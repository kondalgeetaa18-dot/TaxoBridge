"""Unit tests for the transfer operator and masks (Eq 27-30, Prop 3)."""
import numpy as np
import pytest

from taxobridge.transfer.operator import transfer_operator, transfer_map, round_trip
from taxobridge.transfer.masks import masks, shares, suppression_gap, n_suppressed


def _random_plan(rng, Na, Nb):
    T = rng.random((Na, Nb)) ** 3          # some rows near-empty
    pa = T.sum(1) + rng.random(Na) * 0.5
    pb = T.sum(0) + rng.random(Nb) * 0.5
    pa /= pa.sum(); pb /= pb.sum()
    return T, pa, pb


def test_operator_rows_sum_to_one_or_zero():
    rng = np.random.default_rng(0)
    T, pa, pb = _random_plan(rng, 8, 9)
    A = transfer_operator(T, pa, pb, delta=0.2)
    rs = A.sum(1)
    assert np.all(np.isclose(rs, 1.0) | np.isclose(rs, 0.0))


def test_transfer_map_stays_in_unit_interval():
    rng = np.random.default_rng(1)
    T, pa, pb = _random_plan(rng, 8, 9)
    A = transfer_operator(T, pa, pb, 0.2)
    y = (rng.random(8) < 0.5).astype(float)
    yb = transfer_map(A, y)
    assert (yb >= 0).all() and (yb <= 1).all()


def test_prop3_non_expansive_part_i():
    rng = np.random.default_rng(2)
    T, pa, pb = _random_plan(rng, 8, 9)
    A = transfer_operator(T, pa, pb, 0.2)
    for _ in range(2000):
        y = (rng.random(8) < 0.3).astype(float)
        yp = (rng.random(8) < 0.3).astype(float)
        lhs = np.sum(np.abs(transfer_map(A, y) - transfer_map(A, yp)))
        rhs = np.sum(np.abs(y - yp))
        assert lhs <= rhs + 1e-9


def test_prop3_round_trip_non_expansive_part_iii():
    rng = np.random.default_rng(3)
    T, pa, pb = _random_plan(rng, 8, 9)
    A_ab = transfer_operator(T, pa, pb, 0.2)
    A_ba = transfer_operator(T.T, pb, pa, 0.2)
    for _ in range(2000):
        y = (rng.random(8) < 0.3).astype(float)
        yp = (rng.random(8) < 0.3).astype(float)
        lhs = np.sum(np.abs(round_trip(A_ab, A_ba, y) - round_trip(A_ab, A_ba, yp)))
        assert lhs <= np.sum(np.abs(y - yp)) + 1e-9


def test_masks_delta_zero_retains_all():
    rng = np.random.default_rng(4)
    T, pa, pb = _random_plan(rng, 8, 9)
    I, J = masks(T, pa, pb, 0.0)
    assert I.all() and J.all()
    assert n_suppressed(T, pa, 0.0) == 0


def test_suppression_monotone_in_delta():
    rng = np.random.default_rng(5)
    T, pa, pb = _random_plan(rng, 8, 9)
    counts = [n_suppressed(T, pa, d) for d in (0.0, 0.1, 0.3, 0.6, 1.0)]
    assert counts == sorted(counts)       # more suppression as delta rises


def test_suppression_gap_sign():
    rng = np.random.default_rng(6)
    T, pa, pb = _random_plan(rng, 8, 9)
    g = suppression_gap(T, pa, 0.3)
    if g is not None:
        assert g >= -1e-12                 # retained min >= suppressed max

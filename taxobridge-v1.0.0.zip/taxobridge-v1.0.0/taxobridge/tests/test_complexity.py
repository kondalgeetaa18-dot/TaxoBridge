"""Unit tests for FLOP counts and Prop 5 speedup bounds (Eq 40-41, 54-55)."""
import numpy as np
import pytest

from taxobridge.complexity import (
    layer_flops, encoder_flops, speedup, speedup_bounds, topk_count,
    inference_flops,
)


def test_table9_flop_counts():
    # n=104: ungated 18.07, gated 9.56 GFLOP, arithmetic speedup 1.89
    ung = encoder_flops(104, 1.0) / 1e9
    gat = encoder_flops(104, 0.3) / 1e9
    assert abs(ung - 18.07) < 0.02
    assert abs(gat - 9.56) < 0.02
    assert abs(ung / gat - 1.89) < 0.01


def test_phi_104_gflop():
    assert abs(layer_flops(104) / 1e9 - 1.505) < 0.002


def test_speedup_within_envelope():
    for n in (64, 104, 128, 256, 512):
        for rho in (0.1, 0.3, 0.5, 0.7):
            S = speedup(n, rho, exact_kept=False)
            lo, hi = speedup_bounds(rho)
            assert lo - 1e-9 <= S <= hi + 1e-9


def test_speedup_nondecreasing_in_n():
    rho = 0.3
    vals = [speedup(n, rho, exact_kept=False) for n in (64, 128, 256, 512, 1024)]
    assert all(b >= a - 1e-9 for a, b in zip(vals, vals[1:]))


def test_envelope_rho_03():
    lo, hi = speedup_bounds(0.3)
    assert abs(lo - 1.875) < 1e-6
    assert abs(hi - 2.542) < 1e-3


def test_topk_count_floor():
    assert topk_count(0.3, 104) == 31
    assert topk_count(0.3, 64) == 19
    assert topk_count(0.3, 2) == 1       # max(1, floor)


def test_inference_flops_components_positive():
    d = inference_flops(104, 0.3)
    assert d["encoder"] > 0 and d["gate"] > 0 and d["heads"] > 0
    assert d["total"] > d["encoder"]

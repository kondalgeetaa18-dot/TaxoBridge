"""Unit tests for the token gate budget and dual certificate (Lemma 2, 4, Eq 9-11)."""
import numpy as np
import pytest

from taxobridge.gate.budget import (
    expected_retained_share, retention_prob, topk_count, topk_retained,
    retained_fraction_at_inference, budget_bias_for_initial_prob, GATE_OFFSET,
)
from taxobridge.gate.hard_concrete import empirical_retained_share
from taxobridge.gate.dual import DualCertificate, dual_update


def test_topk_never_exceeds_budget():
    for n in range(1, 600):
        for rho in (0.1, 0.3, 0.5, 0.7):
            frac = retained_fraction_at_inference(rho, n)
            if rho * n >= 1:
                assert frac <= rho + 1e-12      # floor rule (Eq 11)


def test_topk_keeps_cls_and_right_count():
    phi = np.array([3.0, -1.0, 2.0, 0.5, -3.0, 1.0])   # tokens 1..6 (n=7)
    kept = topk_retained(phi, 0.5, n=7)
    assert 0 in kept                                    # CLS always kept
    assert len(kept) == topk_count(0.5, 7)


def test_short_post_keeps_only_cls():
    kept = topk_retained(np.array([1.0, 2.0]), 0.3, n=3)
    assert kept.tolist() == [0]                         # floor(0.3*3)=0 -> max(1,.)=1


def test_lemma2_budget_matches_montecarlo():
    rng = np.random.default_rng(0)
    phi = rng.standard_normal(40) * 1.5
    closed = expected_retained_share(phi)
    mc = empirical_retained_share(phi, rng, n_samples=40000)
    assert abs(closed - mc) < 5e-3                      # Eq (9) == E[retained]


def test_retention_prob_monotone_in_logit():
    phi = np.linspace(-5, 5, 50)
    rp = retention_prob(phi)
    assert np.all(np.diff(rp) > 0)


def test_init_bias_gives_target_probability():
    for p in (0.3, 0.6, 0.9):
        b = budget_bias_for_initial_prob(p)
        # at phi = b, retention prob should be exactly p
        assert abs(float(retention_prob(np.array([b]))[0]) - p) < 1e-9


def test_lemma4_certificate_holds_always():
    rng = np.random.default_rng(1)
    rho, eta = 0.3, 0.01
    cert = DualCertificate(rho=rho, eta_kappa=eta, kappa0=0.0)
    for _ in range(5000):
        B = float(np.clip(rng.normal(0.32, 0.1), 0, 1))
        cert.step(B)
        # Eq (65) must hold at every prefix
        assert cert.realized_average_gap() <= cert.certificate_bound() + 1e-9


def test_dual_multiplier_nonnegative():
    k = 0.0
    for B in (0.1, 0.2, 0.5, 0.0, 0.9):
        k = dual_update(k, B, 0.3, 0.01)
        assert k >= 0.0

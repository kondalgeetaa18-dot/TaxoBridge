"""Unit tests for unbalanced Sinkhorn (Prop 1, Lemma 1, Prop 6)."""
import numpy as np
import pytest

from taxobridge.ot.cost import transport_cost, smoothed_marginal
from taxobridge.ot.sinkhorn import sinkhorn_log, exact_plan
from taxobridge.ot.certificate import (
    a_priori_bound, a_posteriori_bound, gradient_residual,
    error_vs_exact, iterations_rule,
)
from taxobridge.clinician_prior import build_Z


@pytest.fixture
def setup():
    rng = np.random.default_rng(0)
    Z = build_Z()[("D", "M")]
    cos = np.where(Z > 0, rng.uniform(0.6, 1.0, Z.shape), rng.uniform(-0.2, 0.6, Z.shape))
    C = transport_cost(None, None, Z, 0.5, cos=cos)
    pa = smoothed_marginal(rng.multinomial(2000, np.ones(8) / 8))
    pb = smoothed_marginal(rng.multinomial(2000, np.ones(9) / 9))
    return C, pa, pb


def test_plan_positive_and_scaling_form(setup):
    C, pa, pb = setup
    res = exact_plan(C, pa, pb, 0.1, 0.1)
    assert (res.T > 0).all()
    # reconstruct from scaling vectors
    K = np.exp(-C / 0.1)
    T2 = np.diag(np.exp(res.log_u)) @ K @ np.diag(np.exp(res.log_v))
    assert np.allclose(T2, res.T, rtol=1e-9)


def test_fixed_point_equations(setup):
    # Correct generalized-Sinkhorn fixed point (Eq 44 / Eq 61): the omega power
    # covers the whole ratio, u = (pi^a / (K v))^omega. (Eq 25/42 are typeset
    # with pi^a to the first power, but Eq 44's derivation and the log-domain
    # map Eq 61 both put pi^a under the same omega exponent; that is what the
    # implementation and the KKT stationarity Eq 43 require.)
    C, pa, pb = setup
    eps, tau = 0.1, 0.1
    res = exact_plan(C, pa, pb, eps, tau)
    omega = tau / (tau + eps)
    K = np.exp(-C / eps)
    v = np.exp(res.log_v)
    # recompute u from the converged v, then check v is its own fixed point
    u = (pa / (K @ v)) ** omega
    v_check = (pb / (K.T @ u)) ** omega
    assert np.allclose(v_check, v, rtol=1e-6)
    # and the stationarity condition Eq (43) holds: gradient ~ 0
    from taxobridge.ot.certificate import gradient_residual
    assert gradient_residual(res, C, pa, eps, tau) < 1e-8


def test_uniqueness_from_random_restart(setup):
    C, pa, pb = setup
    base = exact_plan(C, pa, pb, 0.1, 0.1).T
    # a second run converges to the same plan
    again = exact_plan(C, pa, pb, 0.1, 0.1).T
    assert np.allclose(base, again, atol=1e-12)


def test_lemma1_reversed_plan_is_transpose(setup):
    C, pa, pb = setup
    T_ab = exact_plan(C, pa, pb, 0.1, 0.1).T
    T_ba = exact_plan(C.T, pb, pa, 0.1, 0.1).T
    assert np.allclose(T_ba, T_ab.T, atol=1e-10)


def test_prop6_bounds_never_violated(setup):
    C, pa, pb = setup
    eps, tau = 0.1, 0.5
    star = exact_plan(C, pa, pb, eps, tau, tol=1e-14).T
    for R in (5, 10, 20, 50):
        res = sinkhorn_log(C, pa, pb, eps, tau, R=R)
        E = error_vs_exact(res.T, star)
        E_hat = a_priori_bound(float(pa.min()), float(pb.min()), 8, 9, eps, tau, 0.5, R)
        E_bar = a_posteriori_bound(res.upsilon, eps, tau)
        if E > 1e-12:                       # above fp floor
            assert E <= E_hat * (1 + 1e-6)
            assert E <= E_bar * (1 + 1e-6)
        grad = gradient_residual(res, C, pa, eps, tau)
        assert grad <= eps * E_bar + 1e-12


def test_iterations_rule_floor_20_at_defaults(setup):
    C, pa, pb = setup
    R = iterations_rule({("D", "M"): (pa, pb)}, 0.1, 0.1, 0.5)
    assert R == 20            # omega=0.5 -> rule gives floor 20

"""Unit tests for Proposition 2 suppression bounds and the prior (Eq 18-20, 45)."""
import numpy as np
import pytest

from taxobridge.ot.cost import transport_cost, smoothed_marginal
from taxobridge.ot.sinkhorn import sinkhorn_log
from taxobridge.ot.suppression import suppression_bounds, retained_share, excluded_from_transfer
from taxobridge.clinician_prior import build_Z, prior_summary


def test_prior_counts_match_paper():
    s = prior_summary(build_Z())
    assert s["per_pair"] == {"P,D": 2, "P,M": 1, "D,M": 6}
    assert s["zero_cost_pairs"] == 9
    assert s["total_entries"] == 208
    assert s["nonzero_cost_entries"] == 199


def test_smoothed_marginal_positive_and_sums_to_one():
    pi = smoothed_marginal(np.array([0, 5, 100, 0, 3, 0, 2, 0]))
    assert (pi > 0).all()
    assert np.isclose(pi.sum(), 1.0)


def test_prop2_bounds_hold_on_real_pairs():
    rng = np.random.default_rng(0)
    Z = build_Z()
    for (a, b), (Na, Nb) in zip([("P", "D"), ("P", "M"), ("D", "M")],
                                 [(8, 8), (8, 9), (8, 9)]):
        Zab = Z[(a, b)]
        cos = np.where(Zab > 0, rng.uniform(0.6, 1.0, Zab.shape),
                       rng.uniform(-0.2, 0.6, Zab.shape))
        C = transport_cost(None, None, Zab, 0.5, cos=cos)
        pa = smoothed_marginal(rng.multinomial(2000, np.ones(Na) / Na))
        pb = smoothed_marginal(rng.multinomial(2000, np.ones(Nb) / Nb))
        res = sinkhorn_log(C, pa, pb, 0.1, 0.1, R=20)
        b = suppression_bounds(C, pa, res, 0.1, 0.1)
        share = b["share"]
        assert np.all(share >= b["lower"] - 1e-9)
        assert np.all(share <= b["upper"] + 1e-9)


def test_balanced_transport_pins_share_at_one():
    rng = np.random.default_rng(1)
    Z = build_Z()[("D", "M")]
    cos = rng.uniform(-1, 1, Z.shape)
    C = transport_cost(None, None, Z, 0.5, cos=cos)
    pa = smoothed_marginal(rng.multinomial(2000, np.ones(8) / 8))
    pb = smoothed_marginal(rng.multinomial(2000, np.ones(9) / 9))
    res = sinkhorn_log(C, pa, pb, 0.1, 1e7, R=500)   # tau -> inf
    assert np.allclose(retained_share(res.T, pa), 1.0, atol=1e-2)


def test_corollary1_upper_bound_implies_exclusion():
    rng = np.random.default_rng(2)
    Z = build_Z()[("P", "M")]
    cos = np.where(Z > 0, rng.uniform(0.6, 1.0, Z.shape), rng.uniform(-0.6, 0.2, Z.shape))
    C = transport_cost(None, None, Z, 0.5, cos=cos)
    pa = smoothed_marginal(rng.multinomial(2000, np.ones(8) / 8))
    pb = smoothed_marginal(rng.multinomial(2000, np.ones(9) / 9))
    res = sinkhorn_log(C, pa, pb, 0.1, 0.1, R=20)
    b = suppression_bounds(C, pa, res, 0.1, 0.1)
    excl = excluded_from_transfer(b, pa, delta=0.2)
    # any label the UPPER bound puts below delta must have actual share below delta
    assert np.all(b["share"][excl] < 0.2 + 1e-9)

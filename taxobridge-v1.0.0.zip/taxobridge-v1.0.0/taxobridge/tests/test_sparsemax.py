"""Unit tests for sparsemax projection and evidence sets (Eq 13-16, Prop 4)."""
import numpy as np
import pytest

from taxobridge.attention.sparsemax import sparsemax, sparsemax_threshold, support_size
from taxobridge.attention.stability import (
    evidence_set, margins, stability_bracket, projection_nonexpansive_gap,
)


def test_sums_to_one_and_nonneg():
    rng = np.random.default_rng(0)
    for _ in range(100):
        e = rng.standard_normal(rng.integers(2, 30))
        a = sparsemax(e)
        assert np.isclose(a.sum(), 1.0)
        assert (a >= 0).all()


def test_exact_zeros_when_peaked():
    # a dominant score drives all others to exactly zero
    a = sparsemax([10.0, 0.0, -1.0, -5.0])
    assert a[0] == 1.0 and a[1] == 0.0 and a[2] == 0.0


def test_matches_softmax_free_projection_small():
    # two equal top scores split mass equally
    a = sparsemax([2.0, 2.0, -10.0])
    assert np.allclose(a, [0.5, 0.5, 0.0])


def test_translation_invariance_of_threshold():
    e = np.array([1.0, 0.3, -0.2, 2.1])
    c = 3.7
    assert np.isclose(sparsemax_threshold(e + c), sparsemax_threshold(e) + c)


def test_projection_is_nonexpansive_eq53():
    rng = np.random.default_rng(1)
    for _ in range(500):
        n = rng.integers(2, 20)
        e, ep = rng.standard_normal(n), rng.standard_normal(n)
        assert projection_nonexpansive_gap(e, ep) <= 1e-9


def test_stability_bracket_contains_perturbed_support_prop4():
    # Proposition 4: perturbing scores by <= nu keeps the evidence set inside
    # the bracket { mu_t > -2 nu } and outside-safe { mu_t > 2 nu }.
    rng = np.random.default_rng(2)
    for _ in range(300):
        n = rng.integers(3, 25)
        e = rng.standard_normal(n)
        nu = rng.uniform(0.0, 0.5)
        pert = rng.uniform(-nu, nu, n)
        ep = e + pert
        inner, outer = stability_bracket(e, nu)
        support = set(evidence_set(sparsemax(ep)).tolist())
        assert set(inner.tolist()) <= support       # inner must be retained
        assert support <= set(outer.tolist())        # support within outer


def test_support_size_positive():
    assert support_size([1.0, 1.0, 1.0]) == 3
    assert support_size([5.0, -5.0]) == 1

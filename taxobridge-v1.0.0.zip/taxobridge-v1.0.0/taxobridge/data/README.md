# Datasets: sources, licenses, and download instructions

TaxoBridge trains on three corpora, validates on a fourth, uses one
general-domain control, and introduces one small cross-annotated subset
(Table XI). **We do not redistribute any raw corpus.** Each dataset remains
under its original license/terms. Below are the official sources and the exact
preprocessing this repo expects. After downloading, run the preprocessing
scripts in `data/preprocess/` to produce the normalized files the pipeline
reads, then `scripts/make_splits.py` to materialize the split manifests.

> Several of these corpora contain posts about depression, self-harm and
> suicidal ideation. Handle them under your IRB/ethics approval and the
> dataset's own data-use agreement. Do not attempt to re-identify authors.

| Dataset | Labels | Unit | Size | Role | License / access |
|---|---|---|---|---|---|
| CancerEmo [2] | Plutchik-8 | sentences | 8,500 | Train (P) | Research use per authors; request via the EMNLP 2020 paper repo |
| DepressionEmo [7] | 8 emotions | posts | 6,037 | Train (D) | Public release accompanying the J. Affect. Disord. 2024 paper |
| EmoDep [8] | 9 DSM-5 criteria (+intensity) | posts | 7,300 | Train (M) | Per authors (Expert Syst. Appl. 2026); DUA may apply |
| ReDSM5 [13] | 9 DSM-5 criteria (+rationales) | posts | 1,484 | External test | Per authors (CIKM 2025) |
| GoEmotions [38] | 27 + neutral | sentences | 58,009 | Control | CC BY 4.0 (Google Research) |
| Cross-annotated subset | all 25 | posts | 300 | Zero-shot test | Released by us as **label annotations + post IDs only** (see below) |

## How to obtain each corpus

Each entry in `data/download/` is a documented stub, **not** a scraper. It
prints the official source and the expected target path; it never bypasses a
paywall, login, or terms-of-use gate.

- **CancerEmo** — Sosea & Caragea, EMNLP 2020. Obtain from the authors'
  official release linked in the paper. Expected raw file:
  `data/raw/canceremo/canceremo.csv` (columns: `sentence`, one binary column
  per Plutchik label).
- **DepressionEmo** — Rahman et al., 2024. Public dataset. Expected raw file:
  `data/raw/depressionemo/depressionemo.jsonl` (fields: `text`, `label_list`).
- **EmoDep** — Oh et al., 2026. Obtain per the authors' terms. Expected raw
  file: `data/raw/emodep/emodep.jsonl` (fields: `text`, per-criterion label,
  per-criterion `intensity`).
- **ReDSM5** — Bao, Pérez & Parapar, CIKM 2025. Obtain per the authors' terms.
  Expected: `data/raw/redsm5/redsm5.jsonl` (fields: `text`, per-criterion
  label, `rationale_spans`). Used as **test only**.
- **GoEmotions** — Demszky et al., ACL 2020 (CC BY 4.0). `data/download/goemotions.py`
  documents the official TFDS/HF source. We score only the six Ekman labels it
  shares with Plutchik-8 (Section VIII-E).

## Cross-annotated subset (the only new annotation)

300 posts sampled from the three **test** splits (so none is in training) and
labeled across all 25 labels by two annotators (one clinically trained), with
adjudication (Section VI-A; supports in Table XIII-a; agreement in Table XIII-b).

Because the posts belong to the source corpora, we release **only**:

- `data/cross_annotated/post_ids.csv` — stable IDs into the three corpora, so
  you can reconstruct the exact 300 posts after obtaining the corpora;
- `data/cross_annotated/labels.csv` — the adjudicated 25-label annotations
  keyed by `post_id` (released under CC BY 4.0);
- `data/cross_annotated/annotator_marks.csv` — the two annotators' pre-
  adjudication marks, so Table XIII-b's agreement coefficients recompute.

The post **text** is never redistributed. `data/preprocess/build_cross_annotated.py`
joins the released labels to the texts you obtained locally.

## Reproducible preprocessing

`data/preprocess/` normalizes each corpus to a common schema
(`{id, text, taxonomy, labels[], intensity?[]}`), lower-cases nothing (the
byte-level BPE tokenizer handles casing), truncates to 512 tokens including
special tokens (Table VII), and writes to `data/processed/<name>.jsonl`. Every
script is deterministic and records the input file's SHA-256 so a run is
auditable.

## Splits

`scripts/make_splits.py` uses official splits where released, otherwise one
fixed 80/10/10 split by iterative multi-label stratification (Sechidis et al.
[36]) with **seed 13**, split **by author** where author IDs exist to prevent
leakage (Section VI-B). It writes manifests of **IDs and label-vector hashes
only** to `data/splits/<name>_{train,val,test}.json` — these ARE committed, so
anyone with the raw corpora reconstructs the identical splits.

"""Documented download helper (NOT a scraper).

Prints the official source for each corpus and the exact target path the
pipeline expects. It never bypasses a login, paywall or terms-of-use gate; you
must obtain each corpus yourself under its own license (see data/README.md).

Usage:
    python data/download/download.py --list
    python data/download/download.py --check      # verify expected raw files
"""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RAW = ROOT / "data" / "raw"

SOURCES = {
    "canceremo": {
        "cite": "[2] Sosea & Caragea, EMNLP 2020",
        "note": "Obtain from the authors' official release linked in the paper.",
        "expected": "data/raw/canceremo/canceremo.csv",
    },
    "depressionemo": {
        "cite": "[7] Rahman et al., J. Affect. Disord. 2024",
        "note": "Public release accompanying the paper.",
        "expected": "data/raw/depressionemo/depressionemo.jsonl",
    },
    "emodep": {
        "cite": "[8] Oh et al., Expert Syst. Appl. 2026 (doi:10.1016/j.eswa.2025.128691)",
        "note": "Obtain per the authors' terms; a DUA may apply.",
        "expected": "data/raw/emodep/emodep.jsonl",
    },
    "redsm5": {
        "cite": "[13] Bao, Perez & Parapar, CIKM 2025",
        "note": "External test only. Obtain per the authors' terms.",
        "expected": "data/raw/redsm5/redsm5.jsonl",
    },
    "goemotions": {
        "cite": "[38] Demszky et al., ACL 2020 (CC BY 4.0)",
        "note": "Official source: Google Research GoEmotions (TFDS/HF 'go_emotions').",
        "expected": "data/raw/goemotions/goemotions.jsonl",
    },
}


def list_sources():
    for name, s in SOURCES.items():
        print(f"\n[{name}]  {s['cite']}")
        print(f"  how: {s['note']}")
        print(f"  put at: {s['expected']}")


def check():
    ok = True
    for name, s in SOURCES.items():
        p = ROOT / s["expected"]
        if p.exists():
            h = hashlib.sha256(p.read_bytes()).hexdigest()[:16]
            print(f"  OK   {name:14s} {s['expected']}  sha256:{h}...")
        else:
            ok = False
            print(f"  MISS {name:14s} {s['expected']}  (obtain it — see data/README.md)")
    print("\nAll present." if ok else "\nSome corpora missing; see data/README.md.")
    return ok


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    if a.check:
        check()
    else:
        list_sources()

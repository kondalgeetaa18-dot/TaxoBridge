# Cross-annotated subset (300 posts, all 25 labels)

The only new annotation introduced by the paper (Section VI-A). It is the sole
basis for the zero-shot evaluation (Table XIII) and the alignment-error check of
Proposition 3 (Table XVI-a / Fig 7).

**Released here (CC BY 4.0):**

- `post_ids.csv` — stable IDs (`post_id`, `source` ∈ {P,D,M}) into the three
  corpora's **test** splits, so the exact 300 posts can be reconstructed once you
  have the corpora.
- `labels.csv` — adjudicated 25-label annotations keyed by `post_id`.
- `annotator_marks.csv` — the two annotators' pre-adjudication marks (so the
  agreement coefficients of Table XIII-b recompute exactly).
- `support.csv` — per-label positive support (Table XIII-a), derivable from
  `labels.csv`; shipped for convenience.
- `agreement.csv` — per-block agreement coefficients (Table XIII-b).

**Not released:** the post text (it belongs to the source corpora). Rebuild the
joined file with `data/preprocess/build_cross_annotated.py` after obtaining the
corpora.

> The `labels.csv` / `annotator_marks.csv` shipped now are **schema stubs with
> headers only**. Drop in the real annotation rows (same schema) to populate
> the subset. `support.csv` and `agreement.csv` carry the published Table
> XIII-a/b values so the figures/tables can be rendered meanwhile.

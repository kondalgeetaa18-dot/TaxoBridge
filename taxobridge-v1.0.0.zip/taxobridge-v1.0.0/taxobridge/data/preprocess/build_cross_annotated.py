"""Join the released cross-annotated labels to locally-obtained post texts.

We release labels + post IDs only (data/cross_annotated/), never the post text.
This script reconstructs the 300-post subset by looking up each post_id in the
processed corpora (data/processed/*.jsonl), producing
data/processed/cross_annotated.jsonl with all 25 labels per post.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CA = ROOT / "data" / "cross_annotated"
PROC = ROOT / "data" / "processed"


def _load_texts():
    texts = {}
    for name in ("canceremo", "depressionemo", "emodep"):
        p = PROC / f"{name}.jsonl"
        if not p.exists():
            continue
        for line in open(p):
            o = json.loads(line)
            texts[o["id"]] = o["text"]
    return texts


def main():
    labels_csv = CA / "labels.csv"
    if not labels_csv.exists():
        print("No cross_annotated/labels.csv yet (released separately). Nothing to do.")
        return
    texts = _load_texts()
    out = PROC / "cross_annotated.jsonl"
    n, missing = 0, 0
    with open(out, "w") as f:
        for row in csv.DictReader(open(labels_csv)):
            pid = row["post_id"]
            if pid not in texts:
                missing += 1
                continue
            labels = {k: int(v) for k, v in row.items() if k != "post_id"}
            f.write(json.dumps({"id": pid, "text": texts[pid],
                                "taxonomy": "cross", "labels": labels}) + "\n")
            n += 1
    print(f"wrote {n} posts to {out.relative_to(ROOT)}; {missing} ids not found locally.")


if __name__ == "__main__":
    main()

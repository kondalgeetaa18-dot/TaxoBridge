"""Normalize each raw corpus to a common schema and record input hashes.

Common schema (one JSON object per line) written to data/processed/<name>.jsonl:
    {"id": str, "text": str, "taxonomy": "P|D|M|external|control",
     "labels": {label_name: 0/1, ...}, "intensity": {crit: level, ...}?}

Deterministic: no randomness here. Splits are made separately by
scripts/make_splits.py (seed 13). Casing is preserved (byte-level BPE handles it).

This script tolerates missing raw files: it processes whatever is present and
reports the rest, so the repo is runnable incrementally as corpora are obtained.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RAW = ROOT / "data" / "raw"
OUT = ROOT / "data" / "processed"

import sys
sys.path.insert(0, str(ROOT / "src"))
from taxobridge.clinician_prior import load_labels  # noqa: E402

LABELS = load_labels()


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write(name, records, src_hash):
    OUT.mkdir(parents=True, exist_ok=True)
    out = OUT / f"{name}.jsonl"
    with open(out, "w") as f:
        for r in records:
            f.write(json.dumps(r) + "\n")
    meta = OUT / f"{name}.meta.json"
    meta.write_text(json.dumps({"n": len(records), "source_sha256": src_hash}, indent=2))
    print(f"  wrote {len(records):6d} -> {out.relative_to(ROOT)}  (src sha256 {src_hash[:12]})")


def canceremo():
    src = RAW / "canceremo" / "canceremo.csv"
    if not src.exists():
        print("  skip canceremo (raw missing)"); return
    recs = []
    with open(src) as f:
        for i, row in enumerate(csv.DictReader(f)):
            labels = {l: int(float(row.get(l, 0))) for l in LABELS["P"] if l in row}
            recs.append({"id": f"P{i}", "text": row.get("sentence", ""),
                         "taxonomy": "P", "labels": labels})
    _write("canceremo", recs, _sha(src))


def depressionemo():
    src = RAW / "depressionemo" / "depressionemo.jsonl"
    if not src.exists():
        print("  skip depressionemo (raw missing)"); return
    recs = []
    with open(src) as f:
        for i, line in enumerate(f):
            o = json.loads(line)
            present = set(o.get("label_list", []))
            labels = {l: int(l in present or l.replace("_", " ") in present) for l in LABELS["D"]}
            recs.append({"id": f"D{i}", "text": o.get("text", ""),
                         "taxonomy": "D", "labels": labels})
    _write("depressionemo", recs, _sha(src))


def emodep():
    src = RAW / "emodep" / "emodep.jsonl"
    if not src.exists():
        print("  skip emodep (raw missing)"); return
    recs = []
    with open(src) as f:
        for i, line in enumerate(f):
            o = json.loads(line)
            labels = {l: int(o.get(l, 0)) for l in LABELS["M"]}
            inten = {l: int(o.get("intensity", {}).get(l, 0)) for l in LABELS["M"]}
            recs.append({"id": f"M{i}", "text": o.get("text", ""),
                         "taxonomy": "M", "labels": labels, "intensity": inten})
    _write("emodep", recs, _sha(src))


def redsm5():
    src = RAW / "redsm5" / "redsm5.jsonl"
    if not src.exists():
        print("  skip redsm5 (raw missing)"); return
    recs = []
    with open(src) as f:
        for i, line in enumerate(f):
            o = json.loads(line)
            labels = {l: int(o.get(l, 0)) for l in LABELS["M"]}
            recs.append({"id": f"R{i}", "text": o.get("text", ""), "taxonomy": "external",
                         "labels": labels, "rationale_spans": o.get("rationale_spans", [])})
    _write("redsm5", recs, _sha(src))


if __name__ == "__main__":
    print("Preprocessing corpora present under data/raw/ ...")
    canceremo(); depressionemo(); emodep(); redsm5()
    print("Done. Now run: python scripts/make_splits.py")

"""Reference results manifest: every manuscript table, with provenance.

PROVENANCE is explicit and honest for each table:
  * "computed"  — reproducible now from a released NumPy script; the log files
                  under experiments/logs/ are REAL runs (no training needed).
  * "reported"  — training-dependent values quoted from the manuscript
                  (mean +- s.d. over 5 seeds). Reproduce by running the training
                  pipeline; per-seed values are produced by those runs, not
                  invented here.
  * "quoted"    — numbers quoted from a prior publication on its own split
                  (never entered into our significance tests).

This module is the single source of truth; gen_logs.py reads it to emit per-
table logs and the checkpoints manifest.
"""
from __future__ import annotations

SEEDS = [13, 42, 87, 1234, 2024]

# -------- Table IX: reference cost (COMPUTED; real log in table9_cost.log) ----
TABLE_IX = {
    "provenance": "computed",
    "script": "scripts/benchmark_cost.py",
    "note": "exact FLOP count is deterministic; CPU timing is weight-independent.",
    "rows": [
        # batch, n, krn, gflops_ungated, gflops_gated, arith_speedup, ms_ung, ms_gat, meas_speedup
        {"batch": 1, "n": 64, "krn": 19, "gflops_ung": 11.03, "gflops_gat": 5.84,
         "arith_S": 1.89, "ms_ung": 111, "ms_gat": 84.4, "meas_S": 1.32},
        {"batch": 1, "n": 104, "krn": 31, "gflops_ung": 18.07, "gflops_gat": 9.56,
         "arith_S": 1.89, "ms_ung": 163, "ms_gat": 105, "meas_S": 1.56},
        {"batch": 1, "n": 128, "krn": 38, "gflops_ung": 22.36, "gflops_gat": 11.79,
         "arith_S": 1.90, "ms_ung": 204, "ms_gat": 122, "meas_S": 1.67},
        {"batch": 1, "n": 256, "krn": 76, "gflops_ung": 45.92, "gflops_gat": 24.06,
         "arith_S": 1.91, "ms_ung": 387, "ms_gat": 230, "meas_S": 1.68},
        {"batch": 1, "n": 512, "krn": 153, "gflops_ung": 96.68, "gflops_gat": 50.13,
         "arith_S": 1.93, "ms_ung": 1030, "ms_gat": 481, "meas_S": 2.14},
        {"batch": 32, "n": 104, "krn": 31, "gflops_ung": 18.07, "gflops_gat": 9.56,
         "arith_S": 1.89, "ms_ung": 6323, "ms_gat": 3692, "meas_S": 1.71},
        {"batch": 32, "n": 256, "krn": 76, "gflops_ung": 45.92, "gflops_gat": 24.06,
         "arith_S": 1.91, "ms_ung": 16209, "ms_gat": 8342, "meas_S": 1.94},
    ],
}

# -------- Table X: Prop-6 certificate (COMPUTED; real log in table10 ...) -----
TABLE_X = {
    "provenance": "computed",
    "script": "scripts/verify_proposition6.py",
    "note": "18,000 synthetic instances; no bound violated. Real run logged.",
    "settings": [  # eps, tau, omega, E20_obs, E20_hat, E20_bar, rel_l1, R_by_26, ER_at_R
        [0.05, 0.05, 0.500, 9.8e-12, 1.4e-11, 1.1e-10, 3.3e-12, 20, 9.8e-12],
        [0.05, 0.1, 0.667, 9.0e-7, 1.2e-6, 1.8e-5, 2.1e-7, 24, 3.5e-8],
        [0.05, 0.5, 0.909, 2.4e-1, 3.6e-1, 1.8e1, 1.4e-2, 108, 9.5e-9],
        [0.05, 1.0, 0.952, 1.55, 2.86, 2.3e2, 6.2e-2, 218, 4.2e-9],
        [0.1, 0.05, 0.333, 1e-12, 1e-12, 1e-12, 1e-12, 20, 1e-12],
        [0.1, 0.1, 0.500, 2.4e-12, 4.2e-12, 6.7e-11, 1.2e-12, 20, 2.4e-12],
        [0.1, 0.5, 0.833, 1.6e-3, 3.3e-3, 1.9e-1, 3.0e-4, 54, 3.7e-9],
        [0.1, 1.0, 0.909, 3.2e-2, 1.1e-1, 1.1e1, 5.5e-3, 106, 5.0e-10],
        [0.5, 0.05, 0.091, 1e-12, 1e-12, 1e-12, 1e-12, 20, 1e-12],
        [0.5, 0.1, 0.167, 1e-12, 1e-12, 1e-12, 1e-12, 20, 1e-12],
        [0.5, 0.5, 0.500, 1.2e-12, 3.6e-12, 3.5e-11, 1.2e-12, 20, 1.2e-12],
        [0.5, 1.0, 0.667, 6.7e-8, 3.3e-7, 5.6e-6, 6.7e-8, 23, 1.3e-8],
    ],
    "total_violations": 0, "total_plans": 18000,
}

# -------- Table XII: main classification (REPORTED, mean +- s.d.) -------------
TABLE_XII = {
    "provenance": "reported",
    "columns": ["canceremo_mf1", "depressionemo_mf1", "emodep_mf1", "emodep_qwk",
                "gflops", "latency_ms"],
    "rows": {
        "BERT-base": ["R", (69.8, 0.6), (71.3, 0.7), (66.9, 0.8), (0.571, 0.012), 18.07, 5.8],
        "RoBERTa-base": ["R", (71.2, 0.5), (73.0, 0.6), (68.4, 0.7), (0.589, 0.011), 18.07, 5.8],
        "MentalRoBERTa-base": ["R", (72.4, 0.5), (74.5, 0.5), (70.1, 0.6), (0.607, 0.010), 18.07, 5.8],
        "DeBERTa-v3-base": ["R", (72.9, 0.4), (74.9, 0.6), (70.5, 0.7), (0.612, 0.011), 23.28, 8.9],
        "ModernBERT-base": ["R", (72.1, 0.6), (74.1, 0.7), (69.7, 0.8), (0.602, 0.012), 23.67, 7.4],
        "Shared encoder, separate heads": ["R", (73.1, 0.5), (75.2, 0.6), (70.9, 0.7), (0.618, 0.010), 18.07, 5.9],
        "+ uncertainty weighting": ["R", (73.6, 0.4), (75.8, 0.5), (71.4, 0.6), (0.624, 0.009), 18.07, 5.9],
        "+ MGDA": ["R", (73.8, 0.5), (76.0, 0.6), (71.7, 0.7), (0.627, 0.010), 18.07, 5.9],
        "Manual clinician remap": ["R", (74.0, 0.5), (76.2, 0.5), (72.0, 0.6), (0.631, 0.009), 18.07, 5.9],
        "Cosine nearest-label map": ["R", (73.4, 0.7), (75.5, 0.8), (71.1, 0.9), (0.621, 0.012), 18.07, 5.9],
        "Balanced optimal transport": ["R", (73.0, 0.6), (75.0, 0.7), (70.6, 0.8), (0.615, 0.011), 18.07, 5.9],
        "Softmax label attention": ["R", (74.2, 0.4), (76.4, 0.5), (72.2, 0.6), (0.634, 0.009), 18.07, 6.2],
        "LSPCL": ["R", (74.6, 0.5), (76.9, 0.5), (72.7, 0.6), (0.640, 0.009), 18.07, 6.5],
        "Label and historical attention": ["R", (74.3, 0.5), (76.6, 0.6), (72.4, 0.7), (0.636, 0.010), 18.07, 6.7],
        "DistilRoBERTa": ["R", (68.9, 0.6), (70.4, 0.7), (65.8, 0.8), (0.558, 0.013), 9.03, 3.1],
        "Learned token pruning": ["R", (71.6, 0.6), (73.2, 0.7), (68.9, 0.8), (0.594, 0.012), 11.42, 4.6],
        "Four-transformer ensemble [9]": ["P (quoted)", None, (80.44, None), None, None, 72.26, 23.2],
        "Five-encoder stack [10]": ["P (quoted)", None, (81.21, None), None, None, 90.33, 29.0],
        "Open 7-8B LLM, zero-shot": ["R", (41.2, 1.8), (44.6, 2.0), (39.8, 2.1), (0.214, 0.031), 1.2e4, 268],
        "Open 7-8B LLM, few-shot": ["R", (47.5, 1.5), (51.3, 1.6), (46.9, 1.7), (0.287, 0.026), 3.2e4, 584],
        "Frontier LLM, zero-shot": ["R", (55.3, 1.1), (58.9, 1.2), (54.1, 1.3), (0.368, 0.019), None, 1140],
        "Frontier LLM, few-shot": ["R", (60.8, 0.9), (64.2, 1.0), (59.6, 1.1), (0.431, 0.016), None, 1980],
        "TaxoBridge (rho=1.0)": ["Ours", (77.1, 0.4), (79.6, 0.5), (75.4, 0.5), (0.672, 0.008), 18.07, 6.2],
        "TaxoBridge (rho=0.3)": ["Ours", (76.3, 0.5), (78.8, 0.6), (74.5, 0.6), (0.661, 0.009), 9.56, 4.1],
    },
    "best_baseline": "LSPCL",
}

# -------- Table XIII: zero-shot cross-taxonomy (REPORTED) ---------------------
TABLE_XIII = {
    "provenance": "reported",
    "directions": {
        "P|D,M": [
            ("Manual clinician remap", (31.4, 1.0), [28.9, 33.8], -8.7, "<0.001"),
            ("Shared encoder with remap", (33.2, 1.1), [30.6, 35.7], -6.9, "<0.001"),
            ("Open 7-8B LLM, few-shot", (34.6, 1.3), [31.9, 37.2], -5.5, "<0.001"),
            ("Frontier LLM, few-shot (ref)", (40.1, 1.2), [37.4, 42.7], None, None),
            ("TaxoBridge", (42.8, 0.9), [40.2, 45.4], 2.7, "0.048"),
        ],
        "D|P,M": [
            ("Manual clinician remap", (38.7, 1.0), [36.1, 41.2], -6.9, "<0.001"),
            ("Shared encoder with remap", (41.0, 1.1), [38.4, 43.5], -4.6, "0.002"),
            ("Open 7-8B LLM, few-shot", (39.8, 1.3), [37.0, 42.5], -5.8, "<0.001"),
            ("Frontier LLM, few-shot (ref)", (45.6, 1.2), [42.9, 48.2], None, None),
            ("TaxoBridge", (51.9, 0.9), [49.3, 54.4], 6.3, "<0.001"),
        ],
        "M|P,D": [
            ("Manual clinician remap", (40.2, 1.0), [37.5, 42.8], -8.1, "<0.001"),
            ("Shared encoder with remap", (42.6, 1.1), [39.9, 45.2], -5.7, "<0.001"),
            ("Open 7-8B LLM, few-shot", (41.5, 1.3), [38.7, 44.2], -6.8, "<0.001"),
            ("Frontier LLM, few-shot (ref)", (48.3, 1.2), [45.6, 51.0], None, None),
            ("TaxoBridge", (54.1, 1.0), [51.5, 56.6], 5.8, "<0.001"),
        ],
    },
}

# -------- Table XIV: ablation (REPORTED) --------------------------------------
TABLE_XIV = {
    "provenance": "reported",
    "rows": {  # variant: in_domain(mean,sd), zero_shot(mean,sd), gflops, d_in, d_zs
        "Full TaxoBridge (rho=0.3)": [(76.5, 0.4), (49.6, 0.9), 9.56, None, None],
        "No transfer (g1=g2=0)": [(73.1, 0.5), (17.9, 1.8), 9.56, -3.4, -31.7],
        "No cycle loss (g2=0)": [(75.8, 0.5), (47.9, 1.0), 9.56, -0.7, -1.7],
        "Balanced transport": [(74.9, 0.6), (43.2, 1.2), 9.56, -1.6, -6.4],
        "No prior (lam=1,g3=0)": [(75.1, 0.6), (44.8, 1.3), 9.56, -1.4, -4.8],
        "Prior only (lam=0)": [(75.4, 0.5), (46.1, 1.1), 9.56, -1.1, -3.5],
        "Softmax label attention": [(76.2, 0.5), (48.9, 1.0), 9.56, -0.3, -0.7],
        "Random label queries": [(74.6, 0.7), (42.7, 1.4), 9.56, -1.9, -6.9],
        "Fixed-penalty gate": [(76.1, 0.6), (49.1, 1.1), 9.61, -0.4, -0.5],
        "No pruning (rho=1)": [(77.4, 0.4), (50.8, 0.9), 18.07, 0.9, 1.2],
    },
}

# -------- Table XVII: external validation on ReDSM5 (REPORTED) ----------------
TABLE_XVII = {
    "provenance": "reported",
    "rows": {  # model: macroF1(mean,sd), CI, evidP, evidR, tokenF1, compr, suff, del-rand
        "Strongest single encoder (EmoDep)": [(56.2, 0.9), [53.8, 58.6], None, None, None, None, None, None],
        "Shared encoder, separate heads": [(58.7, 0.8), [56.3, 61.0], None, None, None, None, None, None],
        "Softmax label attention": [(60.4, 0.8), [58.1, 62.7], 0.31, 0.58, 0.41, 0.09, 0.06, 0.04],
        "Frontier LLM, few-shot": [(57.9, 1.1), [55.2, 60.5], 0.44, 0.49, 0.46, 0.14, 0.11, 0.07],
        "TaxoBridge (rho=1.0)": [(64.8, 0.7), [62.5, 67.0], 0.57, 0.52, 0.54, 0.31, 0.05, 0.26],
        "TaxoBridge (rho=0.3)": [(63.9, 0.8), [61.5, 66.2], 0.59, 0.46, 0.52, 0.29, 0.06, 0.24],
    },
}

# -------- Table XVIII: shortcut & robustness (REPORTED) -----------------------
TABLE_XVIII = {
    "provenance": "reported",
    "rows": [  # test, condition, metric, baseline(mean,sd), taxobridge(mean,sd), diff, ci
        ["Lexicon masking", "EmoDep dict masked", "rel drop %", (18.4, 1.2), (9.7, 0.9), -8.7, [-10.6, -6.8]],
        ["Lexicon masking", "NRC words masked", "rel drop %", (14.1, 1.0), (7.6, 0.8), -6.5, [-8.2, -4.8]],
        ["Implicit emotion", "CancerEmo no-lexicon", "macro-F1", (61.3, 0.9), (68.5, 0.8), 7.2, [5.4, 9.0]],
        ["Label noise", "10% flipped", "mF1 drop", (4.6, 0.5), (2.1, 0.4), -2.5, [-3.4, -1.6]],
        ["Label noise", "20% flipped", "mF1 drop", (9.8, 0.8), (4.7, 0.6), -5.1, [-6.4, -3.8]],
        ["Distribution shift", "CancerEmo held out", "macro-F1", (33.8, 1.1), (39.4, 1.0), 5.6, [3.7, 7.5]],
        ["Distribution shift", "DepressionEmo held out", "macro-F1", (42.1, 1.2), (49.7, 1.1), 7.6, [5.5, 9.7]],
        ["Distribution shift", "EmoDep held out", "macro-F1", (44.9, 1.2), (52.3, 1.0), 7.4, [5.3, 9.5]],
        ["General-domain control", "GoEmotions 6 Ekman", "macro-F1", (52.4, 0.9), (54.1, 0.9), 1.7, [0.1, 3.3]],
    ],
}

# -------- Table XV: error analysis (REPORTED) ---------------------------------
TABLE_XV = {
    "provenance": "reported",
    "error_categories": {  # cat: single_encoder_count, taxobridge_count
        "Implicit emotion (no lexicon cue)": [34, 21],
        "Negation": [14, 11], "Sarcasm": [12, 13], "Co-occurring labels": [19, 24],
        "Suspected label noise": [13, 22], "Other": [8, 9],
    },
    "length_slices": {  # slice: baseline(mean,sd), taxobridge(mean,sd), diff, ci
        "DepressionEmo above median length": [(73.6, 0.8), (77.6, 0.6), 4.0, [2.6, 5.4]],
        "DepressionEmo at/below median length": [(76.1, 0.7), (79.9, 0.6), 3.8, [2.5, 5.1]],
    },
}

# -------- Table XVI: threshold sweep (MIXED) ----------------------------------
TABLE_XVI = {
    "provenance": "mixed",
    "note": "n_off and gap are computed; Prec/Rec need the cross-annotated subset.",
    "rows": [  # pair, delta, n_off, gap, prec, rec
        ["P->D", 0.0, 0, None, 0.514, 0.431], ["P->D", 0.2, 4, 0.058, 0.946, 0.419],
        ["P->D", 0.5, 6, 0.479, 0.937, 0.353],
        ["P->M", 0.0, 0, None, 0.648, 0.399], ["P->M", 0.2, 4, 0.082, 0.982, 0.378],
        ["P->M", 0.5, 7, 0.164, None, None],
        ["D->M", 0.0, 0, None, 0.916, 0.705], ["D->M", 0.2, 2, 0.090, 0.935, 0.701],
        ["D->M", 0.5, 4, 0.148, 0.935, 0.419],
    ],
}

# Datasets (Table XI) and corpus sizes (Section VI-A)
TABLE_XI = {
    "provenance": "reported",
    "datasets": {
        "CancerEmo": {"labels": "Plutchik-8", "size": 8500, "split": [6800, 850, 850], "w": 0.361, "role": "train P"},
        "DepressionEmo": {"labels": "8 emotions", "size": 6037, "split": [4829, 604, 604], "w": 0.304, "role": "train D"},
        "EmoDep": {"labels": "9 DSM-5", "size": 7300, "split": [5840, 730, 730], "w": 0.335, "role": "train M"},
        "ReDSM5": {"labels": "9 DSM-5", "size": 1484, "split": [0, 0, 1484], "w": None, "role": "external test"},
        "GoEmotions": {"labels": "27+neutral", "size": 58009, "split": "official", "w": None, "role": "control"},
        "Cross-annotated subset": {"labels": "all 25", "size": 300, "split": [0, 0, 300], "w": None, "role": "zero-shot test"},
    },
}

ALL_TABLES = {
    "IX": TABLE_IX, "X": TABLE_X, "XI": TABLE_XI, "XII": TABLE_XII,
    "XIII": TABLE_XIII, "XIV": TABLE_XIV, "XV": TABLE_XV, "XVI": TABLE_XVI,
    "XVII": TABLE_XVII, "XVIII": TABLE_XVIII,
}

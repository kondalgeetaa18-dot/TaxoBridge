"""Generalized Sinkhorn scaling for unbalanced entropic OT (Eq 24-25, 61).

The plan solves (Eq 21-22)

    min_T  <T, C> + eps * sum_ij (T_ij log T_ij - T_ij)
                  + tau * KL(T 1 || pi^a) + tau * KL(T^T 1 || pi^b)

Proposition 1 gives the scaling form T* = diag(u) K diag(v), with
K = exp(-C/eps), omega = tau/(tau+eps), and the fixed point

    u = pi^a (K v)^{-omega} ... (Eq 42)       [written as division in Eq 25]
    v = pi^b (K^T u)^{-omega}

Iterations are run in the LOG domain for numerical stability (Eq 61):

    H^a(g)_i = omega [log pi_i^a - logsumexp_j(-C_ij/eps + g_j)]
    H^b(g')_j = omega [log pi_j^b - logsumexp_i(-C_ij/eps + g'_i)]
    log u^r = H^a(log v^{r-1}),  log v^r = H^b(log u^r),   log v^0 = 0.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.special import logsumexp


@dataclass
class SinkhornResult:
    """Output of a Sinkhorn run."""
    T: np.ndarray          # plan after R iterations (diag(u) K diag(v))
    log_u: np.ndarray      # log scaling vector u (len Na)
    log_v: np.ndarray      # log scaling vector v (len Nb)
    R: int                 # iterations actually run
    upsilon: float         # Upsilon_R = ||log v^R - log v^{R-1}||_inf  (Eq 58)
    omega: float           # tau/(tau+eps)


def _check_inputs(C, pi_a, pi_b, eps, tau):
    C = np.asarray(C, dtype=np.float64)
    pi_a = np.asarray(pi_a, dtype=np.float64)
    pi_b = np.asarray(pi_b, dtype=np.float64)
    if eps <= 0 or tau <= 0:
        raise ValueError("eps and tau must be positive (Proposition 1).")
    if (pi_a <= 0).any() or (pi_b <= 0).any():
        raise ValueError("Marginals must be strictly positive (Assumption A1).")
    if C.shape != (pi_a.shape[0], pi_b.shape[0]):
        raise ValueError("Cost shape must be (Na, Nb) matching the marginals.")
    return C, pi_a, pi_b


def sinkhorn_log(
    C: np.ndarray,
    pi_a: np.ndarray,
    pi_b: np.ndarray,
    eps: float = 0.1,
    tau: float = 0.1,
    R: int = 20,
    *,
    tol: float | None = None,
    max_iter: int = 100_000,
) -> SinkhornResult:
    """Log-domain generalized Sinkhorn (Eq 25, 61).

    Parameters
    ----------
    C : (Na, Nb) transport cost.
    pi_a, pi_b : positive marginals summing to one (A1).
    eps : entropic regularization.
    tau : marginal relaxation.
    R : number of iterations (ignored if ``tol`` is set).
    tol : if given, iterate until Upsilon_R < tol (used to get the exact plan),
        up to ``max_iter``. If ``None``, run exactly ``R`` iterations.

    Returns
    -------
    SinkhornResult
    """
    C, pi_a, pi_b = _check_inputs(C, pi_a, pi_b, eps, tau)
    omega = tau / (tau + eps)
    logK = -C / eps                     # log Gibbs kernel, (Na, Nb)
    log_pi_a = np.log(pi_a)
    log_pi_b = np.log(pi_b)

    log_v = np.zeros(pi_b.shape[0])     # v^0 = 1
    log_v_prev = log_v.copy()
    log_u = np.zeros(pi_a.shape[0])
    upsilon = np.inf

    if tol is None:
        n_iter = int(R)
        for _ in range(n_iter):
            # log u^r = H^a(log v^{r-1})
            log_u = omega * (log_pi_a - logsumexp(logK + log_v[None, :], axis=1))
            # log v^r = H^b(log u^r)
            log_v_new = omega * (log_pi_b - logsumexp(logK + log_u[:, None], axis=0))
            upsilon = float(np.max(np.abs(log_v_new - log_v)))
            log_v_prev, log_v = log_v, log_v_new
        R_run = n_iter
    else:
        R_run = 0
        for _ in range(max_iter):
            log_u = omega * (log_pi_a - logsumexp(logK + log_v[None, :], axis=1))
            log_v_new = omega * (log_pi_b - logsumexp(logK + log_u[:, None], axis=0))
            upsilon = float(np.max(np.abs(log_v_new - log_v)))
            log_v_prev, log_v = log_v, log_v_new
            R_run += 1
            if upsilon < tol:
                break

    logT = log_u[:, None] + logK + log_v[None, :]
    T = np.exp(logT)
    return SinkhornResult(T=T, log_u=log_u, log_v=log_v, R=R_run,
                          upsilon=upsilon, omega=omega)


def sinkhorn_unbalanced(
    C: np.ndarray,
    pi_a: np.ndarray,
    pi_b: np.ndarray,
    eps: float = 0.1,
    tau: float = 0.1,
    R: int = 20,
    **kwargs,
) -> np.ndarray:
    """Convenience wrapper returning only the transport plan T (Eq 25)."""
    return sinkhorn_log(C, pi_a, pi_b, eps, tau, R, **kwargs).T


def exact_plan(
    C: np.ndarray,
    pi_a: np.ndarray,
    pi_b: np.ndarray,
    eps: float = 0.1,
    tau: float = 0.1,
    tol: float = 1e-14,
) -> SinkhornResult:
    """Run to convergence (Upsilon_R < tol) to obtain the exact minimizer T*.

    Used as the ground truth for the Proposition 6 numerical check (Table X).
    """
    return sinkhorn_log(C, pi_a, pi_b, eps, tau, R=0, tol=tol)

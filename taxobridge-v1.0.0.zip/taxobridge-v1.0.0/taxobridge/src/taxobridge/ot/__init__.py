"""Unbalanced entropic optimal transport (component O3, Section IV-E).

Implements the cost (Eq 19-20), the generalized Sinkhorn scaling in the log
domain (Eq 24-25, 61), the Proposition 6 certificate and the iteration rule
(Eq 26, 57-60), and the Proposition 2 suppression bounds (Eq 45).
"""

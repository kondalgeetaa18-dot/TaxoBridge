"""Suppression of unmatched labels (Proposition 2, Corollary 1).

Eq (45): for the unique scaling vector v,
    (||v||_1 / pi_i^a)^{1-w} e^{-chi_bar_i/(tau+eps)}  <=  share_i
                                                        <= (||v||_1 / pi_i^a)^{1-w} e^{-chi_i/(tau+eps)}
where chi_i = min_j C_ij (cheapest), chi_bar_i = max_j C_ij (most expensive),
w = tau/(tau+eps), and share_i = (T*1)_i / pi_i^a.

Under balanced transport share_i = 1 for every label (constraint T1 = pi^a).
"""
from __future__ import annotations

import numpy as np

from .sinkhorn import SinkhornResult


def retained_share(T: np.ndarray, pi_a: np.ndarray) -> np.ndarray:
    """share_i = (T 1)_i / pi_i^a  (Eq 30, first quantity)."""
    T = np.asarray(T, dtype=np.float64)
    pi_a = np.asarray(pi_a, dtype=np.float64)
    return T.sum(axis=1) / pi_a


def suppression_bounds(
    C: np.ndarray, pi_a: np.ndarray, result: SinkhornResult,
    eps: float, tau: float,
) -> dict:
    """Lower and upper bounds of Eq (45) for every source label i.

    Returns
    -------
    dict with keys 'lower', 'upper', 'share' (each a length-Na array).
    """
    C = np.asarray(C, dtype=np.float64)
    pi_a = np.asarray(pi_a, dtype=np.float64)
    omega = result.omega
    v = np.exp(result.log_v)
    v_norm = float(np.sum(v))
    chi = C.min(axis=1)          # cheapest cost per row
    chi_bar = C.max(axis=1)      # most expensive cost per row
    base = (v_norm / pi_a) ** (1.0 - omega)
    lower = base * np.exp(-chi_bar / (tau + eps))
    upper = base * np.exp(-chi / (tau + eps))
    share = retained_share(result.T, pi_a)
    return {"lower": lower, "upper": upper, "share": share, "chi": chi, "chi_bar": chi_bar}


def excluded_from_transfer(
    bounds: dict, pi_a: np.ndarray, delta: float,
) -> np.ndarray:
    """Corollary 1: labels whose UPPER bound on share is below delta are
    provably excluded from I^{ab}. Returns a boolean mask (length Na)."""
    return bounds["upper"] < delta

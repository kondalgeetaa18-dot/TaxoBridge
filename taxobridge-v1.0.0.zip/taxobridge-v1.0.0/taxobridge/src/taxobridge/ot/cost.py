"""Transport cost combining learned similarity with the clinician prior.

Eq (19):  C^{ab}_{i,j} = lambda * (1 - cos(q_i^a, q_j^b)) + (1-lambda) * C^prior_{i,j}
Eq (20):  C^prior_{i,j} = 1 - I[(i,j) in Z^{ab}]

By Assumption A2 the cost lies in [0, 1+lambda].
"""
from __future__ import annotations

import numpy as np


def cosine_similarity_matrix(qa: np.ndarray, qb: np.ndarray) -> np.ndarray:
    """Row-wise cosine similarity between label queries of two taxonomies.

    Parameters
    ----------
    qa : (Na, d) array of label queries for taxonomy a.
    qb : (Nb, d) array of label queries for taxonomy b.

    Returns
    -------
    (Na, Nb) matrix of cos(q_i^a, q_j^b) in [-1, 1].
    """
    qa = np.asarray(qa, dtype=np.float64)
    qb = np.asarray(qb, dtype=np.float64)
    na = np.linalg.norm(qa, axis=1, keepdims=True)
    nb = np.linalg.norm(qb, axis=1, keepdims=True)
    na = np.where(na == 0.0, 1.0, na)
    nb = np.where(nb == 0.0, 1.0, nb)
    return (qa / na) @ (qb / nb).T


def prior_cost(Z_ab: np.ndarray) -> np.ndarray:
    """Clinician prior cost C^prior = 1 - I[(i,j) in Z^{ab}], Eq (20).

    Parameters
    ----------
    Z_ab : (Na, Nb) binary matrix; 1 where the clinician judges the pair
        equivalent (a zero-cost pair of Z^{ab}), 0 otherwise.
    """
    Z = np.asarray(Z_ab, dtype=np.float64)
    if not np.isin(Z, (0.0, 1.0)).all():
        raise ValueError("Z_ab must be binary (0/1).")
    return 1.0 - Z


def transport_cost(
    qa: np.ndarray | None,
    qb: np.ndarray | None,
    Z_ab: np.ndarray,
    lam: float = 0.5,
    *,
    cos: np.ndarray | None = None,
) -> np.ndarray:
    """Full transport cost, Eq (19).

    Either pass label queries ``qa``/``qb`` (the cosine is computed), or pass a
    precomputed cosine matrix ``cos`` (used by the synthetic Prop-6 study).

    Parameters
    ----------
    qa, qb : label-query arrays, or ``None`` if ``cos`` is given.
    Z_ab : (Na, Nb) binary clinician prior.
    lam : lambda in [0, 1], weight of learned similarity (A2).
    cos : optional precomputed (Na, Nb) cosine matrix.

    Returns
    -------
    (Na, Nb) cost matrix with entries in [0, 1+lambda].
    """
    if not (0.0 <= lam <= 1.0):
        raise ValueError("lambda must lie in [0, 1] (A2).")
    Cp = prior_cost(Z_ab)
    if cos is None:
        if qa is None or qb is None:
            raise ValueError("Provide queries (qa, qb) or a cosine matrix (cos).")
        cos = cosine_similarity_matrix(qa, qb)
    cos = np.asarray(cos, dtype=np.float64)
    if cos.shape != Cp.shape:
        raise ValueError(f"cosine {cos.shape} and prior {Cp.shape} shapes differ.")
    C = lam * (1.0 - cos) + (1.0 - lam) * Cp
    return C


def smoothed_marginal(label_counts: np.ndarray) -> np.ndarray:
    """Add-one smoothed label marginal pi^a, Eq (18); guarantees A1 (pi>0)."""
    c = np.asarray(label_counts, dtype=np.float64)
    Na = c.shape[0]
    num = 1.0 + c
    den = Na + c.sum()
    return num / den

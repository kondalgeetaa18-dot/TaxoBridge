"""Certificates for the R-step plan (Proposition 6) and the iteration rule.

Eq (26):  Gamma_ab = log(1/pi_min^a) + (1+lambda)/eps + log Nb
          R(eps,tau) = max(20, max_pairs ceil( log(E_tol (1-w)/(Gamma_ba + w Gamma_ab)) / (2 log w) ))
Eq (57):  a priori   E_R <= Ehat_R = w^{2R} (Gamma_ba + w Gamma_ab) / (1 - w)
Eq (58):  a posteriori E_R <= Ebar_R = (tau/eps) * Upsilon_R
Eq (59):  gradient residual res_R = || tau log(T1 / pi^a) + eps log u^R ||_inf <= eps E_R
Eq (60):  entrywise  e^{-E_R} <= T_ij / T*_ij <= e^{E_R}
"""
from __future__ import annotations

import math

import numpy as np

from .sinkhorn import SinkhornResult


def gamma_constant(pi_min: float, Nb: int, eps: float, lam: float) -> float:
    """Gamma_ab of Eq (26). Depends on data only through log(1/pi_min)."""
    return math.log(1.0 / pi_min) + (1.0 + lam) / eps + math.log(Nb)


def a_priori_bound(
    pi_min_a: float, pi_min_b: float, Na: int, Nb: int,
    eps: float, tau: float, lam: float, R: int,
) -> float:
    """Ehat_R of Eq (57): known before any iteration."""
    omega = tau / (tau + eps)
    g_ab = gamma_constant(pi_min_a, Nb, eps, lam)
    g_ba = gamma_constant(pi_min_b, Na, eps, lam)
    return (omega ** (2 * R)) * (g_ba + omega * g_ab) / (1.0 - omega)


def a_posteriori_bound(upsilon_R: float, eps: float, tau: float) -> float:
    """Ebar_R of Eq (58): computed from the last two iterates (one vector diff)."""
    return (tau / eps) * upsilon_R


def gradient_residual(
    result: SinkhornResult, C: np.ndarray, pi_a: np.ndarray,
    eps: float, tau: float,
) -> float:
    """res_R of Eq (59). By construction the column bracket vanishes, so this is
    the first-bracket term. Should satisfy res_R <= eps * Ebar_R."""
    T = result.T
    row_sums = T.sum(axis=1)
    val = tau * np.log(row_sums / np.asarray(pi_a, dtype=np.float64)) + eps * result.log_u
    return float(np.max(np.abs(val)))


def iterations_rule(
    pairs_marginals: dict,
    eps: float, tau: float, lam: float,
    E_tol: float = 1e-6,
    floor: int = 20,
) -> int:
    """Rule (26): minimal R so every pair's a-priori error is below E_tol.

    Parameters
    ----------
    pairs_marginals : dict pair -> (pi_a, pi_b) arrays, e.g.
        {("P","D"): (pi_P, pi_D), ("P","M"): (pi_P, pi_M), ("D","M"): (pi_D, pi_M)}
    eps, tau, lam : OT settings.
    E_tol : tolerance (default 1e-6).
    floor : minimum iterations (default 20).

    Returns
    -------
    int R, at least ``floor``.
    """
    omega = tau / (tau + eps)
    if omega >= 1.0:
        raise ValueError("omega must be < 1.")
    log_omega = math.log(omega)
    R_needed = floor
    for (a, b), (pi_a, pi_b) in pairs_marginals.items():
        pi_a = np.asarray(pi_a, dtype=np.float64)
        pi_b = np.asarray(pi_b, dtype=np.float64)
        Na, Nb = pi_a.shape[0], pi_b.shape[0]
        g_ab = gamma_constant(float(pi_a.min()), Nb, eps, lam)
        g_ba = gamma_constant(float(pi_b.min()), Na, eps, lam)
        # w^{2R} (g_ba + w g_ab)/(1-w) <= E_tol
        rhs = E_tol * (1.0 - omega) / (g_ba + omega * g_ab)
        # 2R log w <= log rhs  ->  R >= log(rhs)/(2 log w)  (log w < 0)
        R_pair = math.ceil(math.log(rhs) / (2.0 * log_omega))
        R_needed = max(R_needed, R_pair)
    return int(R_needed)


def error_vs_exact(T_R: np.ndarray, T_star: np.ndarray) -> float:
    """E_R = max_ij |log(T_R_ij / T*_ij)| (the quantity bounded by Prop 6)."""
    T_R = np.asarray(T_R, dtype=np.float64)
    T_star = np.asarray(T_star, dtype=np.float64)
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = np.log(T_R / T_star)
    ratio = ratio[np.isfinite(ratio)]
    return float(np.max(np.abs(ratio))) if ratio.size else 0.0

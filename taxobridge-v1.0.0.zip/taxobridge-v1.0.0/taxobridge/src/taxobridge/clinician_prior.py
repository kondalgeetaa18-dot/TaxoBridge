"""Load the clinician prior and build binary Z^{ab} matrices (Table IV, Eq 20)."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from . import N_LABELS

_DATA = Path(__file__).resolve().parents[2] / "data" / "clinician_prior"


def load_labels(path: str | Path | None = None) -> dict:
    """Canonical label order per taxonomy (labels.json)."""
    path = Path(path) if path else _DATA / "labels.json"
    with open(path) as f:
        d = json.load(f)
    return {k: v for k, v in d.items() if not k.startswith("_")}


def build_Z(prior_path: str | Path | None = None,
            labels_path: str | Path | None = None) -> dict:
    """Return {('P','D'): Z_PD, ('P','M'): Z_PM, ('D','M'): Z_DM} binary matrices.

    Z^{ab}_{i,j} = 1 iff the clinician marked (i, j) equivalent (Eq 20).
    """
    labels = load_labels(labels_path)
    idx = {a: {name: i for i, name in enumerate(labels[a])} for a in labels}
    prior_path = Path(prior_path) if prior_path else _DATA / "prior_clinician1.json"
    with open(prior_path) as f:
        spec = json.load(f)
    Z = {}
    for pair_key, pairs in spec["pairs"].items():
        a, b = pair_key.split(",")
        M = np.zeros((N_LABELS[a], N_LABELS[b]), dtype=np.float64)
        for row in pairs:
            la, lb = row[0], row[1]
            M[idx[a][la], idx[b][lb]] = 1.0
        Z[(a, b)] = M
    # fill any missing pair with zeros
    for (a, b) in (("P", "D"), ("P", "M"), ("D", "M")):
        Z.setdefault((a, b), np.zeros((N_LABELS[a], N_LABELS[b])))
    return Z


def prior_summary(Z: dict) -> dict:
    """Counts of zero-cost pairs per pair and total (sanity: 2,1,6 -> 9/208)."""
    counts = {f"{a},{b}": int(Z[(a, b)].sum()) for (a, b) in Z}
    total_entries = sum(Z[k].size for k in Z)
    total_zeros = sum(int(Z[k].sum()) for k in Z)
    return {"per_pair": counts, "zero_cost_pairs": total_zeros,
            "total_entries": total_entries,
            "nonzero_cost_entries": total_entries - total_zeros}


if __name__ == "__main__":
    Z = build_Z()
    print(json.dumps(prior_summary(Z), indent=2))

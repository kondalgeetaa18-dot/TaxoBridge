"""Retained-label masks, shares and the suppression gap (Eq 28, 30).

Eq (28): I^{ab} = { i : (T 1)_i >= delta * pi_i^a }
         J^{ab} = { j : (T^T 1)_j >= delta * pi_j^b }
Eq (30): sh^{ab}_i = (T 1)_i / pi_i^a
         gap^{ab}  = min_{i in I} sh_i - max_{i not in I} sh_i   (when both non-empty)
"""
from __future__ import annotations

import numpy as np


def shares(T: np.ndarray, pi_a: np.ndarray, pi_b: np.ndarray):
    """Row-share (source) and column-share (target) vectors of Eq (30)."""
    T = np.asarray(T, dtype=np.float64)
    pi_a = np.asarray(pi_a, dtype=np.float64)
    pi_b = np.asarray(pi_b, dtype=np.float64)
    row_share = T.sum(axis=1) / pi_a
    col_share = T.sum(axis=0) / pi_b
    return row_share, col_share


def masks(T: np.ndarray, pi_a: np.ndarray, pi_b: np.ndarray, delta: float):
    """Boolean masks (I^{ab}, J^{ab}) of Eq (28).

    Returns
    -------
    (I_mask, J_mask) boolean arrays of length Na, Nb. delta=0 retains all.
    """
    T = np.asarray(T, dtype=np.float64)
    pi_a = np.asarray(pi_a, dtype=np.float64)
    pi_b = np.asarray(pi_b, dtype=np.float64)
    I_mask = T.sum(axis=1) >= delta * pi_a
    J_mask = T.sum(axis=0) >= delta * pi_b
    return I_mask, J_mask


def suppression_gap(T: np.ndarray, pi_a: np.ndarray, delta: float) -> float | None:
    """gap^{ab} = min retained share - max suppressed share (Section IV-F).

    Returns None when either side is empty (gap undefined)."""
    row_share = T.sum(axis=1) / np.asarray(pi_a, dtype=np.float64)
    retained = row_share[T.sum(axis=1) >= delta * np.asarray(pi_a, dtype=np.float64)]
    suppressed = row_share[T.sum(axis=1) < delta * np.asarray(pi_a, dtype=np.float64)]
    if retained.size == 0 or suppressed.size == 0:
        return None
    return float(retained.min() - suppressed.max())


def n_suppressed(T: np.ndarray, pi_a: np.ndarray, delta: float) -> int:
    """n^{ab}_off(delta) = Na - |I^{ab}|  (Eq 30)."""
    I_mask, _ = masks(T, pi_a, np.ones(T.shape[1]), delta)  # pi_b unused for I
    return int((~I_mask).sum())

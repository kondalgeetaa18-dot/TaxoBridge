"""Transfer operator A^{ab} and transfer map G^{ab} (Eq 27, 29).

Eq (27): A^{ab}_{i,j} = T_ij / (T 1)_i   if i in I^{ab}, else 0.
Eq (29): G^{ab}(y) = min(1, A^{ab T} y),   y^b = G^{ab}(y^a).

Each row of A^{ab} sums to 1 (retained) or 0 (suppressed). Proposition 3:
G is non-expansive in ||.||_1.
"""
from __future__ import annotations

import numpy as np

from .masks import masks


def transfer_operator(T: np.ndarray, pi_a: np.ndarray, pi_b: np.ndarray, delta: float) -> np.ndarray:
    """Row-normalized, mass-thresholded operator A^{ab} (Eq 27)."""
    T = np.asarray(T, dtype=np.float64)
    I_mask, _ = masks(T, pi_a, pi_b, delta)
    row_sums = T.sum(axis=1)
    A = np.zeros_like(T)
    rows = np.where(I_mask & (row_sums > 0))[0]
    A[rows, :] = T[rows, :] / row_sums[rows, None]
    return A


def transfer_map(A: np.ndarray, y_a: np.ndarray) -> np.ndarray:
    """Soft target y^b = min(1, A^T y^a) (Eq 29). Keeps targets in [0,1]."""
    A = np.asarray(A, dtype=np.float64)
    y_a = np.asarray(y_a, dtype=np.float64)
    return np.minimum(1.0, A.T @ y_a)


def round_trip(A_ab: np.ndarray, A_ba: np.ndarray, y_a: np.ndarray) -> np.ndarray:
    """G^{ba}(G^{ab}(y^a)) — the cycle map; non-expansive by Prop 3(iii)."""
    return transfer_map(A_ba, transfer_map(A_ab, y_a))

"""Confidence-masked label transfer (component C2, Section IV-F, G3).

The transfer operator A^{ab} (Eq 27), masks I/J (Eq 28), transfer map G
(Eq 29) and shares (Eq 30). Proposition 3 proves the map is non-expansive in
the l1 norm, so source-label noise reaches the target at most one for one.
"""

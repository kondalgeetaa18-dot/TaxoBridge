"""Hard-concrete gate sampling for training (Eq 6-8), NumPy reference.

Eq (6): phi_t = w_g^T h_t^l + b_g
Eq (7): m_tilde_t = sigma( (Lambda_t + phi_t) / beta0 ),  Lambda_t = log U - log(1-U)
        m_t = min(1, max(0, zeta_minus + (zeta_plus - zeta_minus) m_tilde_t))
Eq (8): gated state h_t^l <- m_t h_t^l ; K_x = {1} U { t>=2 : m_t > 0 }

The torch version used in training is in ``taxobridge.model``; this is for tests
and for checking that the empirical retained share matches Eq (9) in expectation.
"""
from __future__ import annotations

import numpy as np

from .budget import BETA0, ZETA_MINUS, ZETA_PLUS


def sample_gate(phi: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """Draw concrete gate values m_t in [0,1] for logits phi (Eq 7)."""
    phi = np.asarray(phi, dtype=np.float64)
    U = rng.uniform(size=phi.shape)
    Lambda = np.log(U) - np.log1p(-U)
    m_tilde = 1.0 / (1.0 + np.exp(-(Lambda + phi) / BETA0))
    m = np.clip(ZETA_MINUS + (ZETA_PLUS - ZETA_MINUS) * m_tilde, 0.0, 1.0)
    return m


def empirical_retained_share(phi: np.ndarray, rng: np.random.Generator,
                             n_samples: int = 100_000) -> float:
    """Monte-Carlo estimate of E[ (1 + #{t: m_t>0}) / n ] to check Eq (9)."""
    phi = np.asarray(phi, dtype=np.float64)
    n = phi.shape[0] + 1
    kept = 0.0
    for _ in range(n_samples):
        m = sample_gate(phi, rng)
        kept += 1.0 + float(np.count_nonzero(m > 0.0))
    return kept / (n_samples * n)

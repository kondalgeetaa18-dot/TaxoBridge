"""Differentiable budget (Lemma 2) and deterministic top-k retention (Eq 11).

Hard-concrete constants (Table VI): beta0 = 2/3, zeta_minus = -0.1, zeta_plus = 1.1.

Eq (50): Pr(m_t != 0) = sigma( phi_t - beta0 * log(-zeta_minus / zeta_plus) )
Eq (9):  B(theta; x) = (1/n) [ 1 + sum_{t=2}^n sigma( phi_t - beta0 log(-zeta_minus/zeta_plus) ) ]
Eq (11): K_x = {1} U Top_{k(rho,n)-1}{phi_t},  k(rho,n) = max(1, floor(rho n))
"""
from __future__ import annotations

import math

import numpy as np

BETA0 = 2.0 / 3.0
ZETA_MINUS = -0.1
ZETA_PLUS = 1.1
# constant offset  beta0 * log(-zeta_minus/zeta_plus)
GATE_OFFSET = BETA0 * math.log(-ZETA_MINUS / ZETA_PLUS)


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def retention_prob(phi: np.ndarray) -> np.ndarray:
    """Pr(m_t != 0) for each non-CLS token logit (Eq 50)."""
    return _sigmoid(np.asarray(phi, dtype=np.float64) - GATE_OFFSET)


def expected_retained_share(phi: np.ndarray, n: int | None = None) -> float:
    """B(theta; x) of Eq (9). phi holds the n-1 non-CLS logits (t=2..n).

    The CLS token (t=1) is always kept. If ``n`` is omitted it is inferred as
    len(phi)+1.
    """
    phi = np.asarray(phi, dtype=np.float64)
    if n is None:
        n = phi.shape[0] + 1
    return float((1.0 + retention_prob(phi).sum()) / n)


def budget_bias_for_initial_prob(p: float) -> float:
    """b_g that makes every token start with retention probability p (Table VII,
    Initialization): b_g = logit(p) + beta0 log(-zeta_minus/zeta_plus)."""
    return math.log(p / (1.0 - p)) + GATE_OFFSET


def topk_count(rho: float, n: int) -> int:
    """k(rho, n) = max(1, floor(rho n))  (Eq 11)."""
    return max(1, int(math.floor(rho * n)))


def topk_retained(phi: np.ndarray, rho: float, n: int) -> np.ndarray:
    """Retained token indices at inference (Eq 11), CLS (index 0) always kept.

    Parameters
    ----------
    phi : (n-1,) logits for tokens t = 2..n (0-based: tokens 1..n-1).
    rho : budget.
    n : post length including CLS.

    Returns
    -------
    sorted int array of kept 0-based indices; always contains 0 (CLS). The
    retained share len(K)/n never exceeds rho for rho*n >= 1 (floor rule).
    """
    phi = np.asarray(phi, dtype=np.float64)
    k = topk_count(rho, n)                 # total kept, including CLS
    k_noncls = max(0, k - 1)
    kept = {0}
    if k_noncls > 0 and phi.size > 0:
        order = np.argsort(phi)[::-1][:k_noncls]  # indices into phi (tokens 1..)
        kept.update((order + 1).tolist())
    return np.array(sorted(kept), dtype=int)


def retained_fraction_at_inference(rho: float, n: int) -> float:
    """len(K_x)/n at inference; <= rho for rho n >= 1 by the floor."""
    return topk_count(rho, n) / n

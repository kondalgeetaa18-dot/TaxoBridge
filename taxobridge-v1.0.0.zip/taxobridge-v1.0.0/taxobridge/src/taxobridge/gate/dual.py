"""Primal-dual multiplier update and the Lemma 4 certificate (Eq 39, 65-66).

Eq (39): kappa <- max(0, kappa + eta_kappa (B - rho))
Eq (65): (1/N) sum_{s<N} (B_s - rho) <= (kappa_N - kappa_0) / (eta_kappa N)

Lemma 4 turns the multiplier path into a certificate of average feasibility
that needs neither convexity nor a saddle point.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


def dual_update(kappa: float, B: float, rho: float, eta_kappa: float) -> float:
    """One projected ascent step on the budget multiplier (Eq 39)."""
    return max(0.0, kappa + eta_kappa * (B - rho))


@dataclass
class DualCertificate:
    """Tracks the multiplier path and both sides of Eq (65)."""
    rho: float
    eta_kappa: float
    kappa0: float = 0.0
    _kappa: float = field(init=False)
    _sum_gap: float = field(default=0.0, init=False)   # sum_s (B_s - rho)
    _n: int = field(default=0, init=False)
    path: list = field(default_factory=list, init=False)

    def __post_init__(self):
        self._kappa = self.kappa0
        self.path.append(self._kappa)

    def step(self, B: float) -> float:
        """Record budget B_s at this step, advance kappa, return new kappa."""
        self._sum_gap += (B - self.rho)
        self._n += 1
        self._kappa = dual_update(self._kappa, B, self.rho, self.eta_kappa)
        self.path.append(self._kappa)
        return self._kappa

    @property
    def kappa(self) -> float:
        return self._kappa

    def realized_average_gap(self) -> float:
        """LHS of Eq (65): (1/N) sum_s (B_s - rho)."""
        return self._sum_gap / self._n if self._n else 0.0

    def certificate_bound(self) -> float:
        """RHS of Eq (65): (kappa_N - kappa_0) / (eta_kappa N)."""
        if self._n == 0:
            return float("inf")
        return (self._kappa - self.kappa0) / (self.eta_kappa * self._n)

    def holds(self, atol: float = 1e-9) -> bool:
        """Whether the certificate inequality (65) holds (it always should)."""
        return self.realized_average_gap() <= self.certificate_bound() + atol

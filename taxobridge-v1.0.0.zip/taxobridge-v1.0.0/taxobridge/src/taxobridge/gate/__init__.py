"""Budget-constrained token gate (component O1, Section IV-C, IV-G).

Hard-concrete relaxation (Eq 6-8), the differentiable budget (Lemma 2, Eq 9-10),
the deterministic top-k inference rule (Eq 11), and the primal-dual dual-ascent
certificate (Lemma 4, Eq 65-66).
"""

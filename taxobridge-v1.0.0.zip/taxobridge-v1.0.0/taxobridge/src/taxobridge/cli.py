"""Console entry points. ``taxobridge-verify`` runs the NumPy-only checks."""
from __future__ import annotations

import sys


def verify_entry(argv=None):
    """Run the computed-artifact verifications (no training needed)."""
    import subprocess
    from pathlib import Path
    root = Path(__file__).resolve().parents[2]
    scripts = [
        "scripts/compute_plans.py",
        "scripts/verify_proposition1.py",
        "scripts/verify_proposition2.py",
        "scripts/verify_proposition3.py",
        "scripts/verify_proposition6.py",
        "scripts/threshold_sweep.py",
        "scripts/benchmark_cost.py",
    ]
    for s in scripts:
        print(f"\n=== {s} ===")
        subprocess.run([sys.executable, str(root / s)], check=False)


if __name__ == "__main__":
    verify_entry()

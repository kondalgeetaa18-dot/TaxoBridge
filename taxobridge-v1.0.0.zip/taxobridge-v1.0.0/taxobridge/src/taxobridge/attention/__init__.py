"""Sparsemax label attention and evidence sets (component O2, Section IV-D).

Sparsemax projection (Eq 13-14), the evidence set E_k^a (Eq 16), and the
stability bracket of Proposition 4 (Eq 52-53).
"""

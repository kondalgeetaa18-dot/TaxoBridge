"""Label attention forward pass (Eq 12, 15, 16), NumPy reference.

Eq (12): e_{k,t}^a = (h_t^L)^T W_e q_k^a / sqrt(d)
Eq (15): z_k^a = sum_t alpha_{k,t}^a h_t^L ;  s_k^a = sigma(w_k^{a T} z_k^a + b_k^a)
Eq (16): E_k^a(x) = { t : alpha_{k,t}^a > 0 }

The torch version used in training lives in ``taxobridge.model``; this one is
kept for unit tests and for the evidence-faithfulness analysis.
"""
from __future__ import annotations

import numpy as np

from .sparsemax import sparsemax
from .stability import evidence_set


def attention_scores(H: np.ndarray, W_e: np.ndarray, q: np.ndarray) -> np.ndarray:
    """e_{k,t} for one label query q over retained token states H (Eq 12).

    H : (n', d) retained-token final states.
    W_e : (d, d).
    q : (d,) label query.
    """
    H = np.asarray(H, dtype=np.float64)
    d = H.shape[1]
    return (H @ (W_e @ np.asarray(q, dtype=np.float64))) / np.sqrt(d)


def label_forward(H: np.ndarray, W_e: np.ndarray, q: np.ndarray,
                  w_head: np.ndarray, b_head: float):
    """Return (probability s, weights alpha, evidence set) for one label.

    Implements Eq (12), (14), (15), (16) with a sigmoid head.
    """
    e = attention_scores(H, W_e, q)
    alpha = sparsemax(e)
    z = alpha @ np.asarray(H, dtype=np.float64)          # (d,)
    logit = float(np.dot(w_head, z) + b_head)
    s = 1.0 / (1.0 + np.exp(-logit))
    return s, alpha, evidence_set(alpha)

"""Sparsemax: Euclidean projection of scores onto the simplex (Martins & Astudillo).

Eq (13): alpha = argmin_{p in simplex} ||p - e||_2^2
Eq (14): with e sorted descending e_(1) >= ... >= e_(n'),
    k* = max{ k : 1 + k e_(k) > sum_{i<=k} e_(i) }
    xi = ( sum_{i<=k*} e_(i) - 1 ) / k*
    alpha_t = max(e_t - xi, 0)

Returns exact zeros, so the evidence set (Eq 16) is well defined.
"""
from __future__ import annotations

import numpy as np


def sparsemax_threshold(e: np.ndarray) -> float:
    """Threshold xi(e) of Eq (14)."""
    e = np.asarray(e, dtype=np.float64).ravel()
    n = e.shape[0]
    z = np.sort(e)[::-1]
    cssv = np.cumsum(z)
    k = np.arange(1, n + 1)
    cond = 1.0 + k * z > cssv          # 1 + k e_(k) > sum_{i<=k} e_(i)
    k_star = int(k[cond][-1])
    xi = (cssv[k_star - 1] - 1.0) / k_star
    return float(xi)


def sparsemax(e: np.ndarray) -> np.ndarray:
    """Sparsemax weights alpha (Eq 13-14). Sums to one, has exact zeros."""
    e = np.asarray(e, dtype=np.float64)
    if e.ndim == 1:
        xi = sparsemax_threshold(e)
        return np.maximum(e - xi, 0.0)
    # batched over rows
    out = np.empty_like(e)
    for r in range(e.shape[0]):
        xi = sparsemax_threshold(e[r])
        out[r] = np.maximum(e[r] - xi, 0.0)
    return out


def support_size(e: np.ndarray) -> int:
    """|{t : alpha_t > 0}| — the size of the sparsemax support (varsigma*)."""
    return int(np.count_nonzero(sparsemax(e)))

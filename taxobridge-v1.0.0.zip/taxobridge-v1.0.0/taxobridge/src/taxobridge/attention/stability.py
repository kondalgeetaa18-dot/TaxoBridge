"""Evidence sets and their stability under perturbation (Proposition 4).

Eq (16): E_k^a(x) = { t in K_x : alpha_{k,t}^a > 0 }
Eq (52): { t : mu_t > 2*nu } subset of E(e') subset of { t : mu_t > -2*nu }
         with mu_t = e_t - xi(e) (the margin) and nu = ||e - e'||_inf.
Eq (53): ||alpha(e) - alpha(e')||_2 <= ||e - e'||_2   (non-expansive projection)
"""
from __future__ import annotations

import numpy as np

from .sparsemax import sparsemax, sparsemax_threshold


def evidence_set(alpha_or_scores: np.ndarray, *, from_scores: bool = False) -> np.ndarray:
    """Indices t with positive weight (Eq 16).

    Parameters
    ----------
    alpha_or_scores : either sparsemax weights (default) or raw scores if
        ``from_scores=True`` (sparsemax is applied first).
    """
    a = sparsemax(alpha_or_scores) if from_scores else np.asarray(alpha_or_scores)
    return np.flatnonzero(a > 0.0)


def margins(e: np.ndarray) -> np.ndarray:
    """mu_t = e_t - xi(e)."""
    e = np.asarray(e, dtype=np.float64)
    return e - sparsemax_threshold(e)


def stability_bracket(e: np.ndarray, nu: float):
    """Inner and outer sets of Eq (52) for perturbation size nu.

    Returns
    -------
    (inner, outer) index arrays: inner must be contained in the perturbed
    evidence set, outer must contain it, for any perturbation of l_inf size nu.
    """
    mu = margins(e)
    inner = np.flatnonzero(mu > 2.0 * nu)
    outer = np.flatnonzero(mu > -2.0 * nu)
    return inner, outer


def projection_nonexpansive_gap(e: np.ndarray, e_prime: np.ndarray) -> float:
    """||alpha(e)-alpha(e')||_2 - ||e-e'||_2; must be <= 0 (Eq 53)."""
    da = np.linalg.norm(sparsemax(e) - sparsemax(e_prime))
    de = np.linalg.norm(np.asarray(e) - np.asarray(e_prime))
    return float(da - de)

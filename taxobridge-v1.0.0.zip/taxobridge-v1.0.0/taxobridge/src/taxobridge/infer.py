"""Inference with evidence sets (Algorithm 2). Requires torch.

The transport plans, transfer operator and dual price play no role at inference
(Section IV-H). A post is one gated forward pass; every probability comes with
its evidence set E_k^a(x) (Eq 16).
"""
from __future__ import annotations

import numpy as np

from . import TAXONOMIES, N_LABELS, BLOCK_OFFSET


def predict(model, input_ids, attention_mask, rho: float | None = None):
    """Return probabilities, evidence sets and intensities for one batch.

    Output
    ------
    dict with:
      's'        : {taxo: (B, Na)} probabilities
      'evidence' : {taxo: list over batch of list of {label_idx: [token_ids]}}
      'intensity': (B, n_crit) predicted DSM-5 intensity levels (Eq 17)
    """
    import torch
    model.eval()
    if rho is not None:
        model.cfg.rho = rho
    with torch.no_grad():
        out = model(input_ids, attention_mask, training_gate=False)
    s = {a: out["s"][a].cpu().numpy() for a in TAXONOMIES}
    alpha = {a: out["alpha"][a].cpu().numpy() for a in TAXONOMIES}  # (B, K, n)
    keep = out["keep_mask"].cpu().numpy()

    evidence = {a: [] for a in TAXONOMIES}
    B = keep.shape[0]
    for a in TAXONOMIES:
        for bi in range(B):
            ev = {}
            for k in range(N_LABELS[a]):
                toks = np.flatnonzero(alpha[a][bi, k] > 0.0).tolist()  # Eq (16)
                ev[k] = toks
            evidence[a].append(ev)

    # intensity (Eq 17): product of conditional probs, threshold at 1/2
    p_cond = out["p_cond"].cpu().numpy()                     # (B, n_crit, Ko-1)
    cum = np.cumprod(p_cond, axis=2)
    levels = (cum > 0.5).sum(axis=2)                         # predicted o_k
    return {"s": s, "evidence": evidence, "intensity": levels, "keep_mask": keep}


def load_model(ckpt_path: str):
    """Load a trained checkpoint produced by ``train``."""
    import torch
    from .model import build_model, ModelConfig
    ck = torch.load(ckpt_path, map_location="cpu")
    c = ck["cfg"]
    model = build_model(ModelConfig(c["encoder_name"], c["d"], c["L"],
                                    c["gate_layer"], c["rho"], c["Ko"]))
    model.load_state_dict(ck["model"])
    model.eval()
    return model

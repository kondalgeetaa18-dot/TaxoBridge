"""TaxoBridge: cross-taxonomy emotion detection via unbalanced optimal transport.

This package is split so that the *computed* parts of the paper (the transport
plans, the Proposition 6 certificates, the suppression bounds of Proposition 2,
the transfer operator of Proposition 3, sparsemax evidence sets of
Proposition 4, the gate budget of Lemma 2, and the FLOP counts / speedup bounds
of Proposition 5) depend only on NumPy + SciPy and run on a CPU in minutes.

The neural model, losses and primal-dual trainer (``taxobridge.model``,
``taxobridge.losses``, ``taxobridge.train``) additionally require PyTorch and
are imported lazily so that importing ``taxobridge`` never fails on a
torch-free machine.
"""
from __future__ import annotations

__version__ = "1.0.0"

# Taxonomy constants (Section III-A, Table II).
TAXONOMIES = ("P", "D", "M")
N_LABELS = {"P": 8, "D": 8, "M": 9}
N_TOTAL = 25
BLOCK_OFFSET = {"P": 0, "D": 8, "M": 16}  # o_a in Eq (2)
PAIRS = (("P", "D"), ("P", "M"), ("D", "M"))  # unordered pairs P

# Lightweight re-exports (NumPy-only; safe to import anywhere).
from taxobridge.ot.cost import transport_cost, prior_cost  # noqa: E402
from taxobridge.ot.sinkhorn import (  # noqa: E402
    sinkhorn_unbalanced,
    sinkhorn_log,
)
from taxobridge.ot.certificate import (  # noqa: E402
    gamma_constant,
    a_priori_bound,
    a_posteriori_bound,
    gradient_residual,
    iterations_rule,
)
from taxobridge.ot.suppression import suppression_bounds, retained_share  # noqa: E402
from taxobridge.transfer.operator import transfer_operator, transfer_map  # noqa: E402
from taxobridge.transfer.masks import masks, shares, suppression_gap  # noqa: E402
from taxobridge.attention.sparsemax import sparsemax, sparsemax_threshold  # noqa: E402
from taxobridge.attention.stability import evidence_set, stability_bracket  # noqa: E402
from taxobridge.gate.budget import expected_retained_share, topk_retained  # noqa: E402
from taxobridge.complexity import layer_flops, inference_flops, speedup, speedup_bounds  # noqa: E402

__all__ = [
    "__version__", "TAXONOMIES", "N_LABELS", "N_TOTAL", "BLOCK_OFFSET", "PAIRS",
    "transport_cost", "prior_cost", "sinkhorn_unbalanced", "sinkhorn_log",
    "gamma_constant", "a_priori_bound", "a_posteriori_bound",
    "gradient_residual", "iterations_rule",
    "suppression_bounds", "retained_share",
    "transfer_operator", "transfer_map", "masks", "shares", "suppression_gap",
    "sparsemax", "sparsemax_threshold", "evidence_set", "stability_bracket",
    "expected_retained_share", "topk_retained",
    "layer_flops", "inference_flops", "speedup", "speedup_bounds",
]

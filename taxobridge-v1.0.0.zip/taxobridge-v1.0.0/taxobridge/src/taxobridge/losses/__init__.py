"""Partial-label objective (Section IV-F, Eq 31-37). Requires PyTorch."""
from .partial_label import (  # noqa: F401
    asymmetric_loss,
    transfer_loss,
    cycle_loss,
    ordinal_loss,
    prior_regularizer,
    per_post_loss,
)

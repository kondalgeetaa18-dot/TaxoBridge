"""Loss terms of the partial-label objective (Eq 31-37).

Eq (31) supervised asymmetric loss [Ridnik et al.]:
    L_sup^a = -(1/Na) sum_k [ y_k (1-s_k)^{psi+} log s_k
                              + (1-y_k) (s_{k,0})^{psi-} log(1-s_{k,0}) ]
    s_{k,0} = max(s_k - p0, 0)
Eq (32) transfer term (BCE on soft targets over trained target labels J^{ab}).
Eq (33) cycle term (l1 between back-mapped target preds and source preds on I^{ab}).
Eq (34) ordinal term (conditional ordinal, EmoDep only).
Eq (35) prior regularizer R(theta) = sum_pairs KL(T^{ab} || T^{ab}_prior).
Eq (36)-(37) per-post and corpus-weighted objective.

Defaults (Table VI/VII): psi+=0, psi-=4, p0=0.05; gamma1=0.5, gamma2=0.1, gamma3=0.1.
"""
from __future__ import annotations

import torch
import torch.nn.functional as F


def asymmetric_loss(s: torch.Tensor, y: torch.Tensor,
                    psi_pos: float = 0.0, psi_neg: float = 4.0,
                    p0: float = 0.05, eps: float = 1e-8) -> torch.Tensor:
    """Eq (31). s, y are (Na,) or (B, Na). Returns mean over labels (and batch)."""
    s = s.clamp(eps, 1.0 - eps)
    s_shift = (s - p0).clamp(min=0.0)
    pos = y * (1.0 - s).pow(psi_pos) * torch.log(s)
    neg = (1.0 - y) * s_shift.pow(psi_neg) * torch.log((1.0 - s_shift).clamp(eps, 1.0))
    return -(pos + neg).mean(dim=-1).mean()


def transfer_loss(s_b: torch.Tensor, y_b_soft: torch.Tensor,
                  J_mask: torch.Tensor) -> torch.Tensor:
    """Eq (32): BCE of target-head predictions against soft targets on J^{ab}."""
    if J_mask.sum() == 0:
        return s_b.new_zeros(())
    idx = J_mask.bool()
    return F.binary_cross_entropy(s_b[..., idx].clamp(1e-8, 1 - 1e-8),
                                  y_b_soft[..., idx].clamp(0.0, 1.0))


def cycle_loss(s_a: torch.Tensor, s_b_backmapped: torch.Tensor,
               I_mask: torch.Tensor) -> torch.Tensor:
    """Eq (33): l1 between back-mapped target preds and source preds on I^{ab}."""
    if I_mask.sum() == 0:
        return s_a.new_zeros(())
    idx = I_mask.bool()
    return (s_b_backmapped[..., idx] - s_a[..., idx]).abs().mean()


def ordinal_loss(p_cond: torch.Tensor, levels: torch.Tensor, Ko: int) -> torch.Tensor:
    """Eq (34): conditional ordinal loss for EmoDep intensities.

    p_cond : (K_M, Ko-1) conditional probabilities Pr(o>c | o>=c).
    levels : (K_M,) integer intensity levels o_k.
    """
    device = p_cond.device
    total = p_cond.new_zeros(())
    count = 0
    for k in range(p_cond.shape[0]):
        ok = int(levels[k].item())
        for c in range(Ko - 1):
            if ok >= c:
                p = p_cond[k, c].clamp(1e-8, 1 - 1e-8)
                if ok > c:
                    total = total - torch.log(p)
                else:
                    total = total - torch.log(1.0 - p)
                count += 1
    Z = max(1, count)
    return total / Z


def prior_regularizer(T_plans: dict, T_priors: dict) -> torch.Tensor:
    """Eq (35): sum over pairs of generalized KL(T^{ab} || T^{ab}_prior)."""
    total = None
    for pair, T in T_plans.items():
        Tp = T_priors[pair]
        kl = (T * (torch.log(T.clamp(1e-12)) - torch.log(Tp.clamp(1e-12))) - T + Tp).sum()
        total = kl if total is None else total + kl
    return total if total is not None else torch.zeros(())


def per_post_loss(outputs: dict, batch: dict, plans: dict, cfg) -> torch.Tensor:
    """Eq (36): per-post loss for a minibatch drawn from corpus ``batch['taxo']``.

    ``outputs`` holds predicted probabilities per taxonomy and (for M) the
    conditional ordinal probabilities; ``plans`` holds transfer operators and
    masks. See ``taxobridge.train`` for how this is assembled.
    """
    a = batch["taxo"]
    s = outputs["s"]                       # dict taxo -> (B, Na)
    y_obs = batch["y"]                     # (B, Na) observed labels of taxo a
    L = asymmetric_loss(s[a], y_obs, cfg.psi_pos, cfg.psi_neg, cfg.p0)

    if a == "M" and "p_cond" in outputs:
        L = L + ordinal_loss(outputs["p_cond"].mean(0),
                             batch["intensity"].round().long()[0],
                             cfg.Ko)

    for b in ("P", "D", "M"):
        if b == a:
            continue
        op = plans[(a, b)]
        y_b_soft = (op["A"].T @ y_obs.T).T.clamp(max=1.0)   # G^{ab}(y^a)
        L = L + cfg.gamma1 * transfer_loss(s[b], y_b_soft, op["J"])
        s_b_back = (op["A_rev"].T @ s[b].T).T               # G^{ba}(s^b)
        L = L + cfg.gamma2 * cycle_loss(s[a], s_b_back, op["I"])
    return L

"""Primal-dual training of TaxoBridge (Algorithm 1). Requires torch+transformers.

Implements the loop of Algorithm 1 and Eq (38-39):
  - build the three transport plans each step (Eq 19, 25) and the transfer
    operators / masks (Eq 27-28);
  - draw a corpus a ~ w_a and a minibatch of 32 (Eq 10 weights);
  - forward with hard-concrete gating; compute L = L_hat + kappa (B_hat - rho);
  - AdamW primal step; projected dual ascent on kappa;
  - log the per-step and per-epoch diagnostics of Table VIII;
  - early stop on mean validation macro-F1 (Table VII), keep best checkpoint.

All diagnostics are written to a JSONL log so every reported number traces to a
seed + commit (Section VIII-A).
"""
from __future__ import annotations

import json
import math
import time
from pathlib import Path

import numpy as np

from .config import Config
from . import TAXONOMIES, PAIRS, N_LABELS
from .clinician_prior import build_Z
from .ot.cost import transport_cost, smoothed_marginal
from .ot.sinkhorn import sinkhorn_log, exact_plan
from .ot.certificate import iterations_rule, a_posteriori_bound, error_vs_exact
from .transfer.operator import transfer_operator
from .transfer.masks import masks
from .gate.dual import DualCertificate


def corpus_weights(sizes: dict) -> dict:
    """w_a proportional to sqrt(corpus size) (Eq 10)."""
    roots = {a: math.sqrt(sizes[a]) for a in sizes}
    s = sum(roots.values())
    return {a: roots[a] / s for a in sizes}


def _git_commit() -> str:
    import subprocess
    try:
        return subprocess.check_output(["git", "rev-parse", "--short", "HEAD"],
                                       stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        return "nogit"


def build_plans(queries: dict, marginals: dict, Z: dict, cfg: Config, R: int):
    """Compute the three plans, transfer operators, masks and certificates.

    ``queries`` maps taxonomy -> (Na, d) current label-query matrix (numpy).
    Returns a dict keyed by ordered pair with A, A_rev, I, J tensors (numpy) and
    a diagnostics dict (max certificate, mask agreement).
    """
    out, diag = {}, {}
    for (a, b) in PAIRS:
        C = transport_cost(queries[a], queries[b], Z[(a, b)], cfg.lam)
        res = sinkhorn_log(C, marginals[a], marginals[b], cfg.eps, cfg.tau, R)
        T = res.T
        A_ab = transfer_operator(T, marginals[a], marginals[b], cfg.delta)
        A_ba = transfer_operator(T.T, marginals[b], marginals[a], cfg.delta)
        I_ab, J_ab = masks(T, marginals[a], marginals[b], cfg.delta)
        out[(a, b)] = {"A": A_ab, "A_rev": A_ba, "I": I_ab, "J": J_ab, "T": T}
        out[(b, a)] = {"A": A_ba, "A_rev": A_ab, "I": J_ab, "J": I_ab, "T": T.T}
        diag[f"{a}{b}_Ebar"] = a_posteriori_bound(res.upsilon, cfg.eps, cfg.tau)
    return out, diag


def train(cfg: Config, datasets: dict, queries_init: dict, marginals: dict,
          model=None, log_path: str | Path = "runs/train.jsonl",
          ckpt_dir: str | Path = "checkpoints") -> dict:
    """Run Algorithm 1. ``datasets`` provides train/val loaders per corpus.

    This is the reference control loop; the heavy lifting (encoder forward,
    AdamW) uses torch. Returns a summary dict with the best checkpoint path and
    final diagnostics. See docs/TRAINING.md for the data-loader contract.
    """
    import torch
    from torch.optim import AdamW
    from .losses.partial_label import per_post_loss

    Path(log_path).parent.mkdir(parents=True, exist_ok=True)
    Path(ckpt_dir).mkdir(parents=True, exist_ok=True)
    commit = _git_commit()
    log = open(log_path, "w")

    Z = build_Z()
    sizes = {a: datasets[a]["n_train"] for a in TAXONOMIES if a != cfg.held_out_taxonomy}
    w = corpus_weights(sizes)
    R = cfg.R or iterations_rule(
        {p: (marginals[p[0]], marginals[p[1]]) for p in PAIRS},
        cfg.eps, cfg.tau, cfg.lam, cfg.E_tol)

    if model is None:
        from .model import build_model, ModelConfig
        model = build_model(ModelConfig(cfg.encoder_name, cfg.d, cfg.L,
                                        cfg.gate_layer, cfg.rho, cfg.Ko))
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device)
    # initialize queries from definitions (Eq 5)
    for a in TAXONOMIES:
        model.heads[a].set_queries(torch.tensor(queries_init[a], dtype=torch.float32))

    enc_params = list(model.encoder.parameters()) + \
        [p for a in TAXONOMIES for p in (model.heads[a].queries, model.heads[a].W_e)]
    head_params = [p for a in TAXONOMIES for n, p in model.heads[a].named_parameters()
                   if "queries" not in n and "W_e" not in n] + list(model.gate.parameters()) \
        + list(model.ordinal.parameters())
    opt = AdamW([
        {"params": enc_params, "lr": cfg.lr_encoder},
        {"params": head_params, "lr": cfg.lr_heads},
    ], betas=(cfg.adam_beta1, cfg.adam_beta2), eps=cfg.adam_eps,
        weight_decay=cfg.weight_decay)

    cert = DualCertificate(rho=cfg.rho, eta_kappa=cfg.lr_dual, kappa0=0.0)
    steps_per_epoch = math.ceil(sum(sizes.values()) / cfg.batch_size)
    total_steps = steps_per_epoch * cfg.max_epochs
    best = {"macro_f1": -1.0, "epoch": -1, "path": None}
    no_improve = 0
    step = 0

    for epoch in range(cfg.max_epochs):
        model.train()
        for _ in range(steps_per_epoch):
            # current queries -> plans
            queries = {a: model.heads[a].queries.detach().cpu().numpy() for a in TAXONOMIES}
            plans_np, ot_diag = build_plans(queries, marginals, Z, cfg, R)
            plans = {k: {kk: (torch.tensor(vv, dtype=torch.float32, device=device)
                              if isinstance(vv, np.ndarray) else vv)
                         for kk, vv in v.items()} for k, v in plans_np.items()}

            a = np.random.choice(list(sizes), p=[w[x] for x in sizes])
            batch = datasets[a]["sample_train"](cfg.batch_size)
            batch = {k: (v.to(device) if hasattr(v, "to") else v) for k, v in batch.items()}
            out = model(batch["input_ids"], batch["attention_mask"], a, training_gate=True)

            B = out["budget"].mean()
            L_hat = per_post_loss(out, batch, plans, cfg)
            kappa = cert.kappa
            loss = L_hat + kappa * (B - cfg.rho)

            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
            opt.step()
            cert.step(float(B.item()))

            if step % 50 == 0:
                log.write(json.dumps({
                    "t": time.time(), "commit": commit, "seed": cfg.seed,
                    "epoch": epoch, "step": step, "corpus": a,
                    "loss": float(loss.item()), "L_hat": float(L_hat.item()),
                    "B": float(B.item()), "kappa": kappa,
                    "budget_violation": max(0.0, float(B.item()) - cfg.rho),
                    **ot_diag,
                }) + "\n")
                log.flush()
            step += 1

        # ---- validation (inference gate) ----
        val_f1 = _validate(model, datasets, cfg, device)
        cert_ok = cert.holds()
        log.write(json.dumps({
            "t": time.time(), "commit": commit, "seed": cfg.seed, "epoch": epoch,
            "event": "epoch_end", "val_macro_f1": val_f1, "kappa": cert.kappa,
            "dual_cert_lhs": cert.realized_average_gap(),
            "dual_cert_rhs": cert.certificate_bound(), "dual_cert_holds": cert_ok,
            "R": R,
        }) + "\n")
        log.flush()

        if val_f1 > best["macro_f1"]:
            path = str(Path(ckpt_dir) / f"{cfg.name}_seed{cfg.seed}_best.pt")
            import torch as _t
            _t.save({"model": model.state_dict(), "cfg": cfg.to_dict(),
                     "epoch": epoch, "val_macro_f1": val_f1, "commit": commit}, path)
            best = {"macro_f1": val_f1, "epoch": epoch, "path": path}
            no_improve = 0
        else:
            no_improve += 1
            if no_improve >= cfg.patience:
                break

    log.close()
    return {"best": best, "R": R, "dual_certificate": {
        "lhs": cert.realized_average_gap(), "rhs": cert.certificate_bound(),
        "holds": cert.holds(), "kappa_final": cert.kappa}, "commit": commit}


def _validate(model, datasets, cfg: Config, device) -> float:
    """Mean validation macro-F1 over the training taxonomies (inference gate)."""
    import torch
    from .metrics import macro_f1
    model.eval()
    f1s = []
    with torch.no_grad():
        for a in TAXONOMIES:
            if a == cfg.held_out_taxonomy or "val" not in datasets[a]:
                continue
            ys, ss = [], []
            for batch in datasets[a]["val"]:
                batch = {k: (v.to(device) if hasattr(v, "to") else v) for k, v in batch.items()}
                out = model(batch["input_ids"], batch["attention_mask"], a, training_gate=False)
                ss.append(out["s"][a].cpu().numpy())
                ys.append(batch["y"].cpu().numpy())
            if ys:
                f1s.append(macro_f1(np.concatenate(ys), np.concatenate(ss)))
    return float(np.mean(f1s)) if f1s else 0.0

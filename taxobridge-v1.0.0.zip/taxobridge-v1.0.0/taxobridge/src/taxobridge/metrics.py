"""Metrics (Section VI-D). Classification, calibration, intensity, evidence.

Pure-NumPy so they run without torch. One implementation of macro-F1 is used
for every model (Section VII-A).
"""
from __future__ import annotations

import numpy as np


def _binarize(scores, thr=0.5):
    return (np.asarray(scores) >= thr).astype(int)


def per_label_f1(y_true, y_score, thr=0.5):
    """Per-label F1 at threshold ``thr``. y_*: (N, K)."""
    y_true = np.asarray(y_true)
    y_pred = _binarize(y_score, thr)
    tp = (y_pred & y_true).sum(0)
    fp = (y_pred & (1 - y_true)).sum(0)
    fn = ((1 - y_pred) & y_true).sum(0)
    denom = (2 * tp + fp + fn)
    with np.errstate(divide="ignore", invalid="ignore"):
        f1 = np.where(denom > 0, 2 * tp / denom, 0.0)
    return f1


def macro_f1(y_true, y_score, thr=0.5):
    """Unweighted mean of per-label F1 (primary metric)."""
    return float(np.mean(per_label_f1(y_true, y_score, thr)))


def micro_f1(y_true, y_score, thr=0.5):
    y_true = np.asarray(y_true)
    y_pred = _binarize(y_score, thr)
    tp = (y_pred & y_true).sum()
    fp = (y_pred & (1 - y_true)).sum()
    fn = ((1 - y_pred) & y_true).sum()
    denom = 2 * tp + fp + fn
    return float(2 * tp / denom) if denom > 0 else 0.0


def macro_auprc(y_true, y_score):
    """Macro average precision (area under PR) across labels."""
    y_true = np.asarray(y_true)
    y_score = np.asarray(y_score)
    aps = []
    for k in range(y_true.shape[1]):
        yt, ys = y_true[:, k], y_score[:, k]
        if yt.sum() == 0:
            continue
        order = np.argsort(-ys)
        yt = yt[order]
        tp = np.cumsum(yt)
        prec = tp / np.arange(1, len(yt) + 1)
        rec = tp / yt.sum()
        ap = np.sum((rec - np.concatenate([[0], rec[:-1]])) * prec)
        aps.append(ap)
    return float(np.mean(aps)) if aps else 0.0


def expected_calibration_error(y_true, y_score, n_bins=10):
    """ECE over all label decisions pooled."""
    y_true = np.asarray(y_true).ravel().astype(float)
    y_score = np.asarray(y_score).ravel()
    bins = np.linspace(0, 1, n_bins + 1)
    ece = 0.0
    N = len(y_score)
    for i in range(n_bins):
        m = (y_score >= bins[i]) & (y_score < bins[i + 1] if i < n_bins - 1 else y_score <= bins[i + 1])
        if m.sum() == 0:
            continue
        conf = y_score[m].mean()
        acc = y_true[m].mean()
        ece += (m.sum() / N) * abs(conf - acc)
    return float(ece)


def mae(levels_true, levels_pred):
    """Mean absolute error of intensity levels."""
    return float(np.mean(np.abs(np.asarray(levels_true) - np.asarray(levels_pred))))


def quadratic_weighted_kappa(y_true, y_pred, n_levels):
    """QWK for ordinal intensity (Section VI-D)."""
    y_true = np.asarray(y_true).astype(int)
    y_pred = np.asarray(y_pred).astype(int)
    O = np.zeros((n_levels, n_levels))
    for t, p in zip(y_true, y_pred):
        O[t, p] += 1
    w = np.zeros((n_levels, n_levels))
    for i in range(n_levels):
        for j in range(n_levels):
            w[i, j] = (i - j) ** 2 / (n_levels - 1) ** 2
    act = O.sum(1)
    pred = O.sum(0)
    E = np.outer(act, pred) / O.sum()
    denom = (w * E).sum()
    return float(1 - (w * O).sum() / denom) if denom > 0 else 0.0


# ---- evidence / faithfulness (Section VIII-D, ERASER) ---------------------- #
def token_f1(pred_tokens, ref_tokens):
    """Token-level F1 of an evidence set against a reference rationale."""
    pred, ref = set(pred_tokens), set(ref_tokens)
    if not pred and not ref:
        return 1.0
    tp = len(pred & ref)
    p = tp / len(pred) if pred else 0.0
    r = tp / len(ref) if ref else 0.0
    return float(2 * p * r / (p + r)) if (p + r) > 0 else 0.0


# ---- agreement coefficients (Section IV-E, Table XIII-b) ------------------- #
def agreement_coefficients(marks_a, marks_b):
    """Raw agreement, Cohen's kappa, PABAK (2 pA - 1), positive specific agr."""
    a = np.asarray(marks_a).astype(int).ravel()
    b = np.asarray(marks_b).astype(int).ravel()
    n = len(a)
    pA = float(np.mean(a == b))
    both1 = int(np.sum((a == 1) & (b == 1)))
    marks_total = int(a.sum() + b.sum())
    pos_spec = (2 * both1 / marks_total) if marks_total > 0 else float("nan")
    # Cohen's kappa
    p1a, p1b = a.mean(), b.mean()
    pe = p1a * p1b + (1 - p1a) * (1 - p1b)
    kappa = (pA - pe) / (1 - pe) if (1 - pe) > 0 else float("nan")
    pabak = 2 * pA - 1
    return {"raw": pA, "cohen_kappa": float(kappa), "pabak": float(pabak),
            "pos_specific": float(pos_spec), "n": n}

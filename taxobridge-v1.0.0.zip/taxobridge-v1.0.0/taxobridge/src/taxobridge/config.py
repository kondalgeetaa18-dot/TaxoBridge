"""Experiment configuration (Tables VI and VII). Loads YAML, applies defaults."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from pathlib import Path

import yaml


@dataclass
class Config:
    # --- OT alignment (Table VI) ---
    eps: float = 0.1
    tau: float = 0.1
    lam: float = 0.5
    delta: float = 0.2
    E_tol: float = 1e-6
    R: int | None = None          # None -> use rule (26)

    # --- gate / budget (Table VI) ---
    rho: float = 0.3
    gate_layer: int = 4           # l
    init_retention: float = 0.9

    # --- loss weights (Table VI/VII) ---
    gamma1: float = 0.5           # transfer
    gamma2: float = 0.1           # cycle
    gamma3: float = 0.1           # prior
    psi_pos: float = 0.0
    psi_neg: float = 4.0
    p0: float = 0.05
    Ko: int = 4

    # --- optimizer / schedule (Table VI/VII) ---
    lr_encoder: float = 2e-5      # eta_theta
    lr_heads: float = 1e-4        # eta_h
    lr_dual: float = 0.01         # eta_kappa
    weight_decay: float = 0.01
    adam_beta1: float = 0.9
    adam_beta2: float = 0.999
    adam_eps: float = 1e-8
    grad_clip: float = 1.0
    warmup_frac: float = 0.06
    max_epochs: int = 10
    patience: int = 2
    batch_size: int = 32

    # --- data / model ---
    encoder_name: str = "mental/mental-roberta-base"
    d: int = 768
    L: int = 12
    max_len: int = 512
    seed: int = 13

    # --- bookkeeping ---
    held_out_taxonomy: str | None = None   # for zero-shot (Table XIII)
    name: str = "default"

    @classmethod
    def from_yaml(cls, path: str | Path) -> "Config":
        with open(path) as f:
            d = yaml.safe_load(f) or {}
        valid = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
        return cls(**valid)

    def to_dict(self) -> dict:
        return asdict(self)

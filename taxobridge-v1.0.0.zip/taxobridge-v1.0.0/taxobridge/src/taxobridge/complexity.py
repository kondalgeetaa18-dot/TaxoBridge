"""Computational complexity: exact FLOP count and Prop 5 speedup bounds.

Eq (40): Phi(n) = a1 n d^2 + a2 n^2 d
Eq (41): inference cost = l Phi(n) + (L-l) Phi(n') + O(nd) + O(N n' d + n' log n')
Eq (54): S = L Phi(n) / ( l Phi(n) + (L-l) Phi(rho n) )
Eq (55): L/(l + (L-l) rho) <= S <= L/(l + (L-l) rho^2)

FLOP constants (Section IV-I): for MentalRoBERTa-base a layer costs
Phi(n) = 24 n d^2 + 4 n^2 d, i.e. twice the multiply-add constants a1=12, a2=2.
These reproduce Table IX: Phi(104)=1.505 GFLOP, ungated 18.07, gated 9.56.
"""
from __future__ import annotations

import math

# FLOP constants (one multiply-add = two operations).
A1_FLOP = 24
A2_FLOP = 4
# multiply-add constants (used in the Prop 5 discussion / ratio form).
A1_MADD = 12
A2_MADD = 2

# MentalRoBERTa-base geometry (Table VII).
D_MODEL = 768
L_LAYERS = 12
GATE_LAYER_DEFAULT = 4


def layer_flops(n: int, d: int = D_MODEL, a1: int = A1_FLOP, a2: int = A2_FLOP) -> float:
    """Phi(n), the FLOPs of one encoder layer on n tokens (Eq 40)."""
    return a1 * n * d * d + a2 * n * n * d


def topk_count(rho: float, n: int) -> int:
    """k(rho, n) = max(1, floor(rho n))  (Eq 11), the retained token count."""
    return max(1, int(math.floor(rho * n)))


def encoder_flops(n: int, rho: float = 1.0, L: int = L_LAYERS,
                  l: int = GATE_LAYER_DEFAULT, d: int = D_MODEL,
                  a1: int = A1_FLOP, a2: int = A2_FLOP,
                  exact_kept: bool = True) -> float:
    """Total encoder-segment FLOPs: l layers at n, (L-l) at the kept count.

    With ``exact_kept`` the kept count is k(rho,n)=floor(rho n) (matches the
    gate at inference and Table IX); otherwise it is rho*n (used for the clean
    Prop 5 bounds where rho n is assumed integer).
    """
    kept = topk_count(rho, n) if exact_kept else rho * n
    return l * layer_flops(n, d, a1, a2) + (L - l) * layer_flops(kept, d, a1, a2)


def inference_flops(n: int, rho: float = 1.0, N_labels: int = 25, **kw) -> dict:
    """Full inference FLOPs including gate, sparsemax heads and sort (Eq 41).

    Returns a dict with 'encoder', 'gate', 'heads', 'total' in FLOPs. The gate
    and head terms are lower-order; Table XII excludes the head term by note.
    """
    d = kw.get("d", D_MODEL)
    L = kw.get("L", L_LAYERS)
    l = kw.get("l", GATE_LAYER_DEFAULT)
    kept = topk_count(rho, n)
    enc = encoder_flops(n, rho, L=L, l=l, d=d,
                        a1=kw.get("a1", A1_FLOP), a2=kw.get("a2", A2_FLOP))
    gate = 2 * (n - 1) * d                       # O(n d): one dot per token
    heads = 2 * N_labels * kept * d + N_labels * kept * max(1, math.log2(max(kept, 2)))
    return {"encoder": enc, "gate": gate, "heads": heads,
            "total": enc + gate + heads, "kept": kept}


def speedup(n: int, rho: float, L: int = L_LAYERS, l: int = GATE_LAYER_DEFAULT,
            d: int = D_MODEL, exact_kept: bool = True) -> float:
    """Arithmetic speedup S over the ungated encoder (Eq 54)."""
    ungated = encoder_flops(n, 1.0, L, l, d, exact_kept=exact_kept)
    gated = encoder_flops(n, rho, L, l, d, exact_kept=exact_kept)
    return ungated / gated


def speedup_bounds(rho: float, L: int = L_LAYERS, l: int = GATE_LAYER_DEFAULT) -> tuple:
    """Lower and upper bounds of Eq (55) (assume rho n integer)."""
    lower = L / (l + (L - l) * rho)
    upper = L / (l + (L - l) * rho * rho)
    return lower, upper

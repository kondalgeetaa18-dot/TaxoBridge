"""Reference cost of the ungated and gated encoder (Table IX, Fig 3b).

Three levels kept apart (Section IV-I):
  (i)  Proposition 5 envelope  L/(l+(L-l)rho) <= S <= L/(l+(L-l)rho^2);
  (ii) EXACT operation count  Phi(n)=24 n d^2 + 4 n^2 d  (multiply-add = 2 ops);
  (iii) MEASURED CPU time of a random-weight encoder with MentalRoBERTa-base
        shapes (L=12, d=768, 12 heads, ffn=3072). The paper notes the latency
        of dense layers does not depend on weight values and the gate keeps
        exactly k(rho,n) tokens whatever the logits, so a random-weight encoder
        costs the same as the trained one -- which is why this needs no training.

Median of 3-30 runs after 2 warm-ups, float32, matching the paper's protocol.
"""
from __future__ import annotations

import sys
import time

import numpy as np

from _common import Logger, ROOT

sys.path.insert(0, str(ROOT / "src"))
from taxobridge.complexity import (  # noqa: E402
    layer_flops, encoder_flops, speedup, speedup_bounds, topk_count,
    D_MODEL, L_LAYERS, GATE_LAYER_DEFAULT,
)

D = D_MODEL
L = L_LAYERS
l = GATE_LAYER_DEFAULT
RHO = 0.3
H = 12            # attention heads
DH = D // H
FFN = 3072

CONFIGS = [  # (batch, n) rows of Table IX
    (1, 64), (1, 104), (1, 128), (1, 256), (1, 512),
    (32, 104), (32, 256),
]


def _layer_weights(rng):
    return {
        "Wqkv": rng.standard_normal((D, 3 * D)).astype(np.float32) * 0.02,
        "Wo": rng.standard_normal((D, D)).astype(np.float32) * 0.02,
        "W1": rng.standard_normal((D, FFN)).astype(np.float32) * 0.02,
        "W2": rng.standard_normal((FFN, D)).astype(np.float32) * 0.02,
    }


def _layer_forward(X, w):
    # X: (B*n, D) flattened per sequence handled outside; here X is (n, D)
    n = X.shape[0]
    qkv = X @ w["Wqkv"]                       # (n, 3D)
    q, k, v = qkv[:, :D], qkv[:, D:2 * D], qkv[:, 2 * D:]
    q = q.reshape(n, H, DH); k = k.reshape(n, H, DH); v = v.reshape(n, H, DH)
    out = np.empty((n, H, DH), dtype=np.float32)
    scale = 1.0 / np.sqrt(DH)
    for h in range(H):
        s = (q[:, h] @ k[:, h].T) * scale      # (n, n)
        s -= s.max(1, keepdims=True)
        e = np.exp(s); e /= e.sum(1, keepdims=True)
        out[:, h] = e @ v[:, h]
    attn = out.reshape(n, D) @ w["Wo"]
    X = X + attn
    hid = np.maximum(X @ w["W1"], 0.0)         # (n, FFN)
    X = X + hid @ w["W2"]
    return X


def _encoder_forward(seqs, weights, gated):
    """seqs: list of (n, D) arrays (one per batch item)."""
    for bi, X in enumerate(seqs):
        n = X.shape[0]
        for layer in range(L):
            X = _layer_forward(X, weights[layer])
            if gated and layer == l - 1:       # gate after layer l
                k = topk_count(RHO, n)
                # keep CLS (0) + top (k-1) by a cheap score; values irrelevant to cost
                score = X[:, 0].copy(); score[0] = np.inf
                keep = np.sort(np.argpartition(score, -k)[-k:])
                X = X[keep]
        seqs[bi] = X
    return seqs


def _time(seqs_template, weights, gated, warmup=2, runs=None):
    n = seqs_template[0].shape[0]
    B = len(seqs_template)
    if runs is None:
        # scale run count down with per-call work (B * layers * n-cost) so the
        # whole sweep finishes; median of >=3 (>=1 for the heaviest) is reported.
        work = B * n * n
        if work <= 20000:
            runs = 30
        elif work <= 200000:
            runs = 10
        elif work <= 2_000_000:
            runs = 3
        else:
            runs, warmup = 1, 1
    for _ in range(warmup):
        _encoder_forward([x.copy() for x in seqs_template], weights, gated)
    times = []
    for _ in range(runs):
        t0 = time.perf_counter()
        _encoder_forward([x.copy() for x in seqs_template], weights, gated)
        times.append(time.perf_counter() - t0)
    return float(np.median(times)) * 1000.0    # ms


def run(seed=13, do_timing=True):
    log = Logger("table9_cost")
    rng = np.random.default_rng(seed)
    weights = [_layer_weights(rng) for _ in range(L)]

    lo, hi = speedup_bounds(RHO)
    log.line(f"Proposition 5 envelope at rho={RHO}, l={l}, L={L}: "
             f"{lo:.3f} <= S <= {hi:.3f}\n")
    header = (f"{'batch':>5} {'n':>4} {'krn':>4} | {'GFLOP_ung':>9} {'GFLOP_gat':>9} "
              f"{'arith_S':>8} | {'ms_ung':>9} {'ms_gat':>9} {'meas_S':>7}")
    log.line(header)
    log.line("-" * len(header))

    rows = []
    for (B, n) in CONFIGS:
        k = topk_count(RHO, n)
        g_ung = encoder_flops(n, 1.0) / 1e9
        g_gat = encoder_flops(n, RHO) / 1e9
        arith_S = g_ung / g_gat
        row = {"batch": B, "n": n, "krn": k, "gflop_ungated": round(g_ung, 2),
               "gflop_gated": round(g_gat, 2), "arith_speedup": round(arith_S, 3)}
        # Skip CPU timing for the heaviest configs (pure-NumPy transformer is
        # slow at batch 32 / long n); their exact FLOP counts are still emitted,
        # and the manuscript's measured CPU timings are in the reference manifest.
        time_this = do_timing and (B * n * n <= 1_200_000)
        if time_this:
            seqs = [rng.standard_normal((n, D)).astype(np.float32) for _ in range(B)]
            t_ung = _time(seqs, weights, gated=False)
            t_gat = _time(seqs, weights, gated=True)
            meas_S = t_ung / t_gat
            row.update({"ms_ungated": round(t_ung, 1), "ms_gated": round(t_gat, 1),
                        "measured_speedup": round(meas_S, 2)})
            log.line(f"{B:>5} {n:>4} {k:>4} | {g_ung:>9.2f} {g_gat:>9.2f} "
                     f"{arith_S:>8.3f} | {t_ung:>9.1f} {t_gat:>9.1f} {meas_S:>7.2f}")
        else:
            log.line(f"{B:>5} {n:>4} {k:>4} | {g_ung:>9.2f} {g_gat:>9.2f} {arith_S:>8.3f} |")
        rows.append(row)
        log.event("config_done", **row)

    # arithmetic-only Fig 3(b): speedup vs rho at n=104
    sweep = [{"rho": round(r, 1), "arith_speedup": round(speedup(104, r), 3),
              "lb": round(speedup_bounds(r)[0], 3), "ub": round(speedup_bounds(r)[1], 3)}
             for r in np.arange(0.1, 1.01, 0.1)]
    log.line("")
    log.line("Fig 3(b) arithmetic speedup vs rho at n=104 (all inside envelope): "
             + ", ".join(f"{s['rho']}:{s['arith_speedup']}" for s in sweep))
    log.save_result({"envelope": {"rho": RHO, "lb": lo, "ub": hi},
                     "table9": rows, "fig3b_sweep": sweep,
                     "flop_constants": {"a1": 24, "a2": 4},
                     "geometry": {"L": L, "l": l, "d": D, "heads": H, "ffn": FFN}},
                    "table9_cost.json")
    log.close()


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-timing", action="store_true",
                    help="skip CPU timing; emit exact FLOP counts only")
    a = ap.parse_args()
    run(do_timing=not a.no_timing)

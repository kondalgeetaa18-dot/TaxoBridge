"""Verify Proposition 1: unique plan with scaling form, geometric convergence.

Reproduces Fig 5:
  * the Sinkhorn iterate change Upsilon_r = ||log v^r - log v^{r-1}||_inf decays
    geometrically and tracks the predicted rate omega^{2r};
  * five random positive restarts return the SAME plan (uniqueness).

Runs on the three real taxonomy pairs using the released clinician prior and
synthetic definition-cosines (the structure that matters for convergence is the
cost scale and omega, not the particular trained queries).
"""
from __future__ import annotations

import sys

import numpy as np

from _common import Logger, ROOT

sys.path.insert(0, str(ROOT / "src"))
from taxobridge import PAIRS, N_LABELS
from taxobridge.clinician_prior import build_Z
from taxobridge.ot.cost import transport_cost, smoothed_marginal
from taxobridge.ot.sinkhorn import sinkhorn_log

EPS, TAU, LAM = 0.1, 0.1, 0.5


def sinkhorn_trace(C, pa, pb, eps, tau, R, v0=None):
    """Run R iterations, returning (plan, [Upsilon_r for r=1..R])."""
    from scipy.special import logsumexp
    omega = tau / (tau + eps)
    logK = -C / eps
    log_pi_a, log_pi_b = np.log(pa), np.log(pb)
    log_v = np.zeros(pb.shape[0]) if v0 is None else np.log(v0)
    trace = []
    log_u = np.zeros(pa.shape[0])
    for _ in range(R):
        log_u = omega * (log_pi_a - logsumexp(logK + log_v[None, :], axis=1))
        log_v_new = omega * (log_pi_b - logsumexp(logK + log_u[:, None], axis=0))
        trace.append(float(np.max(np.abs(log_v_new - log_v))))
        log_v = log_v_new
    T = np.exp(log_u[:, None] + logK + log_v[None, :])
    return T, trace, omega


def run(seed=13):
    log = Logger("fig5_proposition1")
    rng = np.random.default_rng(seed)
    Z = build_Z()
    marg = {a: smoothed_marginal(rng.multinomial(2000, np.ones(N_LABELS[a]) / N_LABELS[a]))
            for a in ("P", "D", "M")}

    results = {}
    for (a, b) in PAIRS:
        cos = np.where(Z[(a, b)] > 0, rng.uniform(0.6, 1.0, Z[(a, b)].shape),
                       rng.uniform(-0.2, 0.6, Z[(a, b)].shape))
        C = transport_cost(None, None, Z[(a, b)], LAM, cos=cos)
        T, trace, omega = sinkhorn_trace(C, marg[a], marg[b], EPS, TAU, R=40)
        reached_machine = next((r + 1 for r, u in enumerate(trace) if u < 1e-15), None)
        # predicted rate omega^{2r}
        pred = [omega ** (2 * (r + 1)) for r in range(len(trace))]
        # uniqueness: 5 random restarts
        plans = [T]
        for _ in range(5):
            v0 = rng.uniform(0.1, 2.0, N_LABELS[b])
            Tr, _, _ = sinkhorn_trace(C, marg[a], marg[b], EPS, TAU, R=60, v0=v0)
            plans.append(Tr)
        max_dev = max(float(np.max(np.abs(p - plans[0]))) for p in plans[1:])
        results[f"{a}{b}"] = {
            "omega": omega, "upsilon_trace": trace, "predicted_rate": pred,
            "reached_machine_precision_at": reached_machine,
            "restart_max_deviation": max_dev,
        }
        log.line(f"pair {a}->{b}: omega={omega:.3f}  machine precision by iter "
                 f"{reached_machine}  |  5 restarts agree to {max_dev:.2e}")
        log.event("pair_done", pair=f"{a}{b}", omega=omega,
                  reached=reached_machine, restart_dev=max_dev)

    worst_restart = max(r["restart_max_deviation"] for r in results.values())
    latest_machine = max(r["reached_machine_precision_at"] or 999 for r in results.values())
    log.line("")
    log.line(f"All pairs reach machine precision by iteration {latest_machine} "
             f"(paper: 28).")
    log.line(f"Random restarts return the same plan to {worst_restart:.1e} "
             f"(paper: 2.7e-15) -> uniqueness of Proposition 1 confirmed.")
    log.save_result(results, "fig5_proposition1.json")
    log.close()


if __name__ == "__main__":
    run()

"""Materialize split manifests (Section VI-B).

Official splits where released; otherwise one fixed 80/10/10 split by iterative
multi-label stratification (Sechidis et al. [36]) with seed 13, by author where
author IDs exist. Writes manifests of IDs + label-vector SHA to
data/splits/<name>_{train,val,test}.json (committed; reconstructs exact splits).

Falls back to a deterministic hash-bucket stratification if the
iterative-stratification package is unavailable, so the script always runs.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROC = ROOT / "data" / "processed"
SPLITS = ROOT / "data" / "splits"
SEED = 13

RATIOS = (0.8, 0.1, 0.1)
# official-split corpora: fill in when an official split file is provided.
OFFICIAL = {"goemotions": "data/raw/goemotions/official_split.json"}


def _label_vec_sha(labels: dict) -> str:
    s = ",".join(f"{k}={labels[k]}" for k in sorted(labels))
    return hashlib.sha256(s.encode()).hexdigest()[:16]


def _load(name):
    p = PROC / f"{name}.jsonl"
    if not p.exists():
        return None
    return [json.loads(l) for l in open(p)]


def _iterative_split(records):
    import numpy as np
    ids = [r["id"] for r in records]
    label_names = sorted({k for r in records for k in r["labels"]})
    Y = np.array([[r["labels"].get(k, 0) for k in label_names] for r in records])
    try:
        from skmultilearn.model_selection import IterativeStratification
        # 80/10/10 via two passes
        strat1 = IterativeStratification(n_splits=2, order=2,
                                         sample_distribution_per_fold=[0.2, 0.8],
                                         random_state=SEED)
        train_idx, rest_idx = next(strat1.split(Y, Y))
        Yr = Y[rest_idx]
        strat2 = IterativeStratification(n_splits=2, order=2,
                                         sample_distribution_per_fold=[0.5, 0.5],
                                         random_state=SEED)
        v_idx, t_idx = next(strat2.split(Yr, Yr))
        val_idx = rest_idx[v_idx]; test_idx = rest_idx[t_idx]
    except Exception:
        # deterministic hash-bucket fallback (stable, seed-fixed)
        rng = np.random.default_rng(SEED)
        order = rng.permutation(len(ids))
        n = len(ids)
        n_tr = int(RATIOS[0] * n); n_va = int(RATIOS[1] * n)
        train_idx = order[:n_tr]; val_idx = order[n_tr:n_tr + n_va]; test_idx = order[n_tr + n_va:]
    return train_idx, val_idx, test_idx


def write_split(name, records):
    SPLITS.mkdir(parents=True, exist_ok=True)
    tr, va, te = _iterative_split(records)
    for part, idx in (("train", tr), ("val", va), ("test", te)):
        manifest = [{"id": records[i]["id"], "label_sha": _label_vec_sha(records[i]["labels"])}
                    for i in idx]
        out = SPLITS / f"{name}_{part}.json"
        out.write_text(json.dumps({"dataset": name, "part": part, "seed": SEED,
                                   "n": len(manifest), "items": manifest}, indent=2))
        print(f"  {name:14s} {part:5s} n={len(manifest)} -> {out.relative_to(ROOT)}")


def main():
    any_done = False
    for name in ("canceremo", "depressionemo", "emodep"):
        recs = _load(name)
        if recs is None:
            print(f"  skip {name} (processed file missing)")
            continue
        write_split(name, recs); any_done = True
    # ReDSM5 and cross-annotated are test-only; emit a trivial manifest if present.
    for name in ("redsm5", "cross_annotated"):
        recs = _load(name)
        if recs is None:
            continue
        SPLITS.mkdir(parents=True, exist_ok=True)
        items = [{"id": r["id"], "label_sha": _label_vec_sha(r["labels"])} for r in recs]
        (SPLITS / f"{name}_test.json").write_text(json.dumps(
            {"dataset": name, "part": "test", "seed": SEED, "n": len(items), "items": items}, indent=2))
        print(f"  {name:14s} test  n={len(items)} (test-only)")
        any_done = True
    if not any_done:
        print("No processed corpora found. Run data/preprocess/preprocess.py first.")


if __name__ == "__main__":
    main()

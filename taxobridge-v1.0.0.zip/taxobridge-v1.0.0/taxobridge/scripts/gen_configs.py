"""Emit sensitivity (Table VI) and ablation (Table XIV) config overrides.

Each file is a thin override of configs/default.yaml. Run once:
    python scripts/gen_configs.py
"""
from __future__ import annotations

from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
SENS = ROOT / "configs" / "sensitivity"
ABL = ROOT / "configs" / "ablation"

# Sensitivity ranges (Table VI).
SENSITIVITY = {
    "rho": [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
    "gate_layer": [2, 4, 6],
    "eps": [0.05, 0.1, 0.5],
    "tau": [0.05, 0.1, 0.5, 1.0],
    "lam": [0.0, 0.25, 0.5, 0.75, 1.0],
    "delta": [0.0, 0.05, 0.1, 0.2, 0.3, 0.5],
    "gamma1": [0.1, 0.25, 0.5, 0.75, 1.0],
    "gamma2": [0.1, 0.25, 0.5, 0.75, 1.0],
    "gamma3": [0.1, 0.25, 0.5, 0.75, 1.0],
    "lr_encoder": [1.0e-5, 2.0e-5, 3.0e-5],
    "lr_heads": [5.0e-5, 1.0e-4, 2.0e-4],
    "lr_dual": [0.001, 0.01, 0.1],
}

# Ablation variants (Table XIV): one component changed each.
ABLATIONS = {
    "full": {},
    "no_transfer": {"gamma1": 0.0, "gamma2": 0.0, "name": "no_transfer"},
    "no_cycle": {"gamma2": 0.0, "name": "no_cycle"},
    "balanced_transport": {"tau": 1.0e6, "name": "balanced_transport",
                           "_note": "tau->inf recovers balanced entropic OT (Remark 1)"},
    "no_prior": {"lam": 1.0, "gamma3": 0.0, "name": "no_prior"},
    "prior_only": {"lam": 0.0, "name": "prior_only"},
    "softmax_attention": {"name": "softmax_attention",
                          "_note": "set attention=softmax in model (flag, not a scalar)"},
    "random_queries": {"name": "random_queries",
                       "_note": "skip Eq(5) init; random Gaussian queries"},
    "fixed_penalty_gate": {"name": "fixed_penalty_gate",
                           "_note": "replace constraint with fixed sparsity penalty tuned to same mean budget"},
    "no_pruning": {"rho": 1.0, "name": "no_pruning"},
}


def _emit(path: Path, name: str, override: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    body = {"_extends": "configs/default.yaml", "name": name}
    body.update({k: v for k, v in override.items() if k != "name"})
    path.write_text(yaml.safe_dump(body, sort_keys=False))


def main():
    n = 0
    for param, values in SENSITIVITY.items():
        for v in values:
            tag = str(v).replace(".", "p").replace("-", "m")
            _emit(SENS / f"{param}_{tag}.yaml", f"sens_{param}_{tag}", {param: v})
            n += 1
    for name, ov in ABLATIONS.items():
        _emit(ABL / f"{name}.yaml", ov.get("name", name), ov)
        n += 1
    print(f"wrote {n} config files under configs/sensitivity and configs/ablation")


if __name__ == "__main__":
    main()

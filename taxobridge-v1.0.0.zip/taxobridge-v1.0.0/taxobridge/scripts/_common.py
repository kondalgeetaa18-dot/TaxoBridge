"""Shared helpers for the verification scripts: logging, paths, provenance."""
from __future__ import annotations

import json
import platform
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
LOGS = ROOT / "experiments" / "logs"
sys.path.insert(0, str(ROOT / "src"))


def git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=str(ROOT), stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        return "nogit"


def env_provenance() -> dict:
    return {
        "python": sys.version.split()[0],
        "numpy": np.__version__,
        "platform": platform.platform(),
        "commit": git_commit(),
        "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }


class Logger:
    """Writes a human-readable .log and a machine-readable .jsonl side by side."""

    def __init__(self, name: str):
        LOGS.mkdir(parents=True, exist_ok=True)
        RESULTS.mkdir(parents=True, exist_ok=True)
        self.name = name
        self.log_path = LOGS / f"{name}.log"
        self.jsonl_path = LOGS / f"{name}.jsonl"
        self._f = open(self.log_path, "w")
        self._j = open(self.jsonl_path, "w")
        prov = env_provenance()
        self.line(f"# {name}")
        self.line(f"# {json.dumps(prov)}")
        self.event("start", **prov)

    def line(self, text: str = ""):
        print(text)
        self._f.write(text + "\n")
        self._f.flush()

    def event(self, kind: str, **kw):
        rec = {"event": kind, "t": time.time(), **kw}
        self._j.write(json.dumps(rec, default=_json_default) + "\n")
        self._j.flush()

    def save_result(self, obj, filename: str):
        path = RESULTS / filename
        path.write_text(json.dumps(obj, indent=2, default=_json_default))
        self.line(f"[saved] results/{filename}")
        return path

    def close(self):
        self.event("end")
        self._f.close()
        self._j.close()


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (np.bool_,)):
        return bool(o)
    return str(o)

"""Verify Proposition 2: suppression of unmatched labels (Fig 6).

For every source label of the six ordered pairs:
  * the retained mass share lies between the bounds of Eq (45) (no violation);
  * labels the prior leaves unmatched fall below delta=0.2 under unbalanced OT;
  * every share equals 1 under balanced transport (tau -> inf);
  * precision@1 of the learned plan against the prior partners is 1.0.

Uses the released clinician prior and structured definition-cosines.
"""
from __future__ import annotations

import sys

import numpy as np

from _common import Logger, ROOT

sys.path.insert(0, str(ROOT / "src"))
from taxobridge import PAIRS, N_LABELS
from taxobridge.clinician_prior import build_Z, load_labels
from taxobridge.ot.cost import transport_cost, smoothed_marginal
from taxobridge.ot.sinkhorn import sinkhorn_log
from taxobridge.ot.suppression import suppression_bounds

EPS, TAU, LAM, DELTA = 0.1, 0.1, 0.5, 0.2


def run(seed=13):
    log = Logger("fig6_proposition2")
    rng = np.random.default_rng(seed)
    Z = build_Z()
    names = load_labels()
    marg = {a: smoothed_marginal(rng.multinomial(2000, np.ones(N_LABELS[a]) / N_LABELS[a]))
            for a in ("P", "D", "M")}

    all_points = []
    violations = 0
    balanced_ok = True
    prec_at_1 = {}
    # ordered pairs (both directions)
    ordered = [(a, b) for (a, b) in PAIRS] + [(b, a) for (a, b) in PAIRS]
    for (a, b) in ordered:
        Zab = Z[(a, b)] if (a, b) in Z else Z[(b, a)].T
        cos = np.where(Zab > 0, rng.uniform(0.6, 1.0, Zab.shape),
                       rng.uniform(-0.2, 0.6, Zab.shape))
        C = transport_cost(None, None, Zab, LAM, cos=cos)
        res = sinkhorn_log(C, marg[a], marg[b], EPS, TAU, R=20)
        bnd = suppression_bounds(C, marg[a], res, EPS, TAU)
        share, lo, hi = bnd["share"], bnd["lower"], bnd["upper"]
        # bound check
        v = int(np.sum((share < lo - 1e-9) | (share > hi + 1e-9)))
        violations += v
        # balanced transport: tau -> inf  (share == 1)
        res_bal = sinkhorn_log(C, marg[a], marg[b], EPS, 1e7, R=400)
        share_bal = res_bal.T.sum(axis=1) / marg[a]
        if not np.allclose(share_bal, 1.0, atol=1e-2):
            balanced_ok = False
        # precision@1: partnered source labels send largest row entry to partner
        A_rows = res.T / res.T.sum(axis=1, keepdims=True)
        hits = total = 0
        for i in range(N_LABELS[a]):
            partners = np.flatnonzero(Zab[i] > 0)
            if partners.size == 0:
                continue
            total += 1
            if int(np.argmax(A_rows[i])) in partners.tolist():
                hits += 1
        prec_at_1[f"{a}{b}"] = (hits / total) if total else None

        for i in range(N_LABELS[a]):
            all_points.append({
                "pair": f"{a}{b}", "label": names[a][i],
                "share": float(share[i]), "lower": float(lo[i]), "upper": float(hi[i]),
                "cheapest_cost": float(bnd["chi"][i]),
                "suppressed": bool(share[i] < DELTA),
                "has_prior_partner": bool(Zab[i].sum() > 0),
            })
        n_supp = int(np.sum(share < DELTA))
        log.line(f"{a}->{b}: {N_LABELS[a]} labels, {n_supp} below delta={DELTA}, "
                 f"prec@1={prec_at_1[f'{a}{b}']}, bound violations={v}")
        log.event("pair_done", pair=f"{a}{b}", n_suppressed=n_supp,
                  prec_at_1=prec_at_1[f"{a}{b}"], violations=v)

    log.line("")
    log.line(f"Total bound violations over {len(all_points)} source-label instances: {violations}")
    log.line(f"All shares equal 1 under balanced transport: {balanced_ok}")
    log.line(f"precision@1 of learned plans vs prior partners: "
             f"{ {k: v for k, v in prec_at_1.items() if v is not None} }")
    log.save_result({"points": all_points, "violations": violations,
                     "balanced_all_one": balanced_ok, "precision_at_1": prec_at_1,
                     "delta": DELTA}, "fig6_proposition2.json")
    log.close()


if __name__ == "__main__":
    run()

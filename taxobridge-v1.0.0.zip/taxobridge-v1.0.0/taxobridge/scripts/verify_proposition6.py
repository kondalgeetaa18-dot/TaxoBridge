"""Numerical check of Proposition 6 on synthetic costs (Table X, Section V-B).

Procedure (verbatim from the paper):
  * 12 settings of (eps, tau); 500 instances each; 3 pairs -> 18,000 plans.
  * each instance draws three marginals by Eq (18) from 2,000 random label
    counts, and draws cosines either uniformly on [-1,1] or (alternate
    instances) from [0.6,1] for pairs in Z^{ab} and [-0.2,0.6] otherwise.
  * cost by Eq (19) with lambda=0.5 and the complete prior of Table IV.
  * exact plan by iterating until Upsilon_R < 1e-14.
  * at R=20 record: observed E_20, a-priori Ehat_20, a-posteriori Ebar_20,
    relative l1 distance; R by rule (26) and E_R at that R.
  * assert: no bound violated; gradient residual <= eps*E_R; masks (delta=0.2)
    of the R-step plan match the exact plan for R>=10.

Prints and saves a Table-X-style summary (largest value over the 1,500 plans of
each setting). Reproduces the paper's procedure; exact magnitudes depend on the
random draws but every asserted property must hold.
"""
from __future__ import annotations

import argparse
import sys
import time

import numpy as np

from _common import Logger, ROOT  # noqa: E402

sys.path.insert(0, str(ROOT / "src"))
from taxobridge import N_LABELS, PAIRS  # noqa: E402
from taxobridge.clinician_prior import build_Z  # noqa: E402
from taxobridge.ot.cost import transport_cost, smoothed_marginal  # noqa: E402
from taxobridge.ot.sinkhorn import sinkhorn_log, exact_plan  # noqa: E402
from taxobridge.ot.certificate import (  # noqa: E402
    a_priori_bound, a_posteriori_bound, gradient_residual,
    iterations_rule, error_vs_exact,
)
from taxobridge.transfer.masks import masks  # noqa: E402

SETTINGS = [
    (0.05, 0.05), (0.05, 0.1), (0.05, 0.5), (0.05, 1.0),
    (0.1, 0.05), (0.1, 0.1), (0.1, 0.5), (0.1, 1.0),
    (0.5, 0.05), (0.5, 0.1), (0.5, 0.5), (0.5, 1.0),
]
LAM = 0.5
DELTA = 0.2
E_TOL = 1e-6
# Floating-point floor (paper: "Entries below 1e-12 lie at the floating-point
# floor"). Below it, observed error and bounds are both numerically zero, so a
# comparison is not meaningful and is not counted as a violation.
FP_FLOOR = 1e-12


def draw_marginals(rng):
    m = {}
    for a in ("P", "D", "M"):
        counts = rng.multinomial(2000, np.ones(N_LABELS[a]) / N_LABELS[a])
        m[a] = smoothed_marginal(counts)
    return m


def draw_cos(rng, Z, a, b, structured):
    Na, Nb = N_LABELS[a], N_LABELS[b]
    if structured:
        cos = np.where(Z[(a, b)] > 0,
                       rng.uniform(0.6, 1.0, (Na, Nb)),
                       rng.uniform(-0.2, 0.6, (Na, Nb)))
    else:
        cos = rng.uniform(-1.0, 1.0, (Na, Nb))
    return cos


def rel_l1(T_R, T_star):
    return float(np.sum(np.abs(T_R - T_star)) / np.sum(np.abs(T_star)))


def run(n_instances=500, seed=13):
    log = Logger("table10_proposition6")
    log.line(f"Proposition 6 numerical check: {n_instances} instances x 3 pairs "
             f"x {len(SETTINGS)} settings = {n_instances*3*len(SETTINGS)} plans\n")
    rng = np.random.default_rng(seed)
    Z = build_Z()

    header = (f"{'eps':>5} {'tau':>5} {'omega':>6} | {'E20_obs':>9} {'E20_hat':>9} "
              f"{'E20_bar':>9} {'rel_l1':>9} | {'R(26)':>5} {'E_R@R':>9} | "
              f"{'viol':>5} {'mask!=5':>7} {'mask!=10':>8} {'mask!=20':>8}")
    log.line(header)
    log.line("-" * len(header))

    table = []
    total_viol = 0
    total_grad_viol = 0
    t0 = time.time()

    for (eps, tau) in SETTINGS:
        omega = tau / (tau + eps)
        # rule (26) uses marginals; it is (very weakly) data-dependent via pi_min.
        # Compute a representative R using typical smoothed marginals.
        agg = {"E20_obs": 0.0, "E20_hat": 0.0, "E20_bar": 0.0, "rel_l1": 0.0,
               "R": 0, "E_R": 0.0, "grad_ratio": 0.0}
        mask_mismatch = {5: 0, 10: 0, 20: 0}
        n_viol = 0
        R_rule_max = 20
        for it in range(n_instances):
            structured = (it % 2 == 1)
            marg = draw_marginals(rng)
            R_rule = iterations_rule(
                {p: (marg[p[0]], marg[p[1]]) for p in PAIRS},
                eps, tau, LAM, E_TOL)
            R_rule_max = max(R_rule_max, R_rule)
            for (a, b) in PAIRS:
                cos = draw_cos(rng, Z, a, b, structured)
                C = transport_cost(None, None, Z[(a, b)], LAM, cos=cos)
                pa, pb = marg[a], marg[b]
                # exact plan
                ex = exact_plan(C, pa, pb, eps, tau, tol=1e-14)
                Tstar = ex.T
                # R=20 plan
                r20 = sinkhorn_log(C, pa, pb, eps, tau, R=20)
                E20 = error_vs_exact(r20.T, Tstar)
                E20_hat = a_priori_bound(float(pa.min()), float(pb.min()),
                                         N_LABELS[a], N_LABELS[b], eps, tau, LAM, 20)
                E20_bar = a_posteriori_bound(r20.upsilon, eps, tau)
                rl1 = rel_l1(r20.T, Tstar)
                grad = gradient_residual(r20, C, pa, eps, tau)

                # bound checks: a violation counts only above the fp floor,
                # where the observed error is numerically meaningful.
                if E20 > FP_FLOOR:
                    if (E20 > E20_hat * (1 + 1e-6) or E20 > E20_bar * (1 + 1e-6)):
                        n_viol += 1
                    if grad > eps * E20_bar * (1 + 1e-6) + FP_FLOOR:
                        total_grad_viol += 1

                # R-by-rule plan and its error
                r_rule = sinkhorn_log(C, pa, pb, eps, tau, R=R_rule)
                E_at_R = error_vs_exact(r_rule.T, Tstar)

                # mask agreement at R in {5,10,20} vs exact
                I_star, _ = masks(Tstar, pa, pb, DELTA)
                for R_chk in (5, 10, 20):
                    rr = sinkhorn_log(C, pa, pb, eps, tau, R=R_chk)
                    I_r, _ = masks(rr.T, pa, pb, DELTA)
                    if not np.array_equal(I_r, I_star):
                        mask_mismatch[R_chk] += 1

                agg["E20_obs"] = max(agg["E20_obs"], E20)
                agg["E20_hat"] = max(agg["E20_hat"], E20_hat)
                agg["E20_bar"] = max(agg["E20_bar"], E20_bar)
                agg["rel_l1"] = max(agg["rel_l1"], rl1)
                agg["R"] = max(agg["R"], R_rule)
                agg["E_R"] = max(agg["E_R"], E_at_R)

        total_viol += n_viol
        row = {
            "eps": eps, "tau": tau, "omega": round(omega, 3),
            "E20_obs_max": agg["E20_obs"], "E20_hat_max": agg["E20_hat"],
            "E20_bar_max": agg["E20_bar"], "rel_l1_max": agg["rel_l1"],
            "R_by_rule": agg["R"], "E_at_R_max": agg["E_R"],
            "violations": n_viol,
            "mask_mismatch_R5": mask_mismatch[5],
            "mask_mismatch_R10": mask_mismatch[10],
            "mask_mismatch_R20": mask_mismatch[20],
        }
        table.append(row)
        log.line(f"{eps:>5} {tau:>5} {omega:>6.3f} | "
                 f"{agg['E20_obs']:>9.1e} {agg['E20_hat']:>9.1e} "
                 f"{agg['E20_bar']:>9.1e} {agg['rel_l1']:>9.1e} | "
                 f"{agg['R']:>5d} {agg['E_R']:>9.1e} | "
                 f"{n_viol:>5d} {mask_mismatch[5]:>7d} {mask_mismatch[10]:>8d} "
                 f"{mask_mismatch[20]:>8d}")
        log.event("setting_done", **row)

    elapsed = time.time() - t0
    log.line("")
    log.line(f"TOTAL bound violations over {n_instances*3*len(SETTINGS)} plans: {total_viol}")
    log.line(f"TOTAL gradient-residual violations: {total_grad_viol}")
    log.line(f"Masks agree with exact for R>=10 in every instance: "
             f"{all(r['mask_mismatch_R10'] == 0 for r in table)}")
    log.line(f"elapsed: {elapsed:.1f}s")
    log.save_result({"settings": table, "n_instances": n_instances,
                     "total_plans": n_instances * 3 * len(SETTINGS),
                     "total_bound_violations": total_viol,
                     "total_gradient_violations": total_grad_viol,
                     "lambda": LAM, "delta": DELTA, "E_tol": E_TOL,
                     "elapsed_s": elapsed}, "table10_proposition6.json")
    log.close()
    return table, total_viol


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--instances", type=int, default=500,
                    help="instances per setting (paper uses 500)")
    ap.add_argument("--seed", type=int, default=13)
    a = ap.parse_args()
    run(a.instances, a.seed)

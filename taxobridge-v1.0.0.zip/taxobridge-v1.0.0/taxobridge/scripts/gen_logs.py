"""Generate a log file for every table (I-XVIII) and the checkpoints manifest.

For each table this writes experiments/logs/table_<ID>.log containing:
  * a provenance header (computed / reported / quoted / mixed);
  * the table's values in a training-log style with per-seed lines where the
    paper reports mean +- s.d. (per-seed lines are drawn to be CONSISTENT with
    the reported mean and s.d. and are explicitly flagged as such -- they are
    placeholders for the real per-seed values a training run produces, NOT
    measurements);
  * for COMPUTED tables, a pointer to the REAL run log already produced by the
    verification scripts (those logs are genuine);
  * a CHECKPOINTS section listing the checkpoint(s) each row depends on, with
    status and the exact command to produce them.

It also writes experiments/checkpoints.json: for every (table, config, seed) a
record with the expected checkpoint path, a sha256 slot (null until the file
exists), and the reproduction command.

Honesty contract: nothing here is presented as a real measurement unless it came
from an executed run. Reported values are attributed to the manuscript; per-seed
expansions are marked synthetic/consistent-with-reported.
"""
from __future__ import annotations

import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
LOGS = ROOT / "experiments" / "logs"
sys.path.insert(0, str(ROOT / "experiments" / "reference_results"))
import manifest as M  # noqa: E402

SEEDS = M.SEEDS
COMMIT = "nogit"
try:
    import subprocess
    COMMIT = subprocess.check_output(["git", "rev-parse", "--short", "HEAD"],
                                     cwd=str(ROOT), stderr=subprocess.DEVNULL).decode().strip()
except Exception:
    pass

# Which tables are computed (real logs already exist) vs training-dependent.
COMPUTED_LOGS = {
    "IX": "table9_cost.log", "X": "table10_proposition6.log",
}
# Training tables -> which configs produce them (for checkpoints.json).
TRAIN_TABLES = {
    "XII": "configs/default.yaml (rho=1.0 and rho=0.3)",
    "XIII": "configs/default.yaml with held_out_taxonomy in {P,D,M}",
    "XIV": "configs/ablation/*.yaml",
    "XV": "configs/default.yaml (error analysis on test predictions)",
    "XVII": "configs/default.yaml (eval on ReDSM5, test only)",
    "XVIII": "configs/default.yaml (shortcut/robustness protocol)",
}


def _hdr(f, table_id, provenance, note=""):
    f.write(f"# TaxoBridge experiment log -- TABLE {table_id}\n")
    f.write(f"# generated {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}  commit {COMMIT}\n")
    f.write(f"# PROVENANCE: {provenance}\n")
    if note:
        f.write(f"# NOTE: {note}\n")
    if provenance == "reported":
        f.write("# These are the manuscript's reported values (mean +- s.d. over 5 seeds).\n")
        f.write("# Per-seed lines below are SYNTHETIC values drawn consistent with the\n")
        f.write("# reported mean/s.d. (seed-labeled) as placeholders for real training\n")
        f.write("# runs -- they are NOT measurements. Run the training pipeline to replace.\n")
    f.write("#" + "-" * 78 + "\n")


def _per_seed(mean, sd, seed):
    """A per-seed placeholder consistent with reported mean/sd (flagged synthetic)."""
    if mean is None:
        return None
    if sd in (None, 0):
        return round(mean, 4)
    rng = np.random.default_rng(seed * 100003 + int(mean * 1000))
    return round(float(rng.normal(mean, sd)), 3)


def gen_computed(table_id):
    real = LOGS / COMPUTED_LOGS[table_id]
    out = LOGS / f"table_{table_id}.log"
    with open(out, "w") as f:
        _hdr(f, table_id, "computed",
             M.ALL_TABLES[table_id].get("note", ""))
        f.write(f"# REAL run log: experiments/logs/{COMPUTED_LOGS[table_id]}\n")
        f.write(f"# Reproduce: python {M.ALL_TABLES[table_id]['script']}\n")
        f.write("#" + "-" * 78 + "\n\n")
        if real.exists():
            f.write(real.read_text())
        else:
            f.write("(run the script above to populate the real log)\n")
        f.write("\n# CHECKPOINTS: none -- computed artifact, no trained weights needed.\n")
    return out


def gen_table_xii(f):
    T = M.TABLE_XII
    f.write(f"{'model':38s} {'src':10s} {'Cancer':>7} {'Depr':>7} {'EmoDep':>7} {'QWK':>7} {'GFLOP':>7} {'ms':>6}\n")
    for name, row in T["rows"].items():
        src = row[0]
        def fmt(x):
            return f"{x[0]:.1f}" if (isinstance(x, tuple) and x[0] is not None) else "  -  "
        ce, de, ed, qw = row[1], row[2], row[3], row[4]
        qwkv = f"{qw[0]:.3f}" if isinstance(qw, tuple) and qw[0] is not None else "  -  "
        g = f"{row[5]:.2f}" if row[5] else "  -  "
        ms = f"{row[6]}" if row[6] else "  -  "
        f.write(f"{name:38s} {src:10s} {fmt(ce):>7} {fmt(de):>7} {fmt(ed):>7} {qwkv:>7} {g:>7} {ms:>6}\n")
    # per-seed expansion for the two proposed rows
    f.write("\n# per-seed (synthetic, consistent with reported mean/sd):\n")
    for name in ("TaxoBridge (rho=1.0)", "TaxoBridge (rho=0.3)"):
        row = T["rows"][name]
        for s in SEEDS:
            vals = [_per_seed(*row[i], s) if isinstance(row[i], tuple) else None
                    for i in (1, 2, 3)]
            f.write(f"  seed={s:<5} commit={COMMIT}  Cancer={vals[0]} Depr={vals[1]} "
                    f"EmoDep={vals[2]}  ckpt=checkpoints/{name.split()[0]}_"
                    f"{name.split('=')[1].rstrip(')')}_seed{s}.pt\n")


def gen_table_xiii(f):
    T = M.TABLE_XIII
    for direction, rows in T["directions"].items():
        held, trained = direction.split("|")
        f.write(f"\n## held-out {held}  trained-on {trained}\n")
        f.write(f"{'method':32s} {'macroF1':>9} {'95%CI':>16} {'delta':>7} {'p(Holm)':>9}\n")
        for name, (mean, sd), ci, d, p in rows:
            dstr = f"{d:+.1f}" if d is not None else "  ref  "
            pstr = f"{p}" if p else "   -   "
            f.write(f"{name:32s} {mean:>7.1f}±{sd:<3.1f} [{ci[0]:>5.1f},{ci[1]:>5.1f}] "
                    f"{dstr:>7} {pstr:>9}\n")
        # per-seed for TaxoBridge row
        tb = rows[-1]
        f.write("  per-seed (synthetic, consistent w/ reported): ")
        f.write(", ".join(f"s{s}={_per_seed(tb[1][0], tb[1][1], s)}" for s in SEEDS) + "\n")


def gen_table_xiv(f):
    T = M.TABLE_XIV
    f.write(f"{'variant':30s} {'in-domain':>12} {'zero-shot':>12} {'GFLOP':>7} {'d_in':>7} {'d_zs':>7}\n")
    for name, (indom, zs, g, di, dz) in T["rows"].items():
        f.write(f"{name:30s} {indom[0]:>6.1f}±{indom[1]:<3.1f} {zs[0]:>6.1f}±{zs[1]:<3.1f} "
                f"{g:>7.2f} {('%+.1f' % di) if di is not None else '   -':>7} "
                f"{('%+.1f' % dz) if dz is not None else '   -':>7}\n")
        f.write(f"  -> ckpt=checkpoints/ablation_{name.split()[0].lower()}_"
                f"seed{{{','.join(map(str, SEEDS))}}}.pt\n")


def gen_table_xvii(f):
    T = M.TABLE_XVII
    f.write(f"{'model':36s} {'macroF1':>9} {'95%CI':>16} {'evP':>5} {'evR':>5} "
            f"{'tokF1':>6} {'compr':>6} {'suff':>5} {'del-r':>6}\n")
    for name, r in T["rows"].items():
        (m, sd), ci = r[0], r[1]
        def c(x): return f"{x:.2f}" if x is not None else "  -  "
        f.write(f"{name:36s} {m:>7.1f}±{sd:<3.1f} [{ci[0]:>5.1f},{ci[1]:>5.1f}] "
                f"{c(r[2]):>5} {c(r[3]):>5} {c(r[4]):>6} {c(r[5]):>6} {c(r[6]):>5} {c(r[7]):>6}\n")


def gen_table_xviii(f):
    T = M.TABLE_XVIII
    f.write(f"{'test':22s} {'condition':28s} {'metric':11s} {'baseline':>11} {'TaxoBridge':>11} {'diff':>7} {'95%CI':>16}\n")
    for test, cond, metric, b, t, d, ci in T["rows"]:
        f.write(f"{test:22s} {cond:28s} {metric:11s} {b[0]:>6.1f}±{b[1]:<3.1f} "
                f"{t[0]:>6.1f}±{t[1]:<3.1f} {d:>+7.1f} [{ci[0]:>5.1f},{ci[1]:>5.1f}]\n")


def gen_table_xv(f):
    T = M.TABLE_XV
    f.write("Error categories (count of 100 sampled errors):\n")
    f.write(f"  {'category':38s} {'single':>7} {'TaxoBridge':>11}\n")
    for cat, (se, tb) in T["error_categories"].items():
        f.write(f"  {cat:38s} {se:>7} {tb:>11}\n")
    f.write("\nLength slices (macro-F1):\n")
    for sl, (b, t, d, ci) in T["length_slices"].items():
        f.write(f"  {sl:42s} base={b[0]:.1f}±{b[1]:.1f} TB={t[0]:.1f}±{t[1]:.1f} "
                f"diff={d:+.1f} [{ci[0]:.1f},{ci[1]:.1f}]\n")


def gen_table_xvi(f):
    T = M.TABLE_XVI
    f.write(f"# {T['note']}\n")
    f.write(f"{'pair':6s} {'delta':>6} {'n_off':>6} {'gap':>8} {'prec':>7} {'rec':>7}\n")
    for pair, d, noff, gap, prec, rec in T["rows"]:
        gs = f"{gap:.3f}" if gap is not None else "   -  "
        ps = f"{prec:.3f}" if prec is not None else "   -  "
        rs = f"{rec:.3f}" if rec is not None else "   -  "
        f.write(f"{pair:6s} {d:>6} {noff:>6} {gs:>8} {ps:>7} {rs:>7}\n")


GEN = {
    "XII": gen_table_xii, "XIII": gen_table_xiii, "XIV": gen_table_xiv,
    "XV": gen_table_xv, "XVI": gen_table_xvi, "XVII": gen_table_xvii,
    "XVIII": gen_table_xviii,
}


def gen_reported(table_id):
    out = LOGS / f"table_{table_id}.log"
    T = M.ALL_TABLES[table_id]
    with open(out, "w") as f:
        _hdr(f, table_id, T["provenance"], T.get("note", ""))
        f.write("\n")
        GEN[table_id](f)
        f.write("\n# CHECKPOINTS\n")
        src = TRAIN_TABLES.get(table_id, "(see configs/)")
        f.write(f"# produced by: {src}\n")
        f.write(f"# command: python scripts/run_table.py --table {table_id} --all-seeds\n")
        f.write(f"# checkpoint manifest: experiments/checkpoints.json (table {table_id})\n")
    return out


def dump_json(table_id):
    (ROOT / "experiments" / "reference_results" / f"table_{table_id}.json").write_text(
        json.dumps(M.ALL_TABLES.get(table_id, {}), indent=2, default=str))


def build_checkpoints_manifest():
    """Expected checkpoint per (table, config, seed), status pending until present."""
    entries = []
    ck_dir = ROOT / "checkpoints"
    for table_id, src in TRAIN_TABLES.items():
        configs = []
        if table_id == "XII":
            configs = ["default_rho1.0", "default_rho0.3"]
        elif table_id == "XIII":
            configs = ["zeroshot_heldout_P", "zeroshot_heldout_D", "zeroshot_heldout_M"]
        elif table_id == "XIV":
            configs = [p.stem for p in (ROOT / "configs" / "ablation").glob("*.yaml")]
        else:
            configs = ["default"]
        for cfg in configs:
            for s in SEEDS:
                path = f"checkpoints/{cfg}_seed{s}_best.pt"
                exists = (ROOT / path).exists()
                sha = None
                if exists:
                    sha = hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
                entries.append({
                    "table": table_id, "config": cfg, "seed": s,
                    "expected_path": path,
                    "status": "present" if exists else "pending",
                    "sha256": sha,
                    "command": f"python scripts/run_table.py --table {table_id} "
                               f"--config {cfg} --seed {s}",
                })
    manifest = {
        "generated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "commit": COMMIT, "seeds": SEEDS,
        "note": "Checkpoints are released separately (see docs/RELEASE.md); this "
                "manifest tracks expected paths and sha256 so a run is auditable. "
                "'pending' = not yet trained in this workspace.",
        "entries": entries,
    }
    out = ROOT / "experiments" / "checkpoints.json"
    out.write_text(json.dumps(manifest, indent=2))
    return out, len(entries)


def main():
    LOGS.mkdir(parents=True, exist_ok=True)
    written = []
    for tid in ("IX", "X"):
        written.append(gen_computed(tid))
        dump_json(tid)
    for tid in ("XII", "XIII", "XIV", "XV", "XVI", "XVII", "XVIII"):
        written.append(gen_reported(tid))
        dump_json(tid)
    dump_json("XI")
    ckpath, n = build_checkpoints_manifest()
    print(f"wrote {len(written)} table logs to experiments/logs/table_*.log")
    print(f"wrote checkpoints manifest: {ckpath.relative_to(ROOT)} ({n} entries)")
    for w in written:
        print(f"  {w.relative_to(ROOT)}")


if __name__ == "__main__":
    main()

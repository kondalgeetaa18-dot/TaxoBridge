"""Threshold sweep over delta (Table XVI) — computed structural part.

For each ordered pair and delta in {0, 0.05, 0.1, 0.2, 0.3, 0.5} reports the
number of suppressed source labels n_off and the suppression gap (Eq 30,
Section IV-F). Transfer precision/recall need the cross-annotated subset; when
data/processed/cross_annotated.jsonl is present they are computed too, otherwise
flagged as data-dependent.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

from _common import Logger, ROOT

sys.path.insert(0, str(ROOT / "src"))
from taxobridge import PAIRS, N_LABELS
from taxobridge.clinician_prior import build_Z
from taxobridge.ot.cost import transport_cost, smoothed_marginal
from taxobridge.ot.sinkhorn import sinkhorn_log
from taxobridge.transfer.masks import n_suppressed, suppression_gap

EPS, TAU, LAM = 0.1, 0.1, 0.5
DELTAS = [0.0, 0.05, 0.1, 0.2, 0.3, 0.5]


def run(seed=13):
    log = Logger("table16_threshold_sweep")
    rng = np.random.default_rng(seed)
    Z = build_Z()
    marg = {a: smoothed_marginal(rng.multinomial(2000, np.ones(N_LABELS[a]) / N_LABELS[a]))
            for a in ("P", "D", "M")}

    plans = {}
    for (a, b) in PAIRS:
        cos = np.where(Z[(a, b)] > 0, rng.uniform(0.6, 1.0, Z[(a, b)].shape),
                       rng.uniform(-0.2, 0.6, Z[(a, b)].shape))
        C = transport_cost(None, None, Z[(a, b)], LAM, cos=cos)
        T = sinkhorn_log(C, marg[a], marg[b], EPS, TAU, R=20).T
        plans[(a, b)] = (T, marg[a], marg[b])
        plans[(b, a)] = (T.T, marg[b], marg[a])

    ca_present = (Path(ROOT) / "data" / "processed" / "cross_annotated.jsonl").exists()
    log.line(f"{'pair':>5} {'delta':>5} {'n_off':>5} {'gap':>8}   prec/rec")
    log.line("-" * 40)
    rows = []
    ordered = [("P", "D"), ("P", "M"), ("D", "M")]
    for (a, b) in ordered:
        T, pa, pb = plans[(a, b)]
        for d in DELTAS:
            noff = n_suppressed(T, pa, d)
            gap = suppression_gap(T, pa, d)
            gstr = f"{gap:.3f}" if gap is not None else "   -  "
            pr = "data-dependent" if not ca_present else "computed"
            log.line(f"{a}->{b:>2} {d:>5} {noff:>5} {gstr:>8}   {pr}")
            rows.append({"pair": f"{a}{b}", "delta": d, "n_off": noff,
                         "gap": gap})
    log.line("")
    log.line("n_off and gap are reproducible from the released prior and plans. "
             "Transfer precision/recall (Table XVI cols Prec/Rec) require the "
             "300-post cross-annotated subset: " +
             ("present -> computed." if ca_present else "not present -> see data/README.md."))
    log.save_result({"rows": rows, "deltas": DELTAS,
                     "cross_annotated_present": ca_present}, "table16_threshold_sweep.json")
    log.close()


if __name__ == "__main__":
    run()

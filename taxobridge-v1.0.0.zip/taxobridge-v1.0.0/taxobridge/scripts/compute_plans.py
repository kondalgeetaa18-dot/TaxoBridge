"""Compute and save the transport plans for the three taxonomy pairs (Fig 4).

The plans T* depend on the trained label queries and the real label marginals.
This script computes:
  * the PRIOR-ALONE plans T^{ab}_prior (lambda=0, run to convergence) — fully
    determined by the released clinician prior, so exactly reproducible now;
  * the plans under the default cost with queries loaded from --queries (a .npz
    of per-taxonomy query matrices produced by a trained checkpoint) and
    marginals from --marginals, when provided.

Row-normalized plans and the hatched (suppressed) rows at delta=0.2 are saved
for the Fig 4 rendering and for audit (Section VII-F).
"""
from __future__ import annotations

import argparse
import sys

import numpy as np

from _common import Logger, ROOT

sys.path.insert(0, str(ROOT / "src"))
from taxobridge import PAIRS, N_LABELS
from taxobridge.clinician_prior import build_Z, load_labels
from taxobridge.ot.cost import transport_cost, smoothed_marginal
from taxobridge.ot.sinkhorn import sinkhorn_log, exact_plan
from taxobridge.transfer.masks import masks

EPS, TAU, DELTA = 0.1, 0.1, 0.2


def run(queries_npz=None, marginals_npz=None, lam=0.5, seed=13):
    log = Logger("fig4_plans")
    names = load_labels()
    Z = build_Z()

    if marginals_npz:
        mz = np.load(marginals_npz)
        marg = {a: mz[a] for a in ("P", "D", "M")}
        log.line(f"marginals: loaded from {marginals_npz}")
    else:
        rng = np.random.default_rng(seed)
        marg = {a: smoothed_marginal(rng.multinomial(2000, np.ones(N_LABELS[a]) / N_LABELS[a]))
                for a in ("P", "D", "M")}
        log.line("marginals: synthetic (real marginals come from --marginals)")

    queries = None
    if queries_npz:
        qz = np.load(queries_npz)
        queries = {a: qz[a] for a in ("P", "D", "M")}
        log.line(f"queries: loaded from {queries_npz} (trained)")
    else:
        log.line("queries: none -> computing PRIOR-ALONE plans (lambda=0, exact), "
                 "which are fully reproducible from the released prior.")

    out = {}
    for (a, b) in PAIRS:
        # prior-alone plan (lambda=0): cost = C_prior exactly
        Cp = transport_cost(None, None, Z[(a, b)], 0.0,
                            cos=np.zeros((N_LABELS[a], N_LABELS[b])))
        prior_plan = exact_plan(Cp, marg[a], marg[b], EPS, TAU).T
        entry = {"prior_plan_row_normalized":
                 (prior_plan / prior_plan.sum(1, keepdims=True)).tolist()}
        if queries is not None:
            C = transport_cost(queries[a], queries[b], Z[(a, b)], lam)
            T = sinkhorn_log(C, marg[a], marg[b], EPS, TAU, R=20).T
            Imask, _ = masks(T, marg[a], marg[b], DELTA)
            entry["learned_plan_row_normalized"] = (T / T.sum(1, keepdims=True)).tolist()
            entry["suppressed_rows"] = [names[a][i] for i in np.flatnonzero(~Imask)]
        out[f"{a}->{b}"] = entry
        log.line(f"pair {a}->{b}: prior-alone plan computed"
                 + ("; learned plan computed" if queries is not None else ""))

    log.save_result({"pairs": out, "labels": names, "eps": EPS, "tau": TAU,
                     "delta": DELTA, "lambda": lam,
                     "queries_provided": queries is not None,
                     "marginals_provided": marginals_npz is not None},
                    "fig4_plans.json")
    log.close()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--queries", default=None, help=".npz with trained queries per taxonomy")
    ap.add_argument("--marginals", default=None, help=".npz with real marginals per taxonomy")
    ap.add_argument("--lam", type=float, default=0.5)
    a = ap.parse_args()
    run(a.queries, a.marginals, a.lam)

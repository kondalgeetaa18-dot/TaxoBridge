"""Dispatch the training/eval runs that produce a given manuscript table.

This is the single entry point the per-table logs point to. It maps a table ID
to the configs and seeds it needs, trains each (taxobridge.train), evaluates
(eval/*), runs the statistics (eval/stats.py) and writes the real per-table log,
overwriting the reference placeholder. Requires torch + the corpora.

    python scripts/run_table.py --table XII --all-seeds
    python scripts/run_table.py --table XIII --held-out D --seed 42
    python scripts/run_table.py --table XIV --config balanced_transport

Without torch/data present it prints the exact plan of runs (a dry run), so the
reproduction path is always inspectable.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

SEEDS = [13, 42, 87, 1234, 2024]

TABLE_PLAN = {
    "XII": {"configs": ["default"], "variants": ["rho=1.0", "rho=0.3"],
            "eval": "in-domain per corpus (CancerEmo, DepressionEmo, EmoDep)"},
    "XIII": {"configs": ["default"], "held_out": ["P", "D", "M"],
             "eval": "zero-shot on cross-annotated subset"},
    "XIV": {"configs": "ablation/*", "eval": "in-domain + zero-shot averages"},
    "XV": {"configs": ["default"], "eval": "error-category + length-slice analysis"},
    "XVII": {"configs": ["default"], "eval": "ReDSM5 external (classification+evidence)"},
    "XVIII": {"configs": ["default"], "eval": "shortcut/robustness protocol"},
}


def have_torch():
    try:
        import torch  # noqa: F401
        return True
    except Exception:
        return False


def plan(table, seeds, held_out=None, config=None):
    p = TABLE_PLAN[table]
    lines = [f"Plan for Table {table}: {p['eval']}"]
    configs = [config] if config else (
        [c.stem for c in (ROOT / "configs" / "ablation").glob("*.yaml")]
        if p["configs"] == "ablation/*" else p["configs"])
    hos = [held_out] if held_out else p.get("held_out", [None])
    n = 0
    for cfg in configs:
        for ho in hos:
            for s in seeds:
                tag = f"{cfg}" + (f"_heldout{ho}" if ho else "")
                lines.append(f"  train config={cfg} held_out={ho} seed={s} "
                             f"-> checkpoints/{tag}_seed{s}_best.pt")
                n += 1
    lines.append(f"  total runs: {n}")
    return "\n".join(lines)


def run(table, seeds, held_out=None, config=None, dry=False):
    print(plan(table, seeds, held_out, config))
    if dry or not have_torch():
        if not have_torch():
            print("\n[torch not available here] This is a dry run: the plan above is "
                  "exact. Install the 'train' extra and provide the corpora to execute.")
        return
    # real execution path
    from taxobridge.config import Config
    from taxobridge.train import train
    # NOTE: the data-loader assembly (datasets dict, queries_init, marginals) is
    # documented in docs/TRAINING.md; wire your loaders there and call train().
    raise SystemExit("Wire dataset loaders per docs/TRAINING.md, then remove this guard.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--table", required=True, choices=list(TABLE_PLAN))
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--all-seeds", action="store_true")
    ap.add_argument("--held-out", choices=["P", "D", "M"], default=None)
    ap.add_argument("--config", default=None)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    seeds = SEEDS if a.all_seeds else [a.seed or 13]
    run(a.table, seeds, a.held_out, a.config, a.dry_run)

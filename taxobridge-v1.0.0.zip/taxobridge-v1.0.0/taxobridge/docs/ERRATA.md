# Errata / notes found while implementing

These are discrepancies or ambiguities noticed while turning the manuscript
into runnable code. None affects the paper's conclusions; they are recorded so
the code and the text can be reconciled.

## 1. Sinkhorn update exponent (Eq 25 / 42 vs Eq 44 / 61)

Equations (25) and (42) are typeset as

    u <- pi^a  (K v)^(-omega)          [i.e. pi^a to the first power]

but the derivation in Eq (44) gives `u_i = (pi_i^a / (K v)_i)^omega` and the
log-domain map Eq (61) gives `log u = omega (log pi^a - log(K v))`, i.e.

    u = (pi^a / (K v))^omega           [omega covers the whole ratio]

These disagree unless `pi^a` is also raised to `omega`. The second form (Eq 44 /
Eq 61) is the mathematically correct generalized-Sinkhorn step for unbalanced
entropic OT (Chizat et al., 2018) and the one that satisfies the KKT
stationarity condition Eq (43). **The implementation follows Eq 44 / Eq 61.**
Our gradient-residual check (`res_R <= eps * Ebar_R`) and the 18,000-instance
Prop-6 study both confirm the computed plan is the true minimizer, so this is a
typesetting slip in Eq (25)/(42), not an error in the method. Reconcile by
printing Eq (25) as `u <- pi^a_pow_omega / (K v)^omega` or `(pi^a / K v)^omega`.

## 2. Floating-point floor in the Prop-6 check (Table X)

At small omega the a-priori bound `Ehat_R` underflows far below 1e-12 while the
observed error floors at float64 roundoff (~1e-15). The paper notes "entries
below 1e-12 lie at the floating-point floor." Our verifier therefore counts a
bound violation only when the observed error exceeds 1e-12; below the floor the
comparison is not numerically meaningful. With this floor, 0 / 18,000
violations, matching the paper.

## 3. Mask agreement at R=10 (Table X / Section V-B)

The paper states the R-step and exact masks agree for R >= 10 in every
instance. With our random draws we observe this holds in all settings except a
borderline one (eps=0.05, tau=0.1, omega=0.667) where 2 of 1,500 instances
disagree at exactly R=10 (shares sitting on the delta=0.2 boundary). This is a
draw-dependent boundary effect, not a failure of the method; rule (26) raises R
to 24 for that setting, which removes it. Reported honestly in the log.

## 4. Suppression counts in Fig 4 / Section VII-F

The exact per-pair suppressed-label counts (4, 4, 2) come from the TRAINED
label queries. The computed verifier (`verify_proposition2.py`) uses synthetic
definition-cosines, so its suppression counts differ in magnitude while the
mechanism (unmatched labels fall below delta, bounds hold, balanced pins at 1,
precision@1 = 1.0) is reproduced exactly. Pass `--queries` to `compute_plans.py`
with a trained checkpoint's queries to get the paper's exact plan.

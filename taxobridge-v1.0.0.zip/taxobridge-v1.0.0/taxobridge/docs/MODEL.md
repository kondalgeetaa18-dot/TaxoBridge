# Model notes

`taxobridge.model.TaxoBridge` wires the four mechanisms onto a
MentalRoBERTa-base encoder (L=12, d=768). Equation references are to the paper.

## Forward pass

1. Encoder layers 1..L with `output_hidden_states=True` (Eq 4).
2. Gate logits `phi_t = w_g^T h_t^l + b_g` from the layer-`l` state (Eq 6).
3. Expected retained share `B(theta;x)` in closed form (Eq 9, Lemma 2).
4. Training: hard-concrete gate values (Eq 7); inference: deterministic top-k
   keep mask (Eq 11).
5. Sparsemax label attention over the kept tokens, per taxonomy (Eq 12–15), with
   a differentiable sparsemax (custom autograd `Function`).
6. Evidence set `E_k^a = {t: alpha_{k,t}>0}` (Eq 16).
7. Conditional ordinal head for EmoDep intensity (Eq 17).

### Two-segment efficiency note

The reference `forward` runs the full encoder and masks attention to the kept
set, which is correct and simplest. The *budgeted two-segment* variant — run
layers `l+1..L` on the gathered subset only, which is what the FLOP count of
Table IX and Proposition 5 assume — is selected by processing only
`keep_mask`-selected positions through the upper layers. Both give identical
outputs on the kept tokens; the two-segment form realizes the measured speedup.
Implement by gathering `input` to the kept indices after the gate and re-running
the upper stack, or by using a HF encoder that accepts a reduced sequence.

## Ablation flags (Table XIV)

- **Softmax label attention** — replace `sparsemax(...)` with `softmax(...)` in
  `LabelAttentionHead.forward`. Accuracy is unchanged within noise; what is lost
  is the exact evidence set and the Prop-4 stability guarantee.
- **Random label queries** — skip `set_queries` (Eq 5); queries stay at their
  random init.
- **Fixed-penalty gate** — drop the constraint and add `lambda_pen * B` to the
  loss with `lambda_pen` tuned to the same mean budget; this loses the per-post
  top-k guarantee of Eq (11) / Lemma 4.
- **Balanced transport** — `tau -> inf` (configs set `tau: 1e6`); recovers
  balanced entropic OT (Remark 1), so every label is forced to match.

## Numerics (Table VII)

Encoder in bfloat16 mixed precision; sparsemax and heads in float32; Sinkhorn in
float64 in the log domain. The Sinkhorn solve (`taxobridge.ot.sinkhorn`) is always
float64 regardless of the encoder precision, so the plan certificate holds.

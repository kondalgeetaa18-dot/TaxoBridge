# Release v1.0.0

Versioned release accompanying the TaxoBridge manuscript.

## What this release contains

- Full source for all four mechanisms (OT, transfer, sparsemax, token gate),
  the model, losses, primal–dual trainer and inference.
- The clinician alignment prior (Table IV) and authored label definitions.
- Split manifests (IDs + label hashes) and reproducible preprocessing.
- All configs (default + 55 sensitivity + 10 ablation), five seeds.
- Verification scripts for every computed artifact, **with their real logs**.
- 40 unit tests.
- Evaluation + statistics (bootstrap / approximate-randomization / Holm) and the
  efficiency benchmark harness.
- Per-table logs (I–XVIII) and `experiments/checkpoints.json`.

## Model checkpoints

Trained checkpoints are large and are **not** committed to the repo. Release
them as versioned assets attached to the GitHub release / an archival record
(e.g. Zenodo), one per `(config, seed)` as listed in
`experiments/checkpoints.json`. Each asset's sha256 goes back into that manifest
(replacing `null` and flipping `status` to `present`) so a download is auditable.

Minimum useful set to attach:
- `default_rho0.3_seed{13,42,87,1234,2024}_best.pt` (Table XII main result)
- `default_rho1.0_seed*_best.pt` (unpruned)
- `zeroshot_heldout{P,D,M}_seed*_best.pt` (Table XIII)

## Prediction files

For reviewers without the compute to retrain, attach cached predictions
(`preds/<model>_<taxo>.npz` with `y_true`, `y_score`) for TaxoBridge and the
baselines on each test set and on the cross-annotated subset. `eval/evaluate.py`
and `eval/cross_taxonomy.py` read these directly (`--preds`, `--baseline`), so
every table and significance test reproduces from predictions alone.

## Linking to the manuscript

Tag this release `v1.0.0` and cite it from the paper's reproducibility statement
(Section VIII-F). `CITATION.cff` carries the metadata.

## Verifying a fresh clone

```bash
pip install -e ".[dev]"
pytest -q                 # 40 tests pass
make verify               # Tier-A artifacts reproduce (minutes, CPU)
```

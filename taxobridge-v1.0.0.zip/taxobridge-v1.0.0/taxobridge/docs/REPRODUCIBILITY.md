# Reproducibility matrix

Every table and figure, its command, and its provenance. **Computed** rows run
on CPU in minutes and produce the real logs shipped in `experiments/logs/`.
**Trained** rows need the corpora + a GPU; the command trains and evaluates, and
the shipped per-table log holds the manuscript's reported values until then.

| Artifact | What | Command | Provenance | Real log here |
|---|---|---|---|---|
| Table I | Gap→component→theory→experiment map | (narrative; see paper) | — | — |
| Tables II–V | Taxonomies, notation, assumptions, prior, alt-priors | `python -m taxobridge.clinician_prior` (prior) | computed | prior counts verified |
| Table VI/VII | Defaults, optimizer/schedule/hardware | `configs/default.yaml` | config | — |
| Table VIII | Training diagnostics | logged by `taxobridge.train` | trained | per-run JSONL |
| **Table IX** | Encoder cost: FLOPs + CPU timing | `make table9` | **computed** | `table9_cost.log` |
| **Table X** | Prop-6 certificate, 18k instances | `make table10` | **computed** | `table10_proposition6.log` |
| Table XI | Datasets/splits | `python scripts/make_splits.py` | data | manifests |
| Table XII | Main classification | `python scripts/run_table.py --table XII --all-seeds` | trained | `table_XII.log` (reported) |
| Table XIII | Zero-shot cross-taxonomy | `python scripts/run_table.py --table XIII --held-out {P,D,M} --all-seeds` | trained | `table_XIII.log` (reported) |
| Table XIII-a/b | Support, agreement | `data/cross_annotated/{support,agreement}.csv` | released | CSV |
| Table XIV | Ablation | `python scripts/run_table.py --table XIV --config <v> --all-seeds` | trained | `table_XIV.log` (reported) |
| Table XV | Error analysis | `python scripts/run_table.py --table XV` | trained | `table_XV.log` (reported) |
| **Table XVI** | Threshold sweep (n_off, gap) | `make table16` | **computed** (struct.) | `table16_threshold_sweep.log` |
| Table XVI | Prec/Rec columns | with cross-annotated subset | trained | — |
| Table XVI-a | Prop-3 on subset | `python scripts/verify_proposition3.py` (struct.) / with subset (exact) | computed/data | `fig7_proposition3.log` |
| Table XVII/-a | ReDSM5 external + evidence | `python scripts/run_table.py --table XVII` | trained | `table_XVII.log` (reported) |
| Table XVIII | Shortcut & robustness | `python scripts/run_table.py --table XVIII` | trained | `table_XVIII.log` (reported) |
| **Fig 4** | Transport plans | `make fig4` | **computed** (prior-alone; +queries for learned) | `fig4_plans.log` |
| **Fig 5** | Prop-1 convergence/uniqueness | `make fig5` | **computed** | `fig5_proposition1.log` |
| **Fig 6** | Prop-2 suppression | `make fig6` | **computed** | `fig6_proposition2.log` |
| **Fig 7** | Prop-3 non-expansive transfer | `make fig7` | **computed** | `fig7_proposition3.log` |
| Fig 3(a) | Accuracy vs GFLOPs | from Table XII/XIV runs | trained | — |
| Fig 3(b) | Speedup vs rho | `make table9` | **computed** | in `table9_cost.log` |

## One command for all computed artifacts

```bash
make verify
```

runs Figs 4–7, Tables X, XVI and IX, then regenerates the per-table logs and
`checkpoints.json`. Each writes a `.log` (human) and `.jsonl`/`.json` (machine)
with full provenance (versions, commit, timestamp).

## Theory ↔ experiment (Table I)

| Claim | Where proved | Checked by |
|---|---|---|
| Prop 1 unique scaling-form plan | Section V-A | `verify_proposition1.py`, `tests/test_sinkhorn.py` |
| Lemma 1 reversed plan = transpose | Section V-A | `tests/test_sinkhorn.py::test_lemma1_*` |
| Prop 2 / Cor 1 suppression | Section V-A | `verify_proposition2.py`, `tests/test_suppression.py` |
| Prop 3 non-expansive transfer | Section V-A | `verify_proposition3.py`, `tests/test_transfer.py` |
| Lemma 2 differentiable budget | Section V-A | `tests/test_gate.py::test_lemma2_*` |
| Lemma 3 feasibility at saddle | Section V-A | (analysis; empirical via diagnostics) |
| Prop 4 evidence stability | Section V-A | `tests/test_sparsemax.py::test_stability_*` |
| Prop 5 speedup bounds | Section V-A | `benchmark_cost.py`, `tests/test_complexity.py` |
| Prop 6 R-step certificate | Section V-B | `verify_proposition6.py`, `tests/test_sinkhorn.py::test_prop6_*` |
| Lemma 4 dual certificate | Section V-B | `tests/test_gate.py::test_lemma4_*` |

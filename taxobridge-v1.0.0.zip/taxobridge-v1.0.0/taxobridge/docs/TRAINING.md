# Training TaxoBridge (Tier B)

This document describes the data-loader contract and how to run the primal–dual
training of Algorithm 1 to reproduce the trained-model tables (XII–XV, XVII,
XVIII). It requires `torch`, `transformers`, a GPU (the paper uses one A100
80 GB), and the corpora obtained per `data/README.md`.

## 1. Data-loader contract

`taxobridge.train.train(cfg, datasets, queries_init, marginals, ...)` expects:

```python
datasets = {
  "P": {
    "n_train": 6800,
    "sample_train": fn(batch_size) -> batch,   # uniform w/ replacement from D_P
    "val":   iterable_of_batches,              # for per-epoch validation
  },
  "D": {...}, "M": {...},
}
```

A `batch` is a dict of tensors on CPU (moved to device inside the loop):

```python
batch = {
  "taxo": "P",                                 # which corpus this batch is from
  "input_ids":      LongTensor (B, n),
  "attention_mask": LongTensor (B, n),         # 1 for real tokens incl. CLS
  "y":              FloatTensor (B, N_a),      # observed labels of taxonomy a
  "intensity":      FloatTensor (B, 9),        # EmoDep only (criterion levels)
}
```

- `queries_init`: `{"P": (8,768), "D": (8,768), "M": (9,768)}` numpy arrays from
  Eq (5) — mean-pool the encoder over each label's definition text
  (`data/label_definitions/definitions.json`). Helper: see
  `taxobridge.model.LabelAttentionHead.set_queries`.
- `marginals`: `{"P": pi_P, "D": pi_D, "M": pi_M}` smoothed label marginals from
  Eq (18) (`taxobridge.ot.cost.smoothed_marginal`). For a zero-shot direction,
  the held-out taxonomy's marginal is uniform (Section VII-C).

## 2. What the loop does (Algorithm 1)

Each step: rebuild the three transport plans from the current queries (Eq 19,
25), form the transfer operators and masks (Eq 27–28), draw a corpus `a ~ w_a`
and a 32-post minibatch, forward with hard-concrete gating, compute
`L = L_hat + kappa (B_hat - rho)`, AdamW primal step, projected dual ascent on
`kappa`, and log the Table VIII diagnostics. Validation after each epoch uses the
inference (top-k) gate; early stop on mean validation macro-F1 (Table VII); keep
the best checkpoint.

## 3. Commands

```bash
# in-domain (Table XII): default config, both budgets, five seeds
python scripts/run_table.py --table XII --all-seeds

# zero-shot (Table XIII): one held-out taxonomy at a time
python scripts/run_table.py --table XIII --held-out P --all-seeds
python scripts/run_table.py --table XIII --held-out D --all-seeds
python scripts/run_table.py --table XIII --held-out M --all-seeds

# ablations (Table XIV)
for v in configs/ablation/*.yaml; do
  python scripts/run_table.py --table XIV --config $(basename $v .yaml) --all-seeds
done
```

`run_table.py` prints the exact run plan (config × seed → checkpoint path) and,
without torch/data, performs a dry run.

## 4. Settings

Every optimizer/schedule/initialization/precision/hardware setting is fixed in
`configs/default.yaml` (Tables VI/VII). Softmax-attention, random-query,
fixed-penalty-gate and balanced-transport ablations are flags/overrides in
`configs/ablation/`; the two attention/gate variants are model flags (see
`docs/MODEL.md`), the rest are scalar overrides.

## 5. Diagnostics (Table VIII)

The trainer logs, per step and per epoch: budget violation `(B_s-rho)_+`, the
dual certificate (both sides of Eq 65), the multiplier path, complementary
slackness, the validation budget and inference share, primal stationarity, the
Sinkhorn certificate `E_R`, plan approximation vs R∈{50,100,500}, gradient
agreement, retained shares vs the Prop-2 bounds, and the suppression/transfer
quality metrics. These are written to the run's JSONL log.

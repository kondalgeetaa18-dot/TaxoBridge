"""Core evaluation: load a checkpoint, score a test set, emit metrics + stats.

Produces the per-corpus numbers of Table XII and, with --baseline, the paired
comparison (delta macro-F1, 95% bootstrap CI, Holm-adjusted AR p) of
Section VIII-A. Requires torch for the forward pass; the stats are NumPy-only.

Usage:
    python eval/evaluate.py --ckpt checkpoints/default_seed13_best.pt \
        --dataset depressionemo --taxonomy D [--baseline preds/lspcl_D.npz]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "eval"))

from taxobridge.metrics import (  # noqa: E402
    macro_f1, micro_f1, macro_auprc, expected_calibration_error,
    quadratic_weighted_kappa, per_label_f1,
)
import stats as S  # noqa: E402


def load_predictions(path):
    """Load cached predictions {y_true, y_score} from a .npz."""
    z = np.load(path)
    return z["y_true"], z["y_score"]


def score_with_model(ckpt, dataset_jsonl, taxonomy, max_len=512, rho=None):
    """Run the model over a test set and return (y_true, y_score, levels?)."""
    import torch
    from transformers import AutoTokenizer
    from taxobridge.infer import load_model, predict
    from taxobridge.clinician_prior import load_labels
    model = load_model(ckpt)
    tok = AutoTokenizer.from_pretrained(model.cfg.encoder_name)
    labels = load_labels()[taxonomy]
    ys, ss = [], []
    recs = [json.loads(l) for l in open(dataset_jsonl)]
    for i in range(0, len(recs), 32):
        batch = recs[i:i + 32]
        enc = tok([r["text"] for r in batch], truncation=True, max_length=max_len,
                  padding=True, return_tensors="pt")
        out = predict(model, enc["input_ids"], enc["attention_mask"], rho=rho)
        ss.append(out["s"][taxonomy])
        ys.append(np.array([[r["labels"].get(l, 0) for l in labels] for r in batch]))
    return np.concatenate(ys), np.concatenate(ss)


def evaluate(y_true, y_score, thr=0.5, levels_true=None, levels_pred=None, Ko=4):
    m = {
        "macro_f1": macro_f1(y_true, y_score, thr),
        "micro_f1": micro_f1(y_true, y_score, thr),
        "macro_auprc": macro_auprc(y_true, y_score),
        "ece": expected_calibration_error(y_true, y_score),
        "per_label_f1": per_label_f1(y_true, y_score, thr).tolist(),
    }
    if levels_true is not None:
        m["qwk"] = quadratic_weighted_kappa(levels_true, levels_pred, Ko)
    return m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt")
    ap.add_argument("--preds", help="cached predictions .npz (skips the model)")
    ap.add_argument("--dataset")
    ap.add_argument("--taxonomy", required=True, choices=["P", "D", "M"])
    ap.add_argument("--baseline", help="baseline predictions .npz for comparison")
    ap.add_argument("--rho", type=float, default=None)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()

    if a.preds:
        y_true, y_score = load_predictions(a.preds)
    elif a.ckpt and a.dataset:
        y_true, y_score = score_with_model(a.ckpt, a.dataset, a.taxonomy, rho=a.rho)
    else:
        raise SystemExit("Provide --preds, or --ckpt and --dataset.")

    result = {"taxonomy": a.taxonomy, "metrics": evaluate(y_true, y_score)}
    y_pred = (y_score >= 0.5).astype(int)

    if a.baseline:
        by, bs = load_predictions(a.baseline)
        bp = (bs >= 0.5).astype(int)
        cmp = S.compare_to_baseline(y_true, y_pred, bp, name="vs_baseline")
        result["comparison"] = {
            "delta_macro_f1": cmp.delta, "ci": [cmp.ci_low, cmp.ci_high],
            "p_ar": cmp.p_raw,
        }
    print(json.dumps(result, indent=2, default=float))
    if a.out:
        Path(a.out).write_text(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()

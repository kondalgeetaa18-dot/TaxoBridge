"""Zero-shot cross-taxonomy evaluation (Table XIII), the central experiment.

For a held-out taxonomy, the model is trained on the other two corpora
(configs with held_out_taxonomy set), and the held-out heads receive supervision
only through the transfer operator. Predictions are scored on the 300-post
cross-annotated subset. This script computes macro-F1 per direction, its 95%
bootstrap CI, and the Holm-adjusted AR p-value against the strongest baseline.

Needs: a zero-shot checkpoint per direction and the cross-annotated subset
(data/processed/cross_annotated.jsonl). Baselines are supplied as cached
prediction .npz files (manual remap, shared-encoder remap, LLM few-shot).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "eval"))
import stats as S  # noqa: E402
from taxobridge.metrics import macro_f1  # noqa: E402
from taxobridge.clinician_prior import load_labels  # noqa: E402

DIRECTIONS = {  # held-out -> trained-on
    "P": ("D", "M"), "D": ("P", "M"), "M": ("P", "D"),
}


def load_subset(path, taxonomy):
    labels = load_labels()[taxonomy]
    recs = [json.loads(l) for l in open(path)]
    Y = np.array([[r["labels"].get(l, 0) for l in labels] for r in recs])
    texts = [r["text"] for r in recs]
    return Y, texts


def run(ckpt, held_out, subset, baselines: dict, out=None):
    from taxobridge.infer import load_model, predict
    from transformers import AutoTokenizer
    Y, texts = load_subset(subset, held_out)
    model = load_model(ckpt)
    tok = AutoTokenizer.from_pretrained(model.cfg.encoder_name)
    scores = []
    for i in range(0, len(texts), 32):
        enc = tok(texts[i:i + 32], truncation=True, max_length=512,
                  padding=True, return_tensors="pt")
        out_i = predict(model, enc["input_ids"], enc["attention_mask"])
        scores.append(out_i["s"][held_out])
    y_score = np.concatenate(scores)
    y_pred = (y_score >= 0.5).astype(int)

    result = {"held_out": held_out, "trained_on": DIRECTIONS[held_out],
              "macro_f1": macro_f1(Y, y_score),
              "ci": S.paired_bootstrap_ci(Y, y_pred)}
    comparisons, pvals = {}, []
    for name, npz in baselines.items():
        bp = (np.load(npz)["y_score"] >= 0.5).astype(int)
        c = S.compare_to_baseline(Y, y_pred, bp, name)
        comparisons[name] = {"delta": c.delta, "ci": [c.ci_low, c.ci_high], "p": c.p_raw}
        pvals.append(c.p_raw)
    if pvals:
        holm = S.holm_bonferroni(pvals)
        for (name, _), padj, rej in zip(comparisons.items(), holm["adjusted_p"], holm["reject"]):
            comparisons[name]["p_holm"] = padj
            comparisons[name]["significant"] = rej
    result["comparisons"] = comparisons
    print(json.dumps(result, indent=2, default=float))
    if out:
        Path(out).write_text(json.dumps(result, indent=2, default=float))
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--held-out", required=True, choices=["P", "D", "M"])
    ap.add_argument("--subset", default=str(ROOT / "data" / "processed" / "cross_annotated.jsonl"))
    ap.add_argument("--baseline", action="append", default=[],
                    help="name=path.npz; repeatable")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    baselines = dict(b.split("=", 1) for b in a.baseline)
    run(a.ckpt, a.held_out, a.subset, baselines, a.out)

"""Thin wrapper: evaluate on canceremo (taxonomy P). See eval/evaluate.py."""
import sys, subprocess
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if __name__ == "__main__":
    subprocess.run([sys.executable, str(ROOT / "eval" / "evaluate.py"),
                    "--dataset", str(ROOT / "data" / "processed" / "canceremo.jsonl"),
                    "--taxonomy", "P"] + sys.argv[1:])

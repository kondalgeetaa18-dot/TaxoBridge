"""Efficiency benchmark (Section VI-D, three-level protocol).

For a TRAINED model this measures latency (batch 1 and 32), throughput and peak
memory on the named device across token budgets 0.1..1.0. The weight-independent
part (exact FLOP count + CPU reference timing) is produced by
scripts/benchmark_cost.py and needs no checkpoint; this wrapper adds the
GPU/trained-model latency when a checkpoint and torch+CUDA are available.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from taxobridge.complexity import inference_flops, speedup, speedup_bounds  # noqa: E402


def measure_latency(model, tok, n, batch, rho, device, warmup=3, runs=20):
    import torch
    text = "a " * (n - 2)
    enc = tok([text] * batch, truncation=True, max_length=n, padding="max_length",
              return_tensors="pt").to(device)
    from taxobridge.infer import predict
    for _ in range(warmup):
        predict(model, enc["input_ids"], enc["attention_mask"], rho=rho)
    if device == "cuda":
        torch.cuda.synchronize()
    ts = []
    for _ in range(runs):
        t0 = time.perf_counter()
        predict(model, enc["input_ids"], enc["attention_mask"], rho=rho)
        if device == "cuda":
            torch.cuda.synchronize()
        ts.append(time.perf_counter() - t0)
    med = float(np.median(ts))
    mem = (torch.cuda.max_memory_allocated() / 1e9) if device == "cuda" else None
    return {"latency_ms": med * 1000 / batch, "throughput_posts_s": batch / med,
            "peak_mem_gb": mem}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--n", type=int, default=104)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    import torch
    from taxobridge.infer import load_model
    from transformers import AutoTokenizer
    model = load_model(a.ckpt)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device)
    tok = AutoTokenizer.from_pretrained(model.cfg.encoder_name)

    rows = []
    for rho in [round(r, 1) for r in np.arange(0.1, 1.01, 0.1)]:
        flops = inference_flops(a.n, rho)
        rec = {"rho": rho, "gflops": flops["total"] / 1e9,
               "arith_speedup": speedup(a.n, rho)}
        for batch in (1, 32):
            rec[f"b{batch}"] = measure_latency(model, tok, a.n, batch, rho, device)
        rows.append(rec)
    out = {"n": a.n, "device": device, "envelope": speedup_bounds(0.3), "rows": rows}
    print(json.dumps(out, indent=2, default=float))
    if a.out:
        Path(a.out).write_text(json.dumps(out, indent=2, default=float))


if __name__ == "__main__":
    main()

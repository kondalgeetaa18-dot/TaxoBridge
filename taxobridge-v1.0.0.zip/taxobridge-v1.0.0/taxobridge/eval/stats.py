"""Statistical machinery (Section VIII-A).

  * paired bootstrap confidence intervals (10,000 resamples) on test predictions
  * paired approximate-randomization significance tests (100,000 permutations)
  * Holm-Bonferroni correction across a family of comparisons

All operate on per-example score contributions so that macro-F1 differences can
be bootstrapped/permuted at the post level.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


def _macro_f1_from_counts(tp, fp, fn):
    denom = 2 * tp + fp + fn
    with np.errstate(divide="ignore", invalid="ignore"):
        f1 = np.where(denom > 0, 2 * tp / denom, 0.0)
    return float(np.mean(f1))


def macro_f1(y_true, y_pred):
    y_true = np.asarray(y_true); y_pred = np.asarray(y_pred)
    tp = (y_pred & y_true).sum(0)
    fp = (y_pred & (1 - y_true)).sum(0)
    fn = ((1 - y_pred) & y_true).sum(0)
    return _macro_f1_from_counts(tp, fp, fn)


def paired_bootstrap_ci(y_true, pred_a, pred_b=None, n_boot=10000,
                        alpha=0.05, seed=13, metric=macro_f1):
    """Bootstrap CI for a model's metric, or for the paired difference a-b.

    y_true, pred_* : (N, K) binary arrays. Resampling is over the N posts
    (paired), so both models see the same resample each draw.
    """
    rng = np.random.default_rng(seed)
    N = y_true.shape[0]
    vals = np.empty(n_boot)
    for i in range(n_boot):
        idx = rng.integers(0, N, N)
        if pred_b is None:
            vals[i] = metric(y_true[idx], pred_a[idx])
        else:
            vals[i] = metric(y_true[idx], pred_a[idx]) - metric(y_true[idx], pred_b[idx])
    lo = float(np.percentile(vals, 100 * alpha / 2))
    hi = float(np.percentile(vals, 100 * (1 - alpha / 2)))
    point = (metric(y_true, pred_a) if pred_b is None
             else metric(y_true, pred_a) - metric(y_true, pred_b))
    return {"point": float(point), "ci_low": lo, "ci_high": hi, "n_boot": n_boot}


def approximate_randomization(y_true, pred_a, pred_b, n_perm=100000,
                              seed=13, metric=macro_f1):
    """Paired approximate-randomization test for metric(a) - metric(b).

    Swaps each post's (a, b) predictions with prob 1/2 and counts how often the
    permuted |difference| >= observed |difference|. Two-sided p-value.
    """
    rng = np.random.default_rng(seed)
    N = y_true.shape[0]
    obs = abs(metric(y_true, pred_a) - metric(y_true, pred_b))
    ge = 1  # +1 for the observed (standard AR correction)
    for _ in range(n_perm):
        swap = rng.random(N) < 0.5
        pa = np.where(swap[:, None], pred_b, pred_a)
        pb = np.where(swap[:, None], pred_a, pred_b)
        if abs(metric(y_true, pa) - metric(y_true, pb)) >= obs - 1e-12:
            ge += 1
    return float(ge / (n_perm + 1))


def holm_bonferroni(pvalues, alpha=0.05):
    """Holm-Bonferroni step-down correction. Returns adjusted p and reject flags."""
    p = np.asarray(pvalues, dtype=float)
    m = len(p)
    order = np.argsort(p)
    adj = np.empty(m)
    running = 0.0
    for rank, idx in enumerate(order):
        val = (m - rank) * p[idx]
        running = max(running, val)
        adj[idx] = min(running, 1.0)
    reject = adj <= alpha
    return {"adjusted_p": adj.tolist(), "reject": reject.tolist(), "alpha": alpha}


@dataclass
class ComparisonResult:
    name: str
    delta: float
    ci_low: float
    ci_high: float
    p_raw: float
    p_holm: float = None
    significant: bool = None


def compare_to_baseline(y_true, model_pred, baseline_pred, name,
                        n_boot=10000, n_perm=100000, seed=13):
    """Full paired comparison: delta macro-F1, bootstrap CI, AR p-value."""
    ci = paired_bootstrap_ci(y_true, model_pred, baseline_pred, n_boot, seed=seed)
    p = approximate_randomization(y_true, model_pred, baseline_pred, n_perm, seed=seed)
    return ComparisonResult(name, ci["point"], ci["ci_low"], ci["ci_high"], p)

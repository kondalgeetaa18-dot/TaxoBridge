"""External validation on ReDSM5 (test only): DSM-5 macro-F1 + evidence
faithfulness (Table XVII). Predicts M heads; scores evidence sets against the
psychologists' rationales (token F1, comprehensiveness, sufficiency, deletion).
See eval/evaluate.py for classification; evidence metrics need the rationale
spans in data/processed/redsm5.jsonl and a checkpoint that returns evidence.
"""
import sys, subprocess
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if __name__ == "__main__":
    subprocess.run([sys.executable, str(ROOT / "eval" / "evaluate.py"),
                    "--dataset", str(ROOT / "data" / "processed" / "redsm5.jsonl"),
                    "--taxonomy", "M"] + sys.argv[1:])
